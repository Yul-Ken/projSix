using System;
using System.IO;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.Animations;
namespace MMDTools
{
    public class MeshUtils
    {

        public static Mesh SplitSubMesh(Mesh src, int idx)
        {
            var dst = new Mesh();
            dst.subMeshCount = 1;
            var desc = src.GetSubMesh(idx);
            var triangles = src.triangles.Skip(desc.indexStart).Take(desc.indexCount).ToArray();
            var start = triangles.Min();
            var count = triangles.Max() - start + 1;

            dst.SetVertices(src.vertices.Skip(start).Take(count).ToArray());
            dst.SetUVs(0, src.uv.Skip(start).Take(count).ToArray());
            dst.SetNormals(src.normals.Skip(start).Take(count).ToArray());
            dst.SetTangents(src.tangents.Skip(start).Take(count).ToArray());
            dst.SetTriangles(triangles.Select(x => x - start).ToArray(), 0);
            dst.bindposes = src.bindposes;
            dst.boneWeights = src.boneWeights.Skip(start).Take(count).ToArray();
            dst.RecalculateBounds();
            dst.RecalculateNormals();
            dst.RecalculateTangents();
            return dst;
        }

        public static Mesh DuplicateMesh(Mesh src)
        {
            var dst = new Mesh();
            dst.name = src.name;
            dst.SetVertices(src.vertices);
            dst.SetUVs(0, src.uv);
            dst.SetNormals(src.normals);
            dst.SetTangents(src.tangents);
            dst.subMeshCount = src.subMeshCount;
            for (int i = 0; i < src.subMeshCount; i++)
            {
                var desc = src.GetSubMesh(i);
                var triangles = src.triangles.Skip(desc.indexStart).Take(desc.indexCount).ToArray();
                // Debug.Log(desc.indexStart + "---" + desc.indexCount + ": " + triangles.Length);
                dst.SetTriangles(triangles, i);
            }
            dst.bindposes = src.bindposes;
            dst.boneWeights = src.boneWeights;
            for (int i = 0; i < src.blendShapeCount; i++)
            {
                int frameCount = src.GetBlendShapeFrameCount(i);
                for (int j = 0; j < frameCount; j++)
                {
                    // continue;
                    var name = src.GetBlendShapeName(i);
                    var vertex = new Vector3[src.vertexCount];
                    var normal = new Vector3[src.vertexCount];
                    var tangent = new Vector3[src.vertexCount];
                    float weight = src.GetBlendShapeFrameWeight(i, j);
                    src.GetBlendShapeFrameVertices(i, j, vertex, normal, tangent);
                    dst.AddBlendShapeFrame(name, weight, vertex, normal, tangent);
                    // Debug.Log($"name: {name}, weight: {weight}, vertex: {vertex}, normal: {normal}, tangent: {tangent}");
                }
            }
            dst.RecalculateBounds();
            dst.RecalculateNormals();
            dst.RecalculateTangents();
            dst.OptimizeReorderVertexBuffer();
            dst.OptimizeIndexBuffers();
            dst.Optimize();
            return dst;
        }
    }
}