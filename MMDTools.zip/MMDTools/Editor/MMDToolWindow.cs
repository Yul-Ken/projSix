using System.Runtime.CompilerServices;
using System;
using System.IO;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.Animations;
using MMDTools;
namespace MMDTools
{
    public class MMDToolWindow : EditorWindow
    {

        GameObject root;
        GameObject prefab;
        string folder = "Assets/";
        string blendShapePath = string.Empty;
        UnityEngine.Object vmd;
        [MenuItem("Tools/MMD工具")]
        static void Init()
        {
            var window = (MMDToolWindow)EditorWindow.GetWindow(typeof(MMDToolWindow), true, "MMD工具");
            window.Show();
        }
        void OnGUI()
        {
            var _root = EditorGUILayout.ObjectField("Model Root: ", root, typeof(GameObject), false) as GameObject;
            if (AssetDatabase.GetAssetPath(_root).EndsWith(".fbx")) root = _root;
            // clip = EditorGUILayout.ObjectField("AnimationClip: ", clip, typeof(AnimationClip), true) as AnimationClip;
            var _vmd = EditorGUILayout.ObjectField("VMD File: ", vmd, typeof(UnityEngine.Object), false) as UnityEngine.Object;
            if (AssetDatabase.GetAssetPath(_vmd).EndsWith(".vmd")) vmd = _vmd;

            if (GUILayout.Button("Process"))
            {
                if (root == null) return;
                prefab = GameObject.Instantiate(root, Vector3.zero, Quaternion.identity);
                prefab.name = root.name;

                var str = EditorUtility.SaveFolderPanel("选择保存路径", folder, "");
                folder = str.Substring(str.LastIndexOf("Assets"));
                Directory.CreateDirectory($"{folder}/Mesh");
                Directory.CreateDirectory($"{folder}/Animation");
                Directory.CreateDirectory($"{folder}/Material");
                Directory.CreateDirectory($"{folder}/Texture");
                // Debug.Log(folder);
                foreach (var skr in prefab.GetComponentsInChildren<SkinnedMeshRenderer>())
                {
                    var mesh = MeshUtils.DuplicateMesh(skr.sharedMesh);
                    if (mesh.blendShapeCount > 0) blendShapePath = GetRelativePath(skr);
                    Save(mesh, $"{folder}/Mesh/{mesh.name}.mesh");
                    skr.sharedMesh = mesh;
                }

                var clip = AnimUtils.DuplicateClip(AssetDatabase.LoadAssetAtPath<AnimationClip>(AssetDatabase.GetAssetPath(root)), true);
                AddCurveToClip(clip);
                Save(clip, $"{folder}/Animation/{clip.name}.anim");

                CreateAnimator(clip);
                CreatePrefab();
            }

            if (GUILayout.Button("Test"))
            {
                var c = new AnimationClip();
                AddCurveToClip(c);
                AssetDatabase.CreateAsset(c, "Assets/test.anim");
            }
        }
        string GetRelativePath(SkinnedMeshRenderer skr)
        {
            var str = skr.gameObject.name;
            Transform p = skr.transform;
            while (p != root)
            {
                str = $"{p.parent.gameObject.name}/{str}";
                p = p.parent;
            }
            return str;
        }

        void AddCurveToClip(AnimationClip clip)
        {
            var path = AssetDatabase.GetAssetPath(vmd);
            var vmd_file = VMDLoaderScript.Import(path);
            var skin_list = vmd_file.skin_list;
            var frame_time = 1f / clip.frameRate;

            foreach (var skin in skin_list.skin)
            {
                var keys = new List<Keyframe>();

                for (int i = 0; i < skin.Value.Count; i++)
                {
                    var data = skin.Value[i];
                    var key = new Keyframe(data.frame_no * frame_time, data.weight);
                    keys.Add(key);
                }
                var curve = new AnimationCurve(keys.ToArray());
                clip.SetCurve(blendShapePath, typeof(SkinnedMeshRenderer), $"blendShape.{skin.Key}", curve);
                AnimationUtility.SetEditorCurve(clip, new EditorCurveBinding(), curve);
            }
        }
        void Save(UnityEngine.Object o, string path)
        {
            if (File.Exists(path)) AssetDatabase.DeleteAsset(path);
            AssetDatabase.CreateAsset(o, path);
        }

        void CreateAnimator(AnimationClip clip)
        {
            Animator animator = prefab.GetComponent<Animator>();
            if (animator == null) animator = prefab.AddComponent<Animator>();
            var path = $"{folder}/Animation/AnimatorController.controller";
            animator.runtimeAnimatorController = AnimatorController.CreateAnimatorControllerAtPathWithClip(path, clip);
        }
        void CreatePrefab()
        {
            // var asset = PrefabUtility.SaveAsPrefabAsset(prefab, $"{folder}/{prefab.name}.prefab");
            var o = PrefabUtility.SaveAsPrefabAssetAndConnect(prefab, $"{folder}/{prefab.name}.prefab", InteractionMode.AutomatedAction);
            GameObject.DestroyImmediate(prefab);
            UnityEditor.EditorUtility.FocusProjectWindow();
            UnityEditor.Selection.activeObject = o;
        }
    }
}