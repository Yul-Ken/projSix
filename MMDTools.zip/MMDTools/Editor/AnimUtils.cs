using System;
using System.IO;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.Animations;
namespace MMDTools
{
    public class AnimUtils
    {
        public static AnimationClip DuplicateClip(AnimationClip src, bool refine = false)
        {
            var clip = new AnimationClip();
            EditorUtility.CopySerialized(src, clip);
            var bindings = AnimationUtility.GetCurveBindings(clip);
            if (refine)
            {
                foreach (var binding in bindings)
                {
                    if (binding.propertyName.Contains("Scale"))
                    {
                        AnimationUtility.SetEditorCurve(clip, binding, null);
                    }
                }
            }
            return clip;
        }
    }
}