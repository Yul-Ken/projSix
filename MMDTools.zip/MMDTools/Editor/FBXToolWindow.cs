﻿using System;
using System.IO;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
namespace MMDTools
{
    public class FBXToolWindow : EditorWindow
    {

        AnimationClip clip;
        SkinnedMeshRenderer skr;
        Animator animator;
        Mesh mesh;
        UnityEngine.Object o;
        [MenuItem("Tools/FBX工具")]
        static void Init()
        {
            // Rect wr = new Rect(600, 400, 400, 100);
            var window = (FBXToolWindow)EditorWindow.GetWindow(typeof(FBXToolWindow), true, "MMD工具");
            window.Show();
        }
        void OnGUI()
        {
            GUILayout.BeginHorizontal();
            clip = EditorGUILayout.ObjectField("AnimationClip: ", clip, typeof(AnimationClip), true) as AnimationClip;
            if (GUILayout.Button("Extract"))
            {
                if (clip)
                {
                    var clip_new = RefiningAnimClip(clip);
                    var path = AssetDatabase.GetAssetPath(clip);
                    var (folder, file_name) = GetFileInfo(path);
                    var str = $"{EditorUtility.SaveFilePanel("选择保存路径", folder, $"{clip.name}", "anim")}";
                    var savePath = str.Substring(str.LastIndexOf("Assets"));
                    if (File.Exists(str)) AssetDatabase.DeleteAsset(savePath);
                    AssetDatabase.CreateAsset(clip_new, savePath);
                }
            }
            // GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            mesh = EditorGUILayout.ObjectField("Mesh: ", mesh, typeof(Mesh), true) as Mesh;
            if (GUILayout.Button("Extract"))
            {
                if (mesh)
                {
                    var mesh_new = DuplicateMesh(mesh);
                    var path = AssetDatabase.GetAssetPath(mesh);
                    var (folder, file_name) = GetFileInfo(path);
                    var str = $"{EditorUtility.SaveFilePanel("选择保存路径", folder, $"{mesh.name}", "mesh")}";
                    var savePath = str.Substring(str.LastIndexOf("Assets"));
                    if (File.Exists(str)) AssetDatabase.DeleteAsset(savePath);
                    AssetDatabase.CreateAsset(mesh_new, savePath);
                }
            }
            // GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            o = EditorGUILayout.ObjectField("Target: ", o, typeof(UnityEngine.Object), true) as UnityEngine.Object;
            if (GUILayout.Button("Build Assets Bundle"))
            {
                if (o)
                {
                    string assetBundleDirectory = "Assets/StreamingAssets";
                    if (!Directory.Exists(Application.streamingAssetsPath))
                    {
                        Directory.CreateDirectory(assetBundleDirectory);
                    }
                    BuildPipeline.BuildAssetBundle(o, null, $"{assetBundleDirectory}/{o.name}.ab", BuildAssetBundleOptions.CollectDependencies, BuildTarget.Android);
                }
            }
            GUILayout.EndHorizontal();
            if (GUILayout.Button("Anim test"))
            {
                if (clip)
                {
                    var binds = AnimationUtility.GetCurveBindings(clip);
                    var curves = AnimationUtility.GetAllCurves(clip);
                    foreach (var bind in binds)
                    {
                        Debug.Log($"{bind.path}/{bind.propertyName}");
                    }
                    var keys = new Keyframe[]{
                    new Keyframe(0,0,0,0,0.3333f,0.3333f),
                    new Keyframe(3,100,0,0,0.3333f,0.3333f),
                    new Keyframe(6,0,0,0,0.3333f,0.3333f),
                };
                    Transform p;

                    var curve = new AnimationCurve(keys);
                    clip.SetCurve("U_Char/U_Char_1", typeof(SkinnedMeshRenderer), "blendShape.笑い", curve);
                    AssetDatabase.SaveAssets();
                    AssetDatabase.Refresh();
                }
            }
            GUILayout.BeginHorizontal();
            skr = EditorGUILayout.ObjectField("SKR: ", skr, typeof(SkinnedMeshRenderer), true) as SkinnedMeshRenderer;
            if (GUILayout.Button("Log BlendShape"))
            {
                if (skr)
                {
                    var m = skr.sharedMesh;
                    for (int i = 0; i < m.blendShapeCount; i++)
                    {
                        Debug.Log(m.GetBlendShapeName(i));
                    }
                }
            }
            GUILayout.EndHorizontal();
        }

        (string, string) GetFileInfo(string path)
        {
            var split = path.LastIndexOf("/");
            var folder = path.Substring(0, split);
            var file_name = path.Substring(split + 1, path.LastIndexOf(".") - split - 1);
            return (folder, file_name);
        }

        AnimationClip RefiningAnimClip(AnimationClip src)
        {
            var clip = new AnimationClip();
            var curves = AnimationUtility.GetAllCurves(src);
            // var bind = AnimationUtility.GetCurveBindings(src);
            foreach (var curve in curves)
            {
                if (!curve.propertyName.Contains("Scale"))
                {
                    clip.SetCurve(curve.path, curve.type, curve.propertyName, curve.curve);
                }
            }

            // clip.SetCurve()

            return clip;
        }

        AnimationClip RefiningAnimClip2(AnimationClip src)
        {
            var clip = new AnimationClip();
            EditorUtility.CopySerialized(src, clip);
            var bindings = AnimationUtility.GetCurveBindings(clip);
            // exclude scale curve
            foreach (var binding in bindings)
            {
                if (binding.propertyName.Contains("Scale"))
                {
                    AnimationUtility.SetEditorCurve(clip, binding, null);
                }
            }
            return clip;
        }

        Mesh DuplicateMesh(Mesh src)
        {
            var dst = new Mesh();
            dst.SetVertices(src.vertices);
            dst.SetUVs(0, src.uv);
            dst.SetNormals(src.normals);
            dst.SetTangents(src.tangents);
            dst.subMeshCount = src.subMeshCount;
            for (int i = 0; i < src.subMeshCount; i++)
            {
                var desc = src.GetSubMesh(i);
                var triangles = src.triangles.Skip(desc.indexStart).Take(desc.indexCount).ToArray();
                // Debug.Log(desc.indexStart + "---" + desc.indexCount + ": " + triangles.Length);
                dst.SetTriangles(triangles, i);
            }
            dst.bindposes = src.bindposes;
            dst.boneWeights = src.boneWeights;
            for (int i = 0; i < src.blendShapeCount; i++)
            {
                int frameCount = src.GetBlendShapeFrameCount(i);
                for (int j = 0; j < frameCount; j++)
                {
                    // continue;
                    var name = src.GetBlendShapeName(i);
                    var vertex = new Vector3[src.vertexCount];
                    var normal = new Vector3[src.vertexCount];
                    var tangent = new Vector3[src.vertexCount];
                    float weight = src.GetBlendShapeFrameWeight(i, j);
                    src.GetBlendShapeFrameVertices(i, j, vertex, normal, tangent);
                    dst.AddBlendShapeFrame(name, weight, vertex, normal, tangent);
                    Debug.Log($"name: {name}, weight: {weight}, vertex: {vertex}, normal: {normal}, tangent: {tangent}");
                }
            }
            dst.RecalculateBounds();
            dst.RecalculateNormals();
            dst.RecalculateTangents();
            dst.OptimizeReorderVertexBuffer();
            dst.OptimizeIndexBuffers();
            dst.Optimize();
            return dst;
        }

        Mesh SplitSubMesh(Mesh src, int idx)
        {
            var dst = new Mesh();
            dst.subMeshCount = 1;
            var desc = src.GetSubMesh(idx);
            var triangles = src.triangles.Skip(desc.indexStart).Take(desc.indexCount).ToArray();
            var start = triangles.Min();
            var count = triangles.Max() - start + 1;

            dst.SetVertices(src.vertices.Skip(start).Take(count).ToArray());
            dst.SetUVs(0, src.uv.Skip(start).Take(count).ToArray());
            dst.SetNormals(src.normals.Skip(start).Take(count).ToArray());
            dst.SetTangents(src.tangents.Skip(start).Take(count).ToArray());
            dst.SetTriangles(triangles.Select(x => x - start).ToArray(), 0);
            dst.bindposes = src.bindposes;
            dst.boneWeights = src.boneWeights.Skip(start).Take(count).ToArray();
            dst.RecalculateBounds();
            dst.RecalculateNormals();
            dst.RecalculateTangents();
            return dst;
        }

    }
}