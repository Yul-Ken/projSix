﻿using System.Net;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Rendering;
using UnityEditor.ProjectWindowCallback;
using UnityEngine;
using System;
using System.IO;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    [CustomEditor(typeof(MDRenderPipelineAsset))]
    public class MDRenderPipelineAssetEditor : Editor
    {
        internal class Styles
        {
            public static GUIContent generalSettingsText = EditorGUIUtility.TrTextContent("General");
            public static GUIContent lightingSettingsText = EditorGUIUtility.TrTextContent("Lighting");
            public static GUIContent shadowSettingsText = EditorGUIUtility.TrTextContent("Shadows");

            public static GUIContent tonemapModeText = EditorGUIUtility.TrTextContent("TonemapMode", "ToneMapping Mode");
            public static GUIContent renderTargetFormatText = EditorGUIUtility.TrTextContent("RenderTargetFormat", "渲染缓冲格式设置");
            public static GUIContent msaaQualityText = EditorGUIUtility.TrTextContent("MsaaQuality", "MSAA Quality");
            public static GUIContent gammaSpaceUIText = EditorGUIUtility.TrTextContent("GammaSpaceUI", "需要单独的UI相机且贴图不勾选sRGB，否则仍在线性下渲染");
            public static GUIContent ForceReversedZBufferText = EditorGUIUtility.TrTextContent("ForceReversedZBuffer", "强制全平台reversed Z");
            public static GUIContent colorGradingDontAffectParticleLayerText = EditorGUIUtility.TrTextContent("ColorGradingDontAffectParticle", "调色不影响特效");
            public static GUIContent renderScaleText = EditorGUIUtility.TrTextContent("RenderScale", "渲染分辨率");

            public static GUIContent opaqueTextureDawnSampleText = EditorGUIUtility.TrTextContent("OpaqueTextureDawnSample", "OpaqueTextureDawnSample");

            public static GUIContent MainLightShadowEnableText = EditorGUIUtility.TrTextContent("MainLightShadowEnable", "启用主光阴影");
            public static GUIContent SoftShadowText = EditorGUIUtility.TrTextContent("SoftShadow", "softshadow");
            public static GUIContent MainLightShadowReslutionText = EditorGUIUtility.TrTextContent("MainLightShadowReslution", "主光阴影分辨率");
            public static GUIContent CharacterShadowReslutionText = EditorGUIUtility.TrTextContent("CharacterShadowReslution", "自阴影分辨率");
            public static GUIContent ShadowDepthBiasText = EditorGUIUtility.TrTextContent("ShadowDepthBias", "ShadowDepthBias");
            public static GUIContent ShadowNormalBiasText = EditorGUIUtility.TrTextContent("ShadowNormalBias", "ShadowNormalBias");
            public static GUIContent ShadowDistanceText = EditorGUIUtility.TrTextContent("ShadowDistance", "ShadowDistance");
            public static GUIContent MainLightShadowDistanceText = EditorGUIUtility.TrTextContent("MainLightShadowDistance", "相对相机视距");
            public static GUIContent EffectSettingText = EditorGUIUtility.TrTextContent("EffectSetting", "后处理设置");

            public static GUIContent addditionalLightsRenderingModeText = EditorGUIUtility.TrTextContent("Additional Lights", "Additional lights support.");
            public static GUIContent perObjectLimit = EditorGUIUtility.TrTextContent("Per Object Limit", "Maximum amount of additional lights. These lights are sorted and culled per-object.");
        }

        bool m_GeneralSettingsFoldout = true;
        bool m_LightingSettingsFoldout = true;
        bool m_ShadowSettingsFoldout = true;

        SerializedProperty m_ToneMappingProp;
        SerializedProperty m_RenderTargetFormatProp;
        SerializedProperty m_MsaaProp;
        SerializedProperty m_GammaSpaceUIProp;
        SerializedProperty m_ForceReversedZBufferProp;
        SerializedProperty m_ColorGradingDontAffectParticleLayerProp;
        SerializedProperty m_RenderScaleProp;
        SerializedProperty m_OpaqueTextureDawnSampleProp;
        SerializedProperty m_EffectSettingProp;

        SerializedProperty m_MainLightShadowEnableProp;
        SerializedProperty m_SoftShadowProp;
        SerializedProperty m_MainLightShadowReslutionProp;
        SerializedProperty m_CharacterShadowReslutionProp;
        SerializedProperty m_ShadowDepthBiasProp;
        SerializedProperty m_ShadowNormalBiasProp;
        SerializedProperty m_ShadowDistanceProp;
        SerializedProperty m_MainLightShadowDistanceProp;


        SerializedProperty m_AdditionalLightsRenderingModeProp;
        SerializedProperty m_AdditionalLightsPerObjectLimitProp;

        LightRenderingMode selectedLightRenderingMode;

        public override void OnInspectorGUI()
        {
            //var asset = target as MDRenderPipelineAsset;
            //asset.renderScale = Mathf.Clamp (asset.renderScale, 0.01f, 4f);
            //base.OnInspectorGUI ();

            //serializedObject.ApplyModifiedProperties ();
            //serializedObject.Update ();

            serializedObject.Update();

            DrawGeneralSettings();
            DrawShadowSettings();
            DrawLightingSettings();
            DrawBuiltInShaderSettings();
            serializedObject.ApplyModifiedProperties();
        }

        void OnEnable()
        {
            m_ToneMappingProp = serializedObject.FindProperty("tonemapMode");
            m_RenderTargetFormatProp = serializedObject.FindProperty("renderTargetFormat");
            m_MsaaProp = serializedObject.FindProperty("msaaQuality");
            m_GammaSpaceUIProp = serializedObject.FindProperty("gammaSpaceUI");
            m_ForceReversedZBufferProp = serializedObject.FindProperty("forceReversedZBuffer");
            m_ColorGradingDontAffectParticleLayerProp = serializedObject.FindProperty("colorGradingDontAffectParticleLayer");
            m_RenderScaleProp = serializedObject.FindProperty("renderScale");
            m_OpaqueTextureDawnSampleProp = serializedObject.FindProperty("OpaqueTextureDawnSample");
            m_EffectSettingProp = serializedObject.FindProperty("effectSetting");

            m_MainLightShadowEnableProp = serializedObject.FindProperty("mainLightShadowEnable");
            m_SoftShadowProp = serializedObject.FindProperty("softShadow");
            m_MainLightShadowReslutionProp = serializedObject.FindProperty("MainLightShadowReslution");
            m_CharacterShadowReslutionProp = serializedObject.FindProperty("CharacterShadowReslution");
            m_ShadowDepthBiasProp = serializedObject.FindProperty("shadowDepthBias");
            m_ShadowNormalBiasProp = serializedObject.FindProperty("shadowNormalBias");
            m_ShadowDistanceProp = serializedObject.FindProperty("shadowDistance");
            m_MainLightShadowDistanceProp = serializedObject.FindProperty("MainLightShadowDistance");

            m_AdditionalLightsRenderingModeProp = serializedObject.FindProperty("additionalLightsRenderingMode");
            m_AdditionalLightsPerObjectLimitProp = serializedObject.FindProperty("additionalLightsPerObjectLimit");

            selectedLightRenderingMode = (LightRenderingMode)m_AdditionalLightsRenderingModeProp.intValue;
        }

        void DrawGeneralSettings()
        {
            m_GeneralSettingsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_GeneralSettingsFoldout, Styles.generalSettingsText);
            if (m_GeneralSettingsFoldout)
            {
                EditorGUI.indentLevel++;

                EditorGUILayout.Space();

                MDRenderPipelineAsset asset = target as MDRenderPipelineAsset;
                EditorGUILayout.PropertyField(m_ToneMappingProp, Styles.tonemapModeText);
                EditorGUILayout.PropertyField(m_RenderTargetFormatProp, Styles.renderTargetFormatText);
                EditorGUILayout.PropertyField(m_MsaaProp, Styles.msaaQualityText);
                EditorGUILayout.PropertyField(m_GammaSpaceUIProp, Styles.gammaSpaceUIText);
                // EditorGUILayout.PropertyField(m_ForceReversedZBufferProp, Styles.ForceReversedZBufferText);//暂时放弃此功能的开发
                EditorGUILayout.PropertyField(m_ColorGradingDontAffectParticleLayerProp, Styles.colorGradingDontAffectParticleLayerText);
                m_RenderScaleProp.floatValue = EditorGUILayout.Slider(Styles.renderScaleText, m_RenderScaleProp.floatValue, 0.01f, 4f);
                m_OpaqueTextureDawnSampleProp.floatValue = EditorGUILayout.Slider(Styles.opaqueTextureDawnSampleText, m_OpaqueTextureDawnSampleProp.floatValue, 0.1f, 1.0f);
                EditorGUILayout.PropertyField(m_EffectSettingProp, Styles.EffectSettingText);

                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        void DrawShadowSettings()
        {
            m_ShadowSettingsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_ShadowSettingsFoldout, Styles.shadowSettingsText);
            if (m_ShadowSettingsFoldout)
            {
                EditorGUI.indentLevel++;

                EditorGUILayout.Space();

                MDRenderPipelineAsset asset = target as MDRenderPipelineAsset;
                EditorGUILayout.PropertyField(m_MainLightShadowEnableProp, Styles.MainLightShadowEnableText);
                EditorGUILayout.PropertyField(m_SoftShadowProp, Styles.SoftShadowText);
                EditorGUILayout.PropertyField(m_MainLightShadowReslutionProp, Styles.MainLightShadowReslutionText);
                EditorGUILayout.PropertyField(m_CharacterShadowReslutionProp, Styles.CharacterShadowReslutionText);
                m_ShadowDepthBiasProp.floatValue = EditorGUILayout.Slider(Styles.ShadowDepthBiasText, m_ShadowDepthBiasProp.floatValue, 0f, 2.0f);
                m_ShadowNormalBiasProp.floatValue = EditorGUILayout.Slider(Styles.ShadowNormalBiasText, m_ShadowNormalBiasProp.floatValue, 0f, 2.0f);
                m_MainLightShadowDistanceProp.floatValue = EditorGUILayout.Slider(Styles.MainLightShadowDistanceText, m_MainLightShadowDistanceProp.floatValue, 0.05f, 1.0f);
                EditorGUILayout.PropertyField(m_ShadowDistanceProp, Styles.ShadowDistanceText);
                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        void DrawLightingSettings()
        {
            m_LightingSettingsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_LightingSettingsFoldout, Styles.lightingSettingsText);
            if (m_LightingSettingsFoldout)
            {
                EditorGUI.indentLevel++;

                EditorGUILayout.Space();

                MDRenderPipelineAsset asset = target as MDRenderPipelineAsset;
                bool disableGroup = false;
                selectedLightRenderingMode = (LightRenderingMode)EditorGUILayout.EnumPopup(Styles.addditionalLightsRenderingModeText, selectedLightRenderingMode);
                m_AdditionalLightsRenderingModeProp.intValue = (int)selectedLightRenderingMode;
                EditorGUI.indentLevel++;

                disableGroup = m_AdditionalLightsRenderingModeProp.intValue == (int)LightRenderingMode.Disabled;
                EditorGUI.BeginDisabledGroup(disableGroup);
                m_AdditionalLightsPerObjectLimitProp.intValue = EditorGUILayout.IntSlider(Styles.perObjectLimit, m_AdditionalLightsPerObjectLimitProp.intValue, 0, 4);
                EditorGUI.EndDisabledGroup();

                EditorGUI.indentLevel--;
                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }
        List<string> shaderIds;
        string GraphicsSettingsPath;
        void DrawBuiltInShaderSettings()
        {
            if (shaderIds == null || shaderIds.Count == 0)
            {
                shaderIds = new List<string>();
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath((target as MDRenderPipelineAsset).defaultShader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.lutBuilderMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.colorGradeMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.blitMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.copyDepthMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.linearToSRGBMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.sRGBToLinearBMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.bloomMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.sunShaftMat.shader)));
                shaderIds.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(CoreUtils.uberMat.shader)));
            }
            if (string.IsNullOrEmpty(GraphicsSettingsPath)) GraphicsSettingsPath = Application.dataPath.Replace("Assets", "") + "ProjectSettings/GraphicsSettings.asset";
            //把管线要用的shader自动添到builtin里,由于找不到合适的API,只好修改文本了(╬▔皿▔)╯
            if (GUILayout.Button("Add pipeline shader to always included"))
            {
                int startIdx = 0, endIdx = 0;
                var shaderToAdd = new List<string>(shaderIds);
                var lines = new List<string>(File.ReadAllLines(GraphicsSettingsPath));
                foreach (var line in lines)
                {
                    if (line.Contains("m_AlwaysIncludedShaders:")) { startIdx = lines.IndexOf(line); endIdx = startIdx + 1; }
                    if (line.Contains("- {fileID: 4800000, guid:")) endIdx = lines.IndexOf(line);
                }
                for (var i = startIdx; i <= endIdx; i++)
                {
                    foreach (var id in shaderIds)
                    {
                        if (lines[i].Contains(id)) shaderToAdd.Remove(id);
                    }
                }
                foreach (var shader in shaderToAdd)
                {
                    lines.Insert(endIdx, $"  - {{fileID: 4800000, guid: {shader}, type: 3}}");
                }
                File.WriteAllLines(GraphicsSettingsPath, lines);
            }

            if (GUILayout.Button("Delete pipeline shader from always included"))
            {
                var lines = new List<string>(File.ReadAllLines(GraphicsSettingsPath));
                var newLines = new List<string>();
                foreach (var line in lines)
                {
                    var flg = true;
                    foreach (var shader in shaderIds)
                    {
                        if (line.Contains(shader)) flg = false;
                    }
                    if (flg) newLines.Add(line);
                }
                File.WriteAllLines(GraphicsSettingsPath, newLines);
            }
        }

        [MenuItem("Assets/Create/Rendering/MD Render Pipeline/PipelineAsset")]
        static void CreatPipelineAsset()
        {
            ProjectWindowUtil.StartNameEditingIfProjectWindowExists(0, CreateInstance<CreateMDPipelineAsset>(), "MDRenderPipelineAsset.asset", null, null);
        }


        class CreateMDPipelineAsset : EndNameEditAction
        {
            public override void Action(int instanceId, string pathName, string resourceFile)
            {
                var instance = CreateInstance<MDRenderPipelineAsset>();
                AssetDatabase.CreateAsset(instance, pathName);
            }
        }
    }
}