1.管线核心是MDRenderPipeline类，unity每帧调用一次它的Render()渲染一遍所有传入的相机，断点跟踪这个函数可以了解整个渲染流程.

2.管线由一系列渲染步骤构成，每步骤算一个pass完成一份具体的渲染工作比如画天空盒、绘制不透明物体或绘制一种后效，所有渲染pass继承自 ScriptablePass类 ，想添新功能继承它重写Excute()函数并添到ScriptableRender.Initpass()里，可以完全自由组合所有的pass.

3.ScriptableRender里RenderingSingleCamera()完成单个相机的渲染，每相机根据情况依次渲PrePass(阴影)、mainPass(场景)、UIPass(UI)，像mainPass就是一个List，包含DrawOpaquePass、DrawSkyBoxPass等渲染步骤，顺序很重要。

4.RenderTextureDescriptor 的无参构造函数构造出来flags值不对，用它申请的RT会上下翻转或FrameDebug下内存暴涨，正确构造方式见CoreUtils.CreateRenderTextureDescriptor().

5.sRGB格式就是伽马空间的具体实现。可以认为所有屏幕都会把线性图拉暗，效果类似将颜色pow了个2.2，想避免它就先把颜色pow个1/2.2(0.45454545)提亮再上屏，pow个1/2.2的操作就叫伽马校正，所以pow(线性空间,1/2.2)=伽马空间，pow(伽马空间，2.2)=线性空间,参考：https://zhuanlan.zhihu.com/p/66558476。

6.工程设置为线性，贴图导入时勾选sRGB选项等价于把贴图颜色pow个2.2，即从伽马空间转到线性，UI图始终处于伽马空间渲染则不转(勾)。

7.builtin shader 与urp shader的唯一区别，是一个LightMode为"Forward"，一个为"UniversalForward"，改了就能互用，没写LightMode的shader当"SRPDefaultUnlit"处理。

8.SRP batch是把材质参数提前以结构体数组的形式缓存进gpu，避免每次DrawCall传节省带宽，要求把材质用的参数写在UnityPerMaterial的buffer里，并且若一个shader含多个pass，每个pass的UnityPerMaterial必须一致。

9.SRP batch 的UnityPerMaterial 有参数数量限制，具体未知，大概20个，超了参数变随机，如果画面表现怪异查下是否参数过多。

10.一个变体就是一个含有某个关键字的新shader，比如一个shader开/关雾效可以分别编译成两个变体，要运行时开关雾效得这俩变体都打进包里，N个关键字可以排列组合出N!个变体，平常只打包用到的变体，变体收集工具见ShaderVariantsCollectionWindow。

11.BatchRendererGroup 类似DrawMeshInstance,不生成GameObject，一次提交一批物体的位置信息，同批物体共用一份网格和材质，一个group可以包含多个batch，BatchRendererGroup最大好处是自动支持SRP batch，并可以自定义裁剪回调函数，EntitySceneGroup类简单封装了一下它，注意一个group用完不调dispose()回收会导致内存泄漏编辑器崩溃。

12.BatchRendererGroup参考：
https://virtualcast.jp/blog/2019/10/batchrenderergroup/
https://zhuanlan.zhihu.com/p/105616808
https://www.bilibili.com/video/BV18J411t7G8?from=search&seid=5281760562959883553
以及 hybridRender包

13.一张RenderTexture就是一张显存里的图片，链接屏幕的RT跟屏幕一样大小(比如1920x1080)，你往里写入什么屏幕就显示什么，整个渲染过程就是GPU拿着网格材质去算这张图每一个像素是什么颜色；当然我们往往不只使用一张RT，比如bloom过程中会用到多张大小不一的RT；通常 RenderTexture可读可写不可压缩，而Texture2D只读不可写且可以以ASTC等压缩格式存在。

14.卡通渲染推荐参考：https://github.com/ColinLeung-NiloCat/UnityURPToonLitShaderExample

15.unity 光照贴图uv可以在导入时勾选自动生成，存放于uv2，同一份网格uv2是固定的，烘培光照贴图时unity会为场景里每个物体生成一个缩放偏移，可通过MeshRenderer.lightmapScaleOffset拿到，shader里变量名为unity_LightmapST，同一份网格只有一份固定的uv2，但每个实例的缩放偏移不同。

16.目前看RenderBatchGroup不支持MaterialPropertyBlock传参，SRP Batch的具体传参细节尚不明朗，烘光照贴图可能只能走DrawMeshInstance或回退为MeshRender orz...

17. 光照烘培参考： https://www.bilibili.com/video/BV1YD4y1X7TG?from=search&seid=12368406943506504276