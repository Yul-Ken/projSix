﻿using UnityEngine;

namespace CustomPipeline
{
    [ExecuteInEditMode]
    public class CharacterShadowCaster : MonoBehaviour
    {
        // public float fov = 1f;
        // public float maxRange = 1f;
        // public float minRange = 1f;
        // public float aspect = 1f;

        // public float left = -5f;
        // public float right = 5;
        // public float bottom = -5;
        // public float top = 5;
        public float size = 5;
        public float near = 0.3f;
        public float far = 10;
        void OnEnable()
        {
            RegisterSelf();
        }
        void Update()
        {
            RegisterSelf(); //to do: 惰性更新
        }

        void OnValidate()
        {
            RegisterSelf();
        }
        void OnDrawGizmos()
        {
            Gizmos.matrix = transform.localToWorldMatrix;
            // Gizmos.DrawFrustum (transform.position, fov, maxRange, minRange, aspect);
            // Gizmos.DrawFrustum (transform.position, fov, maxRange, minRange, 1);
            Gizmos.DrawWireCube(new Vector3(0, 0, (near + far) / 2), new Vector3(size * 2, size * 2, far - near));
        }
        void RegisterSelf()
        {
            DrawCharacterShadowPass.characterShadowCaster = this;
        }
        public Matrix4x4 GetViewMatrice()
        {
            var m = Matrix4x4.TRS(transform.position, transform.rotation, Vector3.one);
            m = Matrix4x4.Inverse(m); //观察空间坐标系为右手
            m.m20 *= -1f;
            m.m21 *= -1f;
            m.m22 *= -1f;
            m.m23 *= -1f;
            return m;
        }
        public Matrix4x4 GetProjMatrice()
        {
            var m = Matrix4x4.Ortho(-size, size, -size, size, near, far);
            return m;
        }
    }
}