﻿using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public enum ShadowResolution
    {
        _256 = 256,
        _512 = 512,
        _1024 = 1024,
        _2048 = 2048,
        _4096 = 4096
    }
    public enum TonemapMode
    {
        ACES,
        None
    }
    public enum LightRenderingMode
    {
        Disabled = 0,
        PerVertex = 2,
        PerPixel = 1,
    }

    public enum MsaaQuality
    {
        Disabled = 1,
        _2x = 2,
        _4x = 4,
        _8x = 8
    }
    public class MDRenderPipelineAsset : RenderPipelineAsset
    {
        public MDRenderPipeline currentActivePipeline;
        [SerializeField] [HideInInspector] public bool supportsDynamicBatching = true;
        [SerializeField] [HideInInspector] public bool lightsUseLinearIntensity = true;
        [SerializeField] public TonemapMode tonemapMode = TonemapMode.None;
        [SerializeField] public RenderTextureFormat renderTargetFormat = RenderTextureFormat.RGB111110Float;//HDR、bloom等后效必须
        [SerializeField] public MsaaQuality msaaQuality = MsaaQuality.Disabled;
        [SerializeField] public bool gammaSpaceUI = true; //需要单独的UI相机且贴图不勾选sRGB，否则仍在线性下渲染
        [SerializeField] public bool forceReversedZBuffer = false; //强制全平台reversed Z,部分逻辑深埋在C++层表现神奇，暂放弃此功能
        [SerializeField] public bool colorGradingDontAffectParticleLayer = true; //调色不影响特效
        [SerializeField] public float renderScale = 1f;

        [SerializeField] public ShadowResolution CharacterShadowReslution = ShadowResolution._1024;
        [SerializeField] public ShadowResolution MainLightShadowReslution = ShadowResolution._4096;
        //[SerializeField] public bool additionalLightsEnable = true; //启用多点光

        [SerializeField] public LightRenderingMode additionalLightsRenderingMode = LightRenderingMode.PerPixel;
        [SerializeField] public int additionalLightsPerObjectLimit = 4;

        [SerializeField] public bool mainLightShadowEnable = true; //主阴影
        [SerializeField] public bool softShadow = true; //软阴影
        [SerializeField] public float shadowDepthBias = 0f;
        [SerializeField] public float shadowNormalBias = 0f;
        [SerializeField] public float shadowDistance = 60f;
        [SerializeField] [Range(0f, 1f)] public float MainLightShadowDistance = 0.15f; //相对相机视距
        [SerializeField] [Range(0.1f, 1f)] public float OpaqueTextureDawnSample = 0.5f;
        [SerializeField] public MDPipelineEffectProfile effectSetting;
        public override Material defaultMaterial => new Material(Shader.Find("MD/Standard/SimplePBR")) { hideFlags = HideFlags.HideAndDontSave };
        // public override Material defaultParticleMaterial => new Material (Shader.Find ("MD/Effect/FX_Main")) { hideFlags = HideFlags.HideAndDontSave };
        public override Shader defaultShader => Shader.Find("MD/Standard/SimplePBR");

        public override bool Equals(object other)
        {
            return base.Equals(other);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
        protected override RenderPipeline CreatePipeline()
        {
            currentActivePipeline = new MDRenderPipeline();
            return currentActivePipeline;
        }

        protected override void OnDisable()
        {
            base.OnDisable();
        }

        protected override void OnValidate()
        {
            base.OnValidate();
        }
    }
}