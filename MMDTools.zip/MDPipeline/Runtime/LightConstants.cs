using Unity.Collections;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public class LightConstants
    {
        public const int MaxCascade = 4; //shader中数组长度定死的
        public const int MaxVisibleLights = 32;
        //public const int MaxPerObjectAdditionalLightsCount = 4;
        public bool softShadow = true;
        public Vector4 shadowBias;
        public Vector4 lightDirection;
        public Vector4 shadowParam;
        public Vector4 shadowmapSize;
        Vector4 mainLightPosition = new Vector4(0, 0, 1, 0);
        Color mainLightColor = Color.black;
        public Matrix4x4[] worldToShadow = new Matrix4x4[MaxCascade + 1]; //结尾多填一个无操作矩阵节省shader分支
        Vector4[] AdditionalLightPositions = new Vector4[MaxVisibleLights];
        Vector4[] AdditionalLightColors = new Vector4[MaxVisibleLights];
        Vector4[] AdditionalLightAttenuations = new Vector4[MaxVisibleLights];
        Vector4[] AdditionalLightSpotDirections = new Vector4[MaxVisibleLights];
        Vector4[] AdditionalLightOcclusionProbeChannels = new Vector4[MaxVisibleLights];
        int AdditionalLightsCount = 0;
        int _MainLightPosition = Shader.PropertyToID("_MainLightPosition");
        int _MainLightColor = Shader.PropertyToID("_MainLightColor");
        int _AdditionalLightsCount = Shader.PropertyToID("_AdditionalLightsCount");
        int _AdditionalLightsPosition = Shader.PropertyToID("_AdditionalLightsPosition");
        int _AdditionalLightsColor = Shader.PropertyToID("_AdditionalLightsColor");
        int _AdditionalLightsAttenuation = Shader.PropertyToID("_AdditionalLightsAttenuation");
        int _AdditionalLightsSpotDir = Shader.PropertyToID("_AdditionalLightsSpotDir");
        int _AdditionalLightOcclusionProbeChannel = Shader.PropertyToID("_AdditionalLightsOcclusionProbes");

        int _WorldToShadow = Shader.PropertyToID("_MainLightWorldToShadow");
        int _ShadowParams = Shader.PropertyToID("_MainLightShadowParams");
        int _CascadeShadowSplitSpheres0 = Shader.PropertyToID("_CascadeShadowSplitSpheres0");
        int _CascadeShadowSplitSpheres1 = Shader.PropertyToID("_CascadeShadowSplitSpheres1");
        int _CascadeShadowSplitSpheres2 = Shader.PropertyToID("_CascadeShadowSplitSpheres2");
        int _CascadeShadowSplitSpheres3 = Shader.PropertyToID("_CascadeShadowSplitSpheres3");
        int _CascadeShadowSplitSphereRadii = Shader.PropertyToID("_CascadeShadowSplitSphereRadii");
        int _ShadowOffset0 = Shader.PropertyToID("_MainLightShadowOffset0");
        int _ShadowOffset1 = Shader.PropertyToID("_MainLightShadowOffset1");
        int _ShadowOffset2 = Shader.PropertyToID("_MainLightShadowOffset2");
        int _ShadowOffset3 = Shader.PropertyToID("_MainLightShadowOffset3");
        int _ShadowmapSize = Shader.PropertyToID("_MainLightShadowmapSize");

        public void SetupMainLight(CommandBuffer cmd, ref ContextStatus stasus)
        {
            var mainLight = stasus.cullingResults.visibleLights[stasus.mainLightIndex];
            if (mainLight.lightType == LightType.Directional)
            {
                lightDirection = -mainLight.localToWorldMatrix.GetColumn(2);
                lightDirection.w = 0f;
                mainLightPosition = lightDirection;
            }
            else
            {
                Vector4 pos = mainLight.localToWorldMatrix.GetColumn(3);
                mainLightPosition = new Vector4(pos.x, pos.y, pos.z, 1.0f);
            }
            mainLightColor = mainLight.finalColor;
            shadowParam = new Vector4(mainLight.light.shadowStrength, softShadow ? 1 : 0, 0, 0);

            cmd.SetGlobalVector(KeywordIds._LightDirectionId, lightDirection);
            cmd.SetGlobalVector(_MainLightPosition, mainLightPosition);
            cmd.SetGlobalVector(_MainLightColor, mainLightColor);
            cmd.SetGlobalVector(_ShadowParams, shadowParam);
        }
        public void SetupAdditionalLight(CommandBuffer cmd, ref ContextStatus status, bool shadeAdditionalLightsPerVertex, int MaxPerObjectAdditionalLightsCount)
        {
            int mainLightIndex = status.mainLightIndex;
            int additionalLightsCount = SetupPerObjectLightIndices(cmd, ref status, mainLightIndex);
            status.additionalLightsCount = additionalLightsCount;
            var lights = status.cullingResults.visibleLights;
            if (additionalLightsCount > 0)
            {
                for (int i = 0, lightIter = 0; i < lights.Length && i < MaxVisibleLights; i++)
                {
                    var light = lights[i];
                    AdditionalLightPositions[lightIter] = new Vector4(0.0f, 0.0f, 1.0f, 0.0f);
                    AdditionalLightColors[lightIter] = Color.black;
                    AdditionalLightAttenuations[lightIter] = new Vector4(0.0f, 1.0f, 0.0f, 1.0f);
                    AdditionalLightSpotDirections[lightIter] = new Vector4(0, 0, 1, 0);
                    AdditionalLightOcclusionProbeChannels[lightIter] = new Vector4(-1.0f, 1.0f, -1.0f, -1.0f);

                    if (mainLightIndex != i)
                    {
                        AdditionalLightColors[lightIter] = light.finalColor;
                        if (light.lightType == LightType.Directional)
                        {
                            Vector4 dir = -light.localToWorldMatrix.GetColumn(2);
                            dir.w = 0;
                            AdditionalLightPositions[lightIter] = dir;
                        }
                        else
                        {
                            Vector4 pos = light.localToWorldMatrix.GetColumn(3);
                            pos.w = 1;
                            AdditionalLightPositions[lightIter] = pos;

                            float lightRangeSqr = light.range * light.range;
                            float fadeStartDistanceSqr = 0.8f * 0.8f * lightRangeSqr;
                            float fadeRangeSqr = (fadeStartDistanceSqr - lightRangeSqr);
                            float oneOverFadeRangeSqr = 1.0f / fadeRangeSqr;
                            float lightRangeSqrOverFadeRangeSqr = -lightRangeSqr / fadeRangeSqr;
                            float oneOverLightRangeSqr = 1.0f / Mathf.Max(0.0001f, light.range * light.range);

                            // On mobile and Nintendo Switch: Use the faster linear smoothing factor (SHADER_HINT_NICE_QUALITY).
                            // On other devices: Use the smoothing factor that matches the GI.
                            AdditionalLightAttenuations[lightIter].x = Application.isMobilePlatform || SystemInfo.graphicsDeviceType == GraphicsDeviceType.Switch ? oneOverFadeRangeSqr : oneOverLightRangeSqr;
                            AdditionalLightAttenuations[lightIter].y = lightRangeSqrOverFadeRangeSqr;
                        }

                        if (light.lightType == LightType.Spot)
                        {
                            Vector4 dir = light.localToWorldMatrix.GetColumn(2);
                            dir.w = 0;
                            AdditionalLightSpotDirections[lightIter] = dir;
                            // Spot Attenuation with a linear falloff can be defined as
                            // (SdotL - cosOuterAngle) / (cosInnerAngle - cosOuterAngle)
                            // This can be rewritten as
                            // invAngleRange = 1.0 / (cosInnerAngle - cosOuterAngle)
                            // SdotL * invAngleRange + (-cosOuterAngle * invAngleRange)
                            // If we precompute the terms in a MAD instruction
                            float cosOuterAngle = Mathf.Cos(Mathf.Deg2Rad * light.spotAngle * 0.5f);
                            // We neeed to do a null check for particle lights
                            // This should be changed in the future
                            // Particle lights will use an inline function
                            float cosInnerAngle;
                            if (light.light != null)
                                cosInnerAngle = Mathf.Cos(light.light.innerSpotAngle * Mathf.Deg2Rad * 0.5f);
                            else
                                cosInnerAngle = Mathf.Cos((2.0f * Mathf.Atan(Mathf.Tan(light.spotAngle * 0.5f * Mathf.Deg2Rad) * (64.0f - 18.0f) / 64.0f)) * 0.5f);
                            float smoothAngleRange = Mathf.Max(0.001f, cosInnerAngle - cosOuterAngle);
                            float invAngleRange = 1.0f / smoothAngleRange;
                            float add = -cosOuterAngle * invAngleRange;
                            AdditionalLightAttenuations[lightIter].z = invAngleRange;
                            AdditionalLightAttenuations[lightIter].w = add;
                        }

                        // Set the occlusion probe channel.
                        int occlusionProbeChannel = light != null ? light.light.bakingOutput.occlusionMaskChannel : -1;

                        // If we have baked the light, the occlusion channel is the index we need to sample in 'unity_ProbesOcclusion'
                        // If we have not baked the light, the occlusion channel is -1.
                        // In case there is no occlusion channel is -1, we set it to zero, and then set the second value in the
                        // input to one. We then, in the shader max with the second value for non-occluded lights.
                        AdditionalLightOcclusionProbeChannels[lightIter].x = occlusionProbeChannel == -1 ? 0f : occlusionProbeChannel;
                        AdditionalLightOcclusionProbeChannels[lightIter].y = occlusionProbeChannel == -1 ? 1f : 0f;
                        ++lightIter;
                    }
                }
                cmd.SetGlobalVectorArray(_AdditionalLightsPosition, AdditionalLightPositions);
                cmd.SetGlobalVectorArray(_AdditionalLightsColor, AdditionalLightColors);
                cmd.SetGlobalVectorArray(_AdditionalLightsAttenuation, AdditionalLightAttenuations);
                cmd.SetGlobalVectorArray(_AdditionalLightsSpotDir, AdditionalLightSpotDirections);
                cmd.SetGlobalVectorArray(_AdditionalLightOcclusionProbeChannel, AdditionalLightOcclusionProbeChannels);
                cmd.SetGlobalVector(_AdditionalLightsCount, new Vector4(MaxPerObjectAdditionalLightsCount, 0.0f, 0.0f, 0.0f));
            }
            else cmd.SetGlobalVector(_AdditionalLightsCount, Vector4.zero);
            if (additionalLightsCount > 0 && shadeAdditionalLightsPerVertex)
                cmd.EnableShaderKeyword(KeywordStrings.AdditionalLightsVertex);
            else
                cmd.DisableShaderKeyword(KeywordStrings.AdditionalLightsVertex);
            if (additionalLightsCount > 0 && !shadeAdditionalLightsPerVertex)
                cmd.EnableShaderKeyword(KeywordStrings.AdditionalLightsPixel);
            else
                cmd.DisableShaderKeyword(KeywordStrings.AdditionalLightsPixel);
        }
        int SetupPerObjectLightIndices(CommandBuffer cmd, ref ContextStatus status, int mainLightIndex)
        {
            var visibleLights = status.cullingResults.visibleLights;
            var perObjectLightIndexMap = status.cullingResults.GetLightIndexMap(Allocator.Temp);
            int globalDirectionalLightsCount = 0;
            int additionalLightsCount = 0;

            // Disable all directional lights from the perobject light indices
            // Pipeline handles main light globally and there's no support for additional directional lights atm.
            for (int i = 0; i < visibleLights.Length; ++i)
            {
                if (additionalLightsCount >= MaxVisibleLights)
                    break;

                VisibleLight light = visibleLights[i];
                if (i == mainLightIndex)
                {
                    perObjectLightIndexMap[i] = -1;
                    ++globalDirectionalLightsCount;
                }
                else
                {
                    perObjectLightIndexMap[i] -= globalDirectionalLightsCount;
                    ++additionalLightsCount;
                }
            }

            // Disable all remaining lights we cannot fit into the global light buffer.
            for (int i = globalDirectionalLightsCount + additionalLightsCount; i < perObjectLightIndexMap.Length; ++i)
                perObjectLightIndexMap[i] = -1;

            status.cullingResults.SetLightIndexMap(perObjectLightIndexMap);
            perObjectLightIndexMap.Dispose();
            status.additionalLightsCount = additionalLightsCount;
            return additionalLightsCount;
        }
        public void SetupShadow(CommandBuffer cmd, ShadowSplitData[] splitData, ref RenderTextureDescriptor shadowmap)
        {
            cmd.SetGlobalVector(_CascadeShadowSplitSpheres0, splitData[0].cullingSphere);
            cmd.SetGlobalVector(_CascadeShadowSplitSpheres1, splitData[1].cullingSphere);
            cmd.SetGlobalVector(_CascadeShadowSplitSpheres2, splitData[2].cullingSphere);
            cmd.SetGlobalVector(_CascadeShadowSplitSpheres3, splitData[3].cullingSphere);

            cmd.SetGlobalVector(_CascadeShadowSplitSphereRadii, new Vector4(
                splitData[0].cullingSphere.w * splitData[0].cullingSphere.w,
                splitData[1].cullingSphere.w * splitData[1].cullingSphere.w,
                splitData[2].cullingSphere.w * splitData[2].cullingSphere.w,
                splitData[3].cullingSphere.w * splitData[3].cullingSphere.w));

            cmd.SetGlobalMatrixArray(_WorldToShadow, worldToShadow);
            cmd.SetGlobalVector(_ShadowmapSize, shadowmapSize);

            if (softShadow)
            {
                var invHalfShadowAtlasWidth = shadowmapSize.x * 0.5f;
                var invHalfShadowAtlasHeight = shadowmapSize.y * 0.5f;
                cmd.SetGlobalVector(_ShadowOffset0, new Vector4(-invHalfShadowAtlasWidth, -invHalfShadowAtlasHeight, 0.0f, 0.0f));
                cmd.SetGlobalVector(_ShadowOffset1, new Vector4(invHalfShadowAtlasWidth, -invHalfShadowAtlasHeight, 0.0f, 0.0f));
                cmd.SetGlobalVector(_ShadowOffset2, new Vector4(-invHalfShadowAtlasWidth, invHalfShadowAtlasHeight, 0.0f, 0.0f));
                cmd.SetGlobalVector(_ShadowOffset3, new Vector4(invHalfShadowAtlasWidth, invHalfShadowAtlasHeight, 0.0f, 0.0f));
            }

            cmd.EnableShaderKeyword(KeywordStrings.MainLightShadows);
            cmd.EnableShaderKeyword(KeywordStrings.MainLightShadowCascades);
            if (softShadow) cmd.EnableShaderKeyword(KeywordStrings.SoftShadows);
            else cmd.DisableShaderKeyword(KeywordStrings.SoftShadows);
        }
    }
}