using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    class PerFrameConstants {
        static int _Time = Shader.PropertyToID ("_Time");
        static int _SinTime = Shader.PropertyToID ("_SinTime");
        static int _CosTime = Shader.PropertyToID ("_CosTime");
        static int unity_DeltaTime = Shader.PropertyToID ("unity_DeltaTime");
        static int _TimeParameters = Shader.PropertyToID ("_TimeParameters");
        static int _GlossyEnvironmentColor = Shader.PropertyToID ("_GlossyEnvironmentColor");
        static int _SubtractiveShadowColor = Shader.PropertyToID ("_SubtractiveShadowColor");
        public static void Update () {
            SphericalHarmonicsL2 ambientSH = RenderSettings.ambientProbe;
            Color linearGlossyEnvColor = new Color (ambientSH[0, 0], ambientSH[1, 0], ambientSH[2, 0]) * RenderSettings.reflectionIntensity;
            Color glossyEnvColor = ColorUtils.ConvertLinearToActiveColorSpace (linearGlossyEnvColor);
            Shader.SetGlobalVector (_GlossyEnvironmentColor, glossyEnvColor);
            Shader.SetGlobalVector (_SubtractiveShadowColor, ColorUtils.ConvertSRGBToActiveColorSpace (RenderSettings.subtractiveShadowColor)); //to do: not necessery
            // if() Shader.EnableKeyword("UNITY_COLORSPACE_GAMMA")

#if UNITY_EDITOR
            float time = Application.isPlaying ? Time.time : Time.realtimeSinceStartup;
#else
            float time = Time.time;
#endif
            float deltaTime = Time.deltaTime;
            float smoothDeltaTime = Time.smoothDeltaTime;

            float timeEights = time / 8f;
            float timeFourth = time / 4f;
            float timeHalf = time / 2f;

            Vector4 timeVector = time * new Vector4 (1f / 20f, 1f, 2f, 3f);
            Vector4 sinTimeVector = new Vector4 (Mathf.Sin (timeEights), Mathf.Sin (timeFourth), Mathf.Sin (timeHalf), Mathf.Sin (time));
            Vector4 cosTimeVector = new Vector4 (Mathf.Cos (timeEights), Mathf.Cos (timeFourth), Mathf.Cos (timeHalf), Mathf.Cos (time));
            Vector4 deltaTimeVector = new Vector4 (deltaTime, 1f / deltaTime, smoothDeltaTime, 1f / smoothDeltaTime);
            Vector4 timeParametersVector = new Vector4 (time, Mathf.Sin (time), Mathf.Cos (time), 0.0f);

            Shader.SetGlobalVector (_Time, timeVector);
            Shader.SetGlobalVector (_SinTime, sinTimeVector);
            Shader.SetGlobalVector (_CosTime, cosTimeVector);
            Shader.SetGlobalVector (unity_DeltaTime, deltaTimeVector);
            Shader.SetGlobalVector (_TimeParameters, timeParametersVector);
        }
    }
}