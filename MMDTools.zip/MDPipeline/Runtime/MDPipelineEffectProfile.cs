using System;
using UnityEngine;

namespace CustomPipeline
{
    [Serializable]
    public class MDPipelineEffectProfile : ScriptableObject
    {
        [SerializeField] public bool bloomEnable = true;
        [SerializeField] [HideInInspector] public float bloomThreshold = 0.9f;
        [SerializeField] [HideInInspector] public float bloomIntensity = 1;
        [SerializeField] [HideInInspector] public Vector4 bloomWeights = new Vector4(1, 1, 1, 1);
        [SerializeField] [HideInInspector] public Vector4 bloomScale = new Vector4(0, 0, 0, 0);
        [SerializeField] public float bloomScatter = 1;
        [SerializeField] public Color bloomTint = Color.white;

        [SerializeField] public bool sunShaftEnable = true;
        [SerializeField] public float sunShaftIntensity = 0.5f;
        [SerializeField] public float sunShaftBlurRadius = 2.5f;
        [SerializeField] public float sunShaftThreshold = 0.15f;
        [SerializeField] public float sunShaftheight = 1f;
        [SerializeField] public int sunShaftRadialBlurIterations = 2;
        [SerializeField] public float sunShaftMaxRadius = 0.75f;

        [SerializeField] public float exposure = 0;
        [SerializeField] [HideInInspector] public Vector4 lift;
        [SerializeField] [HideInInspector] public bool useLift = false;
        [SerializeField] [HideInInspector] public Vector4 gamma;
        [SerializeField] [HideInInspector] public bool useGamma = false;
        [SerializeField] [HideInInspector] public Vector4 gain;
        [SerializeField] [HideInInspector] public bool useGain = false;
        [SerializeField] [HideInInspector] public Vector4 offset;
        [SerializeField] [HideInInspector] public bool useOffset = false;

        [SerializeField] [HideInInspector] public ColorCurves colorCurves = new ColorCurves();
    }
}