using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace CustomPipeline
{
    public enum CommandBufferEventType
    {
        MainShadow,
        AfterOpaque,
        BeforeUI
    }
    public static class CameraCommandBufferEvent
    {
        static List<CommandBuffer> MainShadowCommandBuffers = new List<CommandBuffer>(10);
        static List<CommandBuffer> AfterOpaqueCommandBuffers = new List<CommandBuffer>(10);
        static List<CommandBuffer> BeforeUICommandBuffers = new List<CommandBuffer>(10);
        static List<CommandBuffer> GetEventListByType(CommandBufferEventType bufferEvent)
        {
            switch (bufferEvent)
            {
                case CommandBufferEventType.MainShadow:
                    return MainShadowCommandBuffers;
                case CommandBufferEventType.AfterOpaque:
                    return AfterOpaqueCommandBuffers;
                case CommandBufferEventType.BeforeUI:
                    return BeforeUICommandBuffers;
                default:
                    Debug.LogError("No such CommandBufferEvent!");
                    return null;
            }
        }
        public static CommandBuffer AddCommandBuffer(string name, CommandBufferEventType bufferEvent)
        {
            var command = CommandBufferPool.Get(name);
            var bufferList = GetEventListByType(bufferEvent);
            bufferList.Add(command);
            return command;
        }
        public static void RemoveCommandBuffer(ref CommandBuffer command, CommandBufferEventType bufferEvent)
        {
            var bufferList = GetEventListByType(bufferEvent);
            bufferList.Remove(command);
            CommandBufferPool.Release(command);
            command = null;
        }
        internal static void ExecuteCommandBuffers(ScriptableRender renderer, CommandBufferEventType bufferEvent)
        {
            var bufferList = GetEventListByType(bufferEvent);
            foreach (var command in bufferList) renderer.CommitCommandBuffer(command, false);
        }
    }
}