using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class UberPass : ScriptablePass
    {

        int _TintId = Shader.PropertyToID("_Tint");
        //int _ParamsId = Shader.PropertyToID ("_Params");
        int _BloomTexId = Shader.PropertyToID("_BloomTex");
        int _SunShaftTexId = Shader.PropertyToID("_SunShaftTex");
        int _SunShaftIntensity = Shader.PropertyToID("_SunShaftIntensity");

        Color _Tint;
        RenderTargetHandle tempRt;
        public UberPass()
        {
            tempRt = new RenderTargetHandle("_UberPassRT");
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            if (status.effectSetting == null) return;
            var descriptor = status.targetDescriptor;
            descriptor.msaaSamples = 1;
            descriptor.memoryless = RenderTextureMemoryless.None;
            tempRt.GetTemporaryRT(cmd, ref descriptor, FilterMode.Bilinear);
            var mat = CoreUtils.uberMat;
            //BLOOM
            bool bloom = status.effectSetting.bloomEnable;
            CoreUtils.SetKeyword(cmd, KeywordStrings.BLOOM_ENABLE, bloom);
            if (bloom)
            {
                _Tint = status.effectSetting.bloomTint.linear;
                var luma = ColorUtils.Luminance(_Tint);
                _Tint = luma > 0f ? _Tint * (1f / luma) : Color.white;
                mat.SetVector(_TintId, new Vector4(_Tint.r, _Tint.g, _Tint.b, status.effectSetting.bloomIntensity));
                cmd.SetGlobalTexture(_BloomTexId, status.bloomRTId);
            }

            //SUNSHAFT
            bool sunShaft = status.effectSetting.sunShaftEnable;
            CoreUtils.SetKeyword(cmd, KeywordStrings.SUNSHAFT_ENABLE, sunShaft);
            if (sunShaft)
            {
                cmd.SetGlobalTexture(_SunShaftTexId, status.sunShaftRtId);
                mat.SetFloat(_SunShaftIntensity, status.effectSetting.sunShaftIntensity);
                //mat.SetColor(_SunColorId, _SunColor);
            }

            Blit(renderer.colorTarget.Identifier(), tempRt.Identifier(), mat); //�ϲ���ԭͼ
            Blit(tempRt.Identifier(), renderer.colorTarget.Identifier());
        }
        public override void FrameCleanup()
        {
            tempRt.ReleaseTemporaryRT(cmd);
        }
    }
}