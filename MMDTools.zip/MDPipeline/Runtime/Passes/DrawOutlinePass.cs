using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawOutlinePass : ScriptablePass
    {
        SortingCriteria criteria = SortingCriteria.None;
        ShaderTagId tagId = new ShaderTagId(KeywordStrings.ToonOutline);
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            var drawSetting = CreateDrawingSetting(ref tagId, ref criteria);
            var filterSetting = new FilteringSettings(RenderQueueRange.opaque, renderer.camera.cullingMask);

            context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);
        }
    }
}