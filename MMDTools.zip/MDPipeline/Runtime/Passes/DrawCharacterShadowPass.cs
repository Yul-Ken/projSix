using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawCharacterShadowPass : ScriptablePass
    {
        public static CharacterShadowCaster characterShadowCaster;
        List<ShaderTagId> tagIds = new List<ShaderTagId>();
        SortingCriteria criteria = SortingCriteria.None;
        RenderTargetHandle characterShadowmap;
        int shadowMapSize;
        int worldToCharacterLightId = Shader.PropertyToID(KeywordStrings._WorldToCharacterLight);
        int characterShadowMapSizeId = Shader.PropertyToID(KeywordStrings._CharacterShadowMapSize);
        public DrawCharacterShadowPass()
        {
            MDRenderPipelineAsset asset = MDRenderPipeline.asset;
            shadowMapSize = (int)asset.CharacterShadowReslution;
            var shadowMap = RenderTexture.GetTemporary(
                shadowMapSize, shadowMapSize, 16,
                CoreUtils.shadowFormat);
            shadowMap.filterMode = FilterMode.Point;
            shadowMap.wrapMode = TextureWrapMode.Clamp;
            shadowMap.name = KeywordStrings._CharacterShadowMap;
            characterShadowmap = new RenderTargetHandle(shadowMap);
            Shader.SetGlobalVector(characterShadowMapSizeId, new Vector4(1f / shadowMapSize, 1f / shadowMapSize, shadowMapSize, shadowMapSize));

            tagIds.Add(new ShaderTagId(KeywordStrings.CharacterShadowCaster)); //需要角色shader中添加LightMode为CharacterShadowCaster的pass
            tagIds.Add(new ShaderTagId(KeywordStrings.ShadowCaster)); //待定，暂跟主阴影共用
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            //准备灯光
            var characterlight = characterShadowCaster;
            if (characterlight == null) return;

            //准备渲染缓冲和矩阵
            cmd.SetShadowSamplingMode(characterShadowmap.Identifier(), ShadowSamplingMode.CompareDepths);
            cmd.SetGlobalTexture(characterShadowmap.id, characterShadowmap.Identifier());
            var view = characterlight.GetViewMatrice();
            var proj = characterlight.GetProjMatrice();
            CoreUtils.SetViewProjectionMatrices(cmd, view, proj);

            //设置shader相关参数
            var worldToCharacterLight = CoreUtils.GetAdjustedMatrice(proj, view, false);
            cmd.SetGlobalMatrix(worldToCharacterLightId, worldToCharacterLight);
            SetRenderTarget(characterShadowmap.Identifier(), RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store, true, true);
            cmd.SetViewport(new Rect(0, 0, shadowMapSize, shadowMapSize));
            cmd.EnableScissorRect(new Rect(0 + 4, 0 + 4, shadowMapSize - 8, shadowMapSize - 8));
            renderer.CommitCommandBuffer(cmd);

            //绘制角色阴影
            var drawSetting = CreateDrawingSetting(tagIds, ref criteria);
            var filterSetting = new FilteringSettings(RenderQueueRange.opaque, renderer.camera.cullingMask);
            context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);
            cmd.DisableScissorRect();
        }
        public override void Dispose()
        {
            characterShadowmap.ReleaseRenderTexture();
        }
    }
}