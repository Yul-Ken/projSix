using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class CopyColorAndDepthPass : ScriptablePass
    {
        public RenderTargetHandle _CameraOpaqueTexture = new RenderTargetHandle(KeywordStrings._CameraOpaqueTexture);
        public RenderTargetHandle _CameraDepthTexture = new RenderTargetHandle(KeywordStrings._CameraDepthTexture);
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            //相机背景图
            var cameraOpaqueDesc = status.targetDescriptor;
            cameraOpaqueDesc.width = (int)(cameraOpaqueDesc.width * MDRenderPipeline.asset.OpaqueTextureDawnSample);
            cameraOpaqueDesc.height = (int)(cameraOpaqueDesc.height * MDRenderPipeline.asset.OpaqueTextureDawnSample);
            cameraOpaqueDesc.msaaSamples = 1;
            _CameraOpaqueTexture.GetTemporaryRT(cmd, ref cameraOpaqueDesc, FilterMode.Bilinear);
            Blit(renderer.colorTarget.Identifier(), _CameraOpaqueTexture.Identifier());
            cmd.SetGlobalTexture(_CameraOpaqueTexture.id, _CameraOpaqueTexture.Identifier());

            //深度图
            var cameraDepthDesc = status.targetDescriptor;
            cameraDepthDesc.colorFormat = CoreUtils.depthFormat;
            cameraDepthDesc.msaaSamples = 1;
            //cameraDepthDesc.bindMS = cameraDepthDesc.msaaSamples > 1 && !SystemInfo.supportsMultisampleAutoResolve && (SystemInfo.supportsMultisampledTextures != 0);
            _CameraDepthTexture.GetTemporaryRT(cmd, ref cameraDepthDesc, FilterMode.Point);

            //int cameraSamples = status.targetDescriptor.msaaSamples;
            //if (cameraSamples > 1)
            //{
            //    cmd.DisableShaderKeyword(KeywordString.DepthNoMsaa);
            //    if (cameraSamples == 4)
            //    {
            //        cmd.DisableShaderKeyword(KeywordString.DepthMsaa2);
            //        cmd.EnableShaderKeyword(KeywordString.DepthMsaa4);
            //    }
            //    else
            //    {
            //        cmd.EnableShaderKeyword(KeywordString.DepthMsaa2);
            //        cmd.DisableShaderKeyword(KeywordString.DepthMsaa4);
            //    }
            //}
            //else
            //{
            //    cmd.EnableShaderKeyword(KeywordString.DepthNoMsaa);
            //    cmd.DisableShaderKeyword(KeywordString.DepthMsaa2);
            //    cmd.DisableShaderKeyword(KeywordString.DepthMsaa4);
            //}
            // if (renderer.UseMRT)
            // {
            //     Blit(renderer.color1Target.Identifier(), _CameraDepthTexture.Identifier(), MDRenderUtils.copyDepthMat, 0);
            // }
            // else if (renderer.UseARGBHALF)
            // {
            //     Blit(renderer.colorTarget.Identifier(), _CameraDepthTexture.Identifier(), MDRenderUtils.copyDepthMat, 1);
            // }
            // else
            // {
            //     Blit(renderer.depthTarget.Identifier(), _CameraDepthTexture.Identifier(), MDRenderUtils.copyDepthMat, 0);
            // }

            Blit(renderer.depthTarget.Identifier(), _CameraDepthTexture.Identifier(), CoreUtils.copyDepthMat, 0);
            cmd.SetGlobalTexture(_CameraDepthTexture.id, _CameraDepthTexture.Identifier());
        }
        public override void FrameCleanup()
        {
            _CameraDepthTexture.ReleaseTemporaryRT(cmd);
            _CameraOpaqueTexture.ReleaseTemporaryRT(cmd);
        }
    }
}