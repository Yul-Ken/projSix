using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class SunShaftPass : ScriptablePass
    {
        int radialBlurIterations = 2;

        //Color sunColor = new Color((float)byte.MaxValue / 256f, 15f / 16f, 0.6428571f);
        Vector3 sunTransform;
        //int _SunShaftParams = Shader.PropertyToID ("_SunShaftParams");
        //int _SunStaftThreshold = Shader.PropertyToID("_SunStaftThreshold");
        int _BlurRadius4 = Shader.PropertyToID("_BlurRadius4");
        int _SunPosition = Shader.PropertyToID("_SunPosition");
        int _SunColorId = Shader.PropertyToID("_SunColor");

        RenderTargetHandle sunShaftRt;

        public SunShaftPass()
        {
            sunShaftRt = new RenderTargetHandle("sunShaftRt");
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            if (status.effectSetting == null || !status.effectSetting.sunShaftEnable || status.cullingResults.visibleLights.Length <= 0) return;
            var setting = status.effectSetting;
            Material mat = CoreUtils.sunShaftMat;

            var descriptor = status.targetDescriptor;
            descriptor.msaaSamples = 1;
            descriptor.memoryless = RenderTextureMemoryless.None;
            descriptor.width /= 2;
            descriptor.height /= 2;
            sunShaftRt.GetTemporaryRT(cmd, ref descriptor);
            //mat.SetVector(_SunShaftParams, new Vector4(setting.sunShaftThreshold, setting.sunShaftIntensity, 0,0));
            Blit(renderer.colorTarget.Identifier(), sunShaftRt.Identifier(), mat);

            radialBlurIterations = Mathf.Clamp(setting.sunShaftRadialBlurIterations, 1, 4);
            float num2 = setting.sunShaftBlurRadius * (1f / 768f);
            Vector3 vector3 = Vector3.one * 0.5f;
            Light light = status.cullingResults.visibleLights[status.mainLightIndex].light;
            sunTransform = renderer.camera.transform.position - light.transform.forward * 2000f;
            float t = setting.sunShaftheight;// Mathf.Sin(Time.realtimeSinceStartup ) * 0.3f + 0.5f;
            sunTransform = new Vector3(sunTransform.x, t * (float)(sunTransform.y / 2.0), sunTransform.z);

            vector3 = renderer.camera.WorldToViewportPoint(sunTransform);
            cmd.SetGlobalVector(_BlurRadius4, new Vector4(num2, num2, 0.0f, 0.0f));
            cmd.SetGlobalVector(_SunPosition, new Vector4(vector3.x, vector3.y, vector3.z, setting.sunShaftMaxRadius));

            //RenderTargetHandle sunShaftRt = new RenderTargetHandle(string.Empty);
            //sunShaftRt.GetTemporaryRT(cmd, ref descriptor);

            CoreUtils.uberMat.SetColor(_SunColorId, light.color);

            //Blit(sunShaftRt.Identifier(), sunShaftRt.Identifier(), mat,1);
            for (int index = 0; index < this.radialBlurIterations; ++index)
            {
                RenderTargetHandle temporary2 = new RenderTargetHandle("sunShaftRt2");
                temporary2.GetTemporaryRT(cmd, ref descriptor);
                Blit(sunShaftRt.Identifier(), temporary2.Identifier(), mat, 1);
                sunShaftRt.ReleaseTemporaryRT(cmd);
                float num3 = (float)((double)setting.sunShaftBlurRadius *
                                      (((double)index * 2.0 + 1.0) * 6.0) / 768.0);
                cmd.SetGlobalVector(_BlurRadius4, new Vector4(num3, num3, 0.0f, 0.0f));

                sunShaftRt.GetTemporaryRT(cmd, ref descriptor);
                Blit(temporary2.Identifier(), sunShaftRt.Identifier(), mat, 1);
                temporary2.ReleaseTemporaryRT(cmd);
                float num4 = (float)((double)setting.sunShaftBlurRadius *
                                      (((double)index * 2.0 + 2.0) * 6.0) / 768.0);
                cmd.SetGlobalVector(_BlurRadius4, new Vector4(num4, num4, 0.0f, 0.0f));
            }

            status.sunShaftRtId = sunShaftRt.Identifier();
        }
        public override void FrameCleanup()
        {
            sunShaftRt.ReleaseTemporaryRT(cmd);
        }
    }
}