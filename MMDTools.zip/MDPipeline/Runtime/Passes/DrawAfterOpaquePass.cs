﻿using UnityEngine.Rendering;

namespace CustomPipeline {
    internal class DrawAfterOpaquePass : ScriptablePass {
        public override void Excute (ref ScriptableRenderContext context, ref ContextStatus status) {
            CameraCommandBufferEvent.ExecuteCommandBuffers (renderer, CommandBufferEventType.AfterOpaque);
        }
    }
}