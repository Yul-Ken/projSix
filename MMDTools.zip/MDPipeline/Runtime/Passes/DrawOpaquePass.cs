using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawOpaquePass : ScriptablePass
    {
        List<ShaderTagId> tagIds = new List<ShaderTagId>();
        SortingCriteria criteria = SystemInfo.hasHiddenSurfaceRemovalOnGPU ? SortingCriteria.None : SortingCriteria.CommonOpaque;
        public DrawOpaquePass()
        {
            tagIds.Add(new ShaderTagId(KeywordStrings.UniversalForward));
            tagIds.Add(new ShaderTagId(KeywordStrings.SRPDefaultUnlit));
            tagIds.Add(new ShaderTagId(KeywordStrings.Always));
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            var drawSetting = CreateDrawingSetting(tagIds, ref criteria, CoreUtils.GetPerObjectLightFlags(status.additionalLightsCount));
            var filterSetting = new FilteringSettings(RenderQueueRange.opaque, renderer.camera.cullingMask);

            context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);
        }
    }
}