using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawBloomPass : ScriptablePass
    {
        const int BloomPyramidCount = 5;
        int actualPyramidCount;
        float clamp = 65472f;
        float threshold;
        float thresholdKnee;
        float intensity;
        float scatter;
        Color _Tint;
        Vector4 _Params; // x: scatter, y: clamp, z: threshold (linear), w: threshold knee
        int _TintId = Shader.PropertyToID("_Tint");
        int _ParamsId = Shader.PropertyToID("_Params");
        int BloomWeightsId = Shader.PropertyToID("_Weights");

        RenderTargetHandle[] bloomRTHandle = new RenderTargetHandle[BloomPyramidCount];
        public DrawBloomPass()
        {
            for (var i = 0; i < bloomRTHandle.Length; ++i) bloomRTHandle[i] = new RenderTargetHandle(string.Format("bloomPyramid_{0}", i));
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            if (status.effectSetting == null || !status.effectSetting.bloomEnable) return;

            intensity = status.effectSetting.bloomIntensity;
            threshold = Mathf.GammaToLinearSpace(status.effectSetting.bloomThreshold);
            scatter = status.effectSetting.bloomScatter;
            Vector4 weights = status.effectSetting.bloomWeights;
            Vector4 scale = new Vector4(
                Mathf.Lerp(0.99f, 0.5f, status.effectSetting.bloomScale.x),
                Mathf.Lerp(0.99f, 0.5f, status.effectSetting.bloomScale.y),
                Mathf.Lerp(0.99f, 0.5f, status.effectSetting.bloomScale.z),
                Mathf.Lerp(0.99f, 0.5f, status.effectSetting.bloomScale.w)
            );
            thresholdKnee = threshold * 0.5f; // Hardcoded soft knee
            _Tint = status.effectSetting.bloomTint.linear;
            var luma = ColorUtils.Luminance(_Tint);
            _Tint = luma > 0f ? _Tint * (1f / luma) : Color.white;

            actualPyramidCount = 0;
            var descriptor = status.targetDescriptor;
            descriptor.msaaSamples = 1;
            descriptor.width /= 2;
            descriptor.height /= 2;
            bloomRTHandle[0].GetTemporaryRT(cmd, ref descriptor, FilterMode.Bilinear); //to do: 优化为申请片上RT
            for (var i = 1; i < bloomRTHandle.Length; i++)
            {
                descriptor.width = (int)(descriptor.width * scale[i - 1]);
                descriptor.height = (int)(descriptor.height * scale[i - 1]);
                if (descriptor.width <= 1 || descriptor.height <= 1) break;

                actualPyramidCount = i;
                bloomRTHandle[actualPyramidCount].GetTemporaryRT(cmd, ref descriptor, FilterMode.Bilinear);
            }

            CoreUtils.bloomMat.SetVector(_ParamsId, new Vector4(scatter, clamp, threshold, thresholdKnee));
            CoreUtils.bloomMat.SetVector(_TintId, new Vector4(_Tint.r, _Tint.g, _Tint.b, intensity));
            CoreUtils.bloomMat.SetVector(BloomWeightsId, weights);

            Blit(renderer.colorTarget.Identifier(), bloomRTHandle[0].Identifier(), CoreUtils.bloomMat, 0, false); //提取亮部
            for (var i = 1; i <= actualPyramidCount; ++i) Blit(bloomRTHandle[i - 1].Identifier(), bloomRTHandle[i].Identifier(), CoreUtils.bloomMat, i, false); //降采样
            for (var i = actualPyramidCount; i > 0; --i) Blit(bloomRTHandle[i].Identifier(), bloomRTHandle[i - 1].Identifier(), CoreUtils.bloomMat, 5, false); //升采样
            status.bloomRTId = bloomRTHandle[0].Identifier();
            //Blit (bloomRTHandle[0].Identifier (), renderer.colorTarget.Identifier (), MDRenderUtils.bloomMat, 6, true); //合并回原图
            // renderer.ReSetRenderTarget ();//放到transparent pass里
        }
        public override void FrameCleanup()
        {
            for (var i = 0; i <= actualPyramidCount; ++i) bloomRTHandle[i].ReleaseTemporaryRT(cmd);
        }
    }
}