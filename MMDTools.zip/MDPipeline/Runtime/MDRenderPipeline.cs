using System;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public class MDRenderPipeline : RenderPipeline
    {
        public static MDRenderPipelineAsset asset;
        ScriptableRender renderer;
        public MDRenderPipeline()
        {
            asset = GraphicsSettings.renderPipelineAsset as MDRenderPipelineAsset;
            if (asset == null) { Debug.LogError("Error! No RenderPipelineAsset Find,Pipeline Creation failed!"); return; }
            EnvironmentCheck();
            renderer = new ScriptableRender();
        }
        void EnvironmentCheck()
        {
            GraphicsSettings.lightsUseLinearIntensity = asset.lightsUseLinearIntensity;
            GraphicsSettings.useScriptableRenderPipelineBatching = asset.supportsDynamicBatching;

            CoreUtils.colorFormat = CoreUtils.SupportsRenderTextureFormat(asset.renderTargetFormat)
            ? asset.renderTargetFormat : RenderTextureFormat.DefaultHDR;

            if (CoreUtils.SupportsRenderTextureFormat(RenderTextureFormat.R16))
            {
                CoreUtils.depthFormat = RenderTextureFormat.R16;
            }
            else if (CoreUtils.SupportsRenderTextureFormat(RenderTextureFormat.RHalf))
            {
                CoreUtils.depthFormat = RenderTextureFormat.RHalf;
            }
            else if (CoreUtils.SupportsRenderTextureFormat(RenderTextureFormat.RFloat))
            {
                CoreUtils.depthFormat = RenderTextureFormat.RFloat;
            }
            else
            {
                CoreUtils.depthFormat = RenderTextureFormat.ARGB32;
            }

            CoreUtils.shadowFormat = CoreUtils.SupportsRenderTextureFormat(RenderTextureFormat.Shadowmap)
            ? RenderTextureFormat.Shadowmap : CoreUtils.SupportsRenderTextureFormat(RenderTextureFormat.Depth)
            ? RenderTextureFormat.Depth : CoreUtils.depthFormat;

            if (!CoreUtils.SupportsRenderTextureFormat(RenderTextureFormat.Depth)) { Debug.LogError("This pipeline is NOT supported in Current Platform!"); return; }

#if !UNITY_EDITOR
            Debug.Log($"Set colorFormat: {CoreUtils.colorFormat}\nSet depthFormat: {CoreUtils.depthFormat}\nSet shadowFormat: {CoreUtils.shadowFormat}");
#endif

            //TODO: 抗锯齿模式及平台检查
        }

        //每帧入口
        protected override void Render(ScriptableRenderContext context, Camera[] cameras)
        {
            if (cameras == null || cameras.Length <= 0) return;
            renderer.context = context;
            BeginFrameRendering(context, cameras);
            using (new ProfilingScope(renderer, KeywordStrings.MDRenderer))
            {
                renderer.cameras = cameras;
                PerFrameConstants.Update();
                if (cameras.Length > 1) Array.Sort(cameras, (camera1, camera2) => { return (int)camera1.depth - (int)camera2.depth; }); //gc?
                for (var i = 0; i < cameras.Length; ++i) RenderingSingleCamera(ref context, cameras[i]);
                renderer.EndFrameRendering();
            }
            context.Submit();//所有命令在此正式录制

            EndFrameRendering(context, cameras);
        }
        void RenderingSingleCamera(ref ScriptableRenderContext context, Camera camera)
        {
            BeginCameraRendering(context, camera);
            using (new ProfilingScope(renderer, camera))
            {
                var status = CreateContextStatus(camera);
                SetupCamera(camera, ref context, ref status);

                renderer.RenderingSingleCamera(camera, ref context, ref status);
#if UNITY_EDITOR
                DrawGizmos(ref context, camera);
#endif
            }
            EndCameraRendering(context, camera);
        }
        void SetupCamera(Camera camera, ref ScriptableRenderContext context, ref ContextStatus status)
        {
            PerCameraConstants.Update(camera, ref status);
#if UNITY_EDITOR
            if (camera.cameraType == CameraType.SceneView)
            {
                // context.SetupCameraProperties (camera);//scene窗口某些属性依赖此设置orz...
                ScriptableRenderContext.EmitWorldGeometryForSceneView(camera);
            }
            else if (camera.cameraType == CameraType.Preview)
            {
                status.effectSetting = null;
                camera.clearFlags = CameraClearFlags.Color;
                camera.backgroundColor = new Color32(56, 56, 56, 255);
            }
#endif
        }
#if UNITY_EDITOR
        void DrawGizmos(ref ScriptableRenderContext context, Camera camera)
        {
            if (Handles.ShouldRenderGizmos())
            {
                context.DrawGizmos(camera, GizmoSubset.PreImageEffects);//暂时不管Gizmos后效
                context.DrawGizmos(camera, GizmoSubset.PostImageEffects);
            }
        }
#endif
        ContextStatus CreateContextStatus(Camera camera)
        {
            CameraPostProcess cameraSetting;
            PostProcessManager.instance.GetCameraPostProcess(camera, out cameraSetting);
            return new ContextStatus()
            {
                needReBuildLut = true,
                isBaseCamera = (camera == renderer.cameras[0]) || (camera.clearFlags <= CameraClearFlags.Color), //suppose that skybox,color as base camera, depth or nothing as overlay camera
                rendering3DScene = (camera.cullingMask & KeywordIds.exceptUILayer) != 0,
                renderingUI = (camera.cullingMask & KeywordIds.uiLayer) != 0,
                pixelRect = camera.pixelRect,
                mainLightIndex = 0,
                additionalLightsCount = 0,
                viewMatrix = camera.worldToCameraMatrix,
                projectionMatrix = camera.projectionMatrix,
                effectSetting = cameraSetting && cameraSetting.profile ? cameraSetting.profile : asset.effectSetting,
                targetDescriptor = CoreUtils.CreateRenderTextureDescriptor
                (
                    (int)(camera.pixelRect.width * asset.renderScale),
                    (int)(camera.pixelRect.height * asset.renderScale),
                    0, (int)asset.msaaQuality
                )
            };
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            renderer?.Dispose();
            renderer = null;
        }
    }
}