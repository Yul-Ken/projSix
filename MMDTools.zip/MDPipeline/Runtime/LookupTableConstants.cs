using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    class LookupTableConstants
    {
        public const int lutsize = 32;
        static Vector4 lutParameters = new Vector4(lutsize, 0.5f / (lutsize * lutsize), 0.5f / lutsize, lutsize / (lutsize - 1f));
        static int _LutParameters = Shader.PropertyToID("_Lut_Params");
        static int _ColorBalance = Shader.PropertyToID("_ColorBalance");
        static int _ColorFilter = Shader.PropertyToID("_ColorFilter");
        static int _ChannelMixerRed = Shader.PropertyToID("_ChannelMixerRed");
        static int _ChannelMixerGreen = Shader.PropertyToID("_ChannelMixerGreen");
        static int _ChannelMixerBlue = Shader.PropertyToID("_ChannelMixerBlue");
        static int _HueSatCon = Shader.PropertyToID("_HueSatCon");
        static int _Lift = Shader.PropertyToID("_Lift");
        static int _Gamma = Shader.PropertyToID("_Gamma");
        static int _Gain = Shader.PropertyToID("_Gain");
        static int _Shadows = Shader.PropertyToID("_Shadows");
        static int _Midtones = Shader.PropertyToID("_Midtones");
        static int _Highlights = Shader.PropertyToID("_Highlights");
        static int _ShaHiLimits = Shader.PropertyToID("_ShaHiLimits");
        static int _SplitShadows = Shader.PropertyToID("_SplitShadows");
        static int _SplitHighlights = Shader.PropertyToID("_SplitHighlights");

        static int _CurveMaster = Shader.PropertyToID("_CurveMaster");
        static int _CurveRed = Shader.PropertyToID("_CurveRed");
        static int _CurveGreen = Shader.PropertyToID("_CurveGreen");
        static int _CurveBlue = Shader.PropertyToID("_CurveBlue");
        static int _CurveHueVsHue = Shader.PropertyToID("_CurveHueVsHue");
        static int _CurveHueVsSat = Shader.PropertyToID("_CurveHueVsSat");
        static int _CurveLumVsSat = Shader.PropertyToID("_CurveLumVsSat");
        static int _CurveSatVsSat = Shader.PropertyToID("_CurveSatVsSat");
        //未使用属性均初始化为默认值
        public static void SetupConstants(MDPipelineEffectProfile setting)
        {
            var lmsColorBalance = ColorUtils.ColorBalanceToLMSCoeffs(0, 0);
            var channelMixerR = new Vector4(100f / 100f, 0f / 100f, 0f / 100f, 0f);
            var channelMixerG = new Vector4(0f / 100f, 100f / 100f, 0f / 100f, 0f);
            var channelMixerB = new Vector4(0f / 100f, 0f / 100f, 100f / 100f, 0f);
            var hueSatCon = new Vector4(0f / 360f, 0f / 100f + 1f, 0f / 100f + 1f, 0f);

            var (lift, gamma, gain) = ColorUtils.PrepareLiftGammaGain(
                setting.useLift ? setting.lift : new Vector4(1, 1, 1, 0),
                setting.useGamma ? setting.gamma : new Vector4(1, 1, 1, 0),
                setting.useGain ? setting.gain : new Vector4(1, 1, 1, 0)
            );

            var (shadows, midtones, highlights) = ColorUtils.PrepareShadowsMidtonesHighlights(
                new Vector4(1, 1, 1, 0),
                new Vector4(1, 1, 1, 0),
                new Vector4(1, 1, 1, 0)
            );

            var shadowsHighlightsLimits = new Vector4(0, 0.3f, 0.55f, 1);

            var (splitShadows, splitHighlights) = ColorUtils.PrepareSplitToning(
                new Vector4(0.5f, 0.5f, 0.5f, 1f),
                new Vector4(0.5f, 0.5f, 0.5f, 1f),
                0f
            );

            var material = CoreUtils.lutBuilderMat;
            material.SetVector(_LutParameters, lutParameters);
            material.SetVector(_ColorBalance, lmsColorBalance);
            material.SetVector(_ColorFilter, Color.white.linear);
            material.SetVector(_ChannelMixerRed, channelMixerR);
            material.SetVector(_ChannelMixerGreen, channelMixerG);
            material.SetVector(_ChannelMixerBlue, channelMixerB);
            material.SetVector(_HueSatCon, hueSatCon);
            material.SetVector(_Lift, lift);
            material.SetVector(_Gamma, gamma);
            material.SetVector(_Gain, gain);
            material.SetVector(_Shadows, shadows);
            material.SetVector(_Midtones, midtones);
            material.SetVector(_Highlights, highlights);
            material.SetVector(_ShaHiLimits, shadowsHighlightsLimits);
            material.SetVector(_SplitShadows, splitShadows);
            material.SetVector(_SplitHighlights, splitHighlights);

            // YRGB curves
            material.SetTexture(_CurveMaster, setting.colorCurves.Master.GetTexture());
            material.SetTexture(_CurveRed, setting.colorCurves.Red.GetTexture());
            material.SetTexture(_CurveGreen, setting.colorCurves.Green.GetTexture());
            material.SetTexture(_CurveBlue, setting.colorCurves.Blue.GetTexture());

            // Secondary curves
            material.SetTexture(_CurveHueVsHue, setting.colorCurves.HueVsHue.GetTexture());
            material.SetTexture(_CurveHueVsSat, setting.colorCurves.HueVsSat.GetTexture());
            material.SetTexture(_CurveLumVsSat, setting.colorCurves.LumVsSat.GetTexture());
            material.SetTexture(_CurveSatVsSat, setting.colorCurves.SatVsSat.GetTexture());

            if (MDRenderPipeline.asset.tonemapMode == TonemapMode.ACES) material.EnableKeyword(KeywordStrings._TONEMAP_ACES);
            else material.DisableKeyword(KeywordStrings._TONEMAP_ACES);
        }
    }
}