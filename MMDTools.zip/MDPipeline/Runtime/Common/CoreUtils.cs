using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public class CoreUtils
    {
        public static RenderTextureFormat colorFormat = RenderTextureFormat.RGB111110Float;
        public static RenderTextureFormat depthFormat = RenderTextureFormat.R16;
        public static RenderTextureFormat shadowFormat = RenderTextureFormat.Shadowmap;
        class ScopeParam
        {
            public CommandBuffer command;
            public ProfilingSampler sampler;
            ~ScopeParam()
            {
                CommandBufferPool.Release(command);
                command = null;
                sampler = null;
            }
        }
        static Material _lutBuilderMat;
        public static Material lutBuilderMat { get { if (_lutBuilderMat == null) _lutBuilderMat = new Material(Shader.Find("MD/Standard/LutBuilder")); return _lutBuilderMat; } }
        static Material _colorGradeMat;
        public static Material colorGradeMat { get { if (_colorGradeMat == null) _colorGradeMat = new Material(Shader.Find("MD/Standard/ColorGrade")); return _colorGradeMat; } }
        static Material _blitMat;
        public static Material blitMat { get { if (_blitMat == null) _blitMat = new Material(Shader.Find("MD/Standard/Blit")); return _blitMat; } }
        static Material _copyDepthMat;
        public static Material copyDepthMat { get { if (_copyDepthMat == null) _copyDepthMat = new Material(Shader.Find("MD/Standard/CopyDepth")); return _copyDepthMat; } }
        static Material _linearToSRGBMat;
        public static Material linearToSRGBMat { get { if (_linearToSRGBMat == null) _linearToSRGBMat = new Material(Shader.Find("MD/Standard/LinearToSRGB")); return _linearToSRGBMat; } }
        static Material _sRGBToLinearBMat;
        public static Material sRGBToLinearBMat { get { if (_sRGBToLinearBMat == null) _sRGBToLinearBMat = new Material(Shader.Find("MD/Standard/SRGBToLinear")); return _sRGBToLinearBMat; } }
        static Material _bloomMat;
        public static Material bloomMat { get { if (_bloomMat == null) _bloomMat = new Material(Shader.Find("MD/Standard/Bloom")); return _bloomMat; } }
        static Material _sunShaftMat;
        public static Material sunShaftMat { get { if (_sunShaftMat == null) _sunShaftMat = new Material(Shader.Find("MD/Standard/SunShaft")); return _sunShaftMat; } }
        static Material _uberMat;
        public static Material uberMat { get { if (_uberMat == null) _uberMat = new Material(Shader.Find("MD/Standard/Uber")); return _uberMat; } }
        static Dictionary<string, ScopeParam> ScopeParamPool_string = new Dictionary<string, ScopeParam>();
        public static (CommandBuffer, ProfilingSampler) GetScopeParam(string name)
        {
            ScopeParam scopParam;
            ScopeParamPool_string.TryGetValue(name, out scopParam);
            if (scopParam == null)
            {
                scopParam = new ScopeParam()
                {
                    command = CommandBufferPool.Get(name),
                    sampler = new ProfilingSampler(name)
                };
                ScopeParamPool_string.Add(name, scopParam);
            }
            return (scopParam.command, scopParam.sampler);
        }
        static Dictionary<Camera, ScopeParam> ScopeParamPool_camera = new Dictionary<Camera, ScopeParam>();
        static ScopeParam _previewCameraScopeParam;
        static ScopeParam PreviewCameraScopeParam
        {
            get
            {
                if (_previewCameraScopeParam == null)
                {
                    _previewCameraScopeParam = new ScopeParam()
                    {
                        command = CommandBufferPool.Get(string.Empty),
                        sampler = new ProfilingSampler(string.Empty)
                    };
                }
                return _previewCameraScopeParam;
            }
        }
        public static (CommandBuffer, ProfilingSampler) GetScopeParam(Camera camera)
        {
            ScopeParam scopParam;
            ScopeParamPool_camera.TryGetValue(camera, out scopParam);
            if (scopParam == null)
            {
                if (camera.cameraType == CameraType.Preview)
                {
                    scopParam = PreviewCameraScopeParam;
                }
                else
                {
                    scopParam = new ScopeParam()
                    {
                        command = CommandBufferPool.Get(camera.name),
                        sampler = new ProfilingSampler(camera.name)
                    };
                    ScopeParamPool_camera.Add(camera, scopParam);
                }
            }
            return (scopParam.command, scopParam.sampler);
        }
        static Mesh _fullscreenMesh = null;
        public static Mesh fullscreenMesh
        {
            get
            {
                if (_fullscreenMesh != null) return _fullscreenMesh;

                float topV = 1.0f;
                float bottomV = 0.0f;

                _fullscreenMesh = new Mesh { name = "Fullscreen Quad" };
                _fullscreenMesh.SetVertices(new List<Vector3> {
                    new Vector3 (-1.0f, -1.0f, 0.0f),
                    new Vector3 (-1.0f, 1.0f, 0.0f),
                    new Vector3 (1.0f, -1.0f, 0.0f),
                    new Vector3 (1.0f, 1.0f, 0.0f)
                });

                _fullscreenMesh.SetUVs(0, new List<Vector2> {
                    new Vector2 (0.0f, bottomV),
                    new Vector2 (0.0f, topV),
                    new Vector2 (1.0f, bottomV),
                    new Vector2 (1.0f, topV)
                });

                _fullscreenMesh.SetIndices(new[] { 0, 1, 2, 2, 1, 3 }, MeshTopology.Triangles, 0, false);
                _fullscreenMesh.UploadMeshData(true);
                return _fullscreenMesh;
            }
        }
        static Dictionary<RenderTextureFormat, bool> renderTextureFormatSupport = new Dictionary<RenderTextureFormat, bool>();
        public static bool SupportsRenderTextureFormat(RenderTextureFormat format)
        {
            if (!renderTextureFormatSupport.TryGetValue(format, out var support))
            {
                support = SystemInfo.SupportsRenderTextureFormat(format);
                if (!support) Debug.LogError($"Error!,Current Platform DO NOT support RenderTextureFormat: {format} !");
                renderTextureFormatSupport.Add(format, support);
            }
            return support;
        }
        // reverse Z, flip Y, texture scale and bias
        public static Matrix4x4 GetAdjustedMatrice(Matrix4x4 proj, Matrix4x4 view, bool flipY = true)
        {
            // Matrix4x4 res = GL.GetGPUProjectionMatrix (proj * view, flipY); //反向z及y翻转
            if (SystemInfo.usesReversedZBuffer || MDRenderPipeline.asset.forceReversedZBuffer)
            {
                proj.m20 = -proj.m20;
                proj.m21 = -proj.m21;
                proj.m22 = -proj.m22;
                proj.m23 = -proj.m23;
            }
            Matrix4x4 res = proj * view;
            var textureScaleAndBias = Matrix4x4.identity; //将x,y从(-1,1)映射至(0,1)用于采样
            textureScaleAndBias.m00 = 0.5f;
            textureScaleAndBias.m11 = 0.5f;
            textureScaleAndBias.m22 = 0.5f;
            textureScaleAndBias.m03 = 0.5f;
            textureScaleAndBias.m13 = 0.5f;
            textureScaleAndBias.m23 = 0.5f;
            // Apply texture scale and offset to save a MAD in shader.
            return textureScaleAndBias * res;
        }
        public static PerObjectData GetPerObjectLightFlags(int additionalLightsCount)
        {
            // return UniversalRenderPipeline.GetPerObjectLightFlags (additionalLightsCount);//默认全开...
            var perObjectData = PerObjectData.ReflectionProbes | PerObjectData.Lightmaps | PerObjectData.LightProbe |
                PerObjectData.LightData | PerObjectData.OcclusionProbe | PerObjectData.LightIndices;
            return perObjectData;
        }

        public static RenderTextureDescriptor CreateRenderTextureDescriptor(
            int width, int height, int depthBufferBits = 0,
            int msaaSamples = 1, bool sRGB = false, bool bindMS = false, bool useDynamicScale = false,
            RenderTextureMemoryless memoryless = RenderTextureMemoryless.None)
        {

            //注意，只有带参构造函数会操作descriptor的flag属性，添加AllowVerticalFlip等,
            //无参的构造函数new出来的flag为空,该属性又只读，可能导致在framedebug下严重的内存泄漏（；´д｀）ゞ
            var descriptor = new RenderTextureDescriptor(width, height);

            descriptor.colorFormat = colorFormat;
            descriptor.depthBufferBits = depthBufferBits;
            descriptor.msaaSamples = msaaSamples;
            descriptor.sRGB = sRGB;
            descriptor.bindMS = bindMS;
            descriptor.useDynamicScale = useDynamicScale;
            descriptor.dimension = TextureDimension.Tex2D;//安卓上默认是None,会报错≡(▔﹏▔)≡
            descriptor.memoryless = memoryless;
            return descriptor;
        }
        //等价于camera.worldToCameraMatrix,将世界坐标转入相机空间
        public static Matrix4x4 GetViewMatrix(Vector3 position, Quaternion rotation, Vector3 scale)
        {
            var m = Matrix4x4.TRS(position, rotation, scale);
            m = Matrix4x4.Inverse(m); //观察空间坐标系为右手
            m.m20 *= -1f;
            m.m21 *= -1f;
            m.m22 *= -1f;
            m.m23 *= -1f;
            return m;
        }
        //proj: 等价于camera.projectionMatrix,将世界坐标转入裁剪空间
        //reverseZ: OpenGL like 平台默认(-1,1); DirectX like 平台默认(1,0)
        //flipY: 渲染画面上下翻转，即Y值取反，DX like默认此项
        //uvMapping: 将x,y从(-1,1)直接映射至(0,1)用于采样，shader里直接当贴图uv使用
        public static Matrix4x4 GetGPUProjectionMatrix(Matrix4x4 proj, bool flipY, bool uvMapping = false)
        {
            var bias = Matrix4x4.identity;
            var reverseZ = SystemInfo.usesReversedZBuffer || MDRenderPipeline.asset.forceReversedZBuffer;
            //reverse Z, map z from (-1,1) to (1,0)
            if (reverseZ)
            {
                bias.m22 = -0.5f;
                bias.m23 = 0.5f;
            }
            //y取反,上下翻转
            if (flipY) bias.m11 = -1f;
            //map x,y from (-1,1) to (0,1),save a MAD in shader
            if (uvMapping)
            {
                bias.m00 = 0.5f;
                bias.m11 = 0.5f;
                bias.m03 = 0.5f;
                bias.m13 = 0.5f;
            }

            return bias * proj;
        }
        public static void SetViewProjectionMatrices(CommandBuffer command, Matrix4x4 view, Matrix4x4 proj, bool flipY = false, bool setInverseMatrices = false)
        {
            // if (MDRenderPipeline.asset.forceReversedZBuffer) {
            //     proj = GetGPUProjectionMatrix (proj, flipY);
            //     command.SetGlobalMatrix (PerCameraConstants.viewMatrix, view);
            //     command.SetGlobalMatrix (PerCameraConstants.projectionMatrix, proj);
            //     command.SetGlobalMatrix (PerCameraConstants.viewAndProjectionMatrix, proj * view);
            //     if (setInverseMatrices) {
            //         Matrix4x4 inverseView = Matrix4x4.Inverse (view);
            //         Matrix4x4 inverseProj = Matrix4x4.Inverse (proj);
            //         Matrix4x4 inverseViewProj = inverseView * inverseProj;
            //         command.SetGlobalMatrix (PerCameraConstants.inverseViewMatrix, inverseView);
            //         command.SetGlobalMatrix (PerCameraConstants.inverseProjectionMatrix, inverseProj);
            //         command.SetGlobalMatrix (PerCameraConstants.inverseViewAndProjectionMatrix, inverseViewProj);
            //     }
            // } else {
            command.SetViewProjectionMatrices(view, proj); //按unity默认方式处理
            // }
        }
        public static void SetKeyword(CommandBuffer command, string keyword, bool state)
        {
            if (state) command.EnableShaderKeyword(keyword);
            else command.DisableShaderKeyword(keyword);
        }
    }
}