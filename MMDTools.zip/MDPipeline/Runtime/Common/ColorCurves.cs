using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    [Serializable]
    public sealed class ColorCurves {
        public int activeFlag = 0; //0~7位对应master~lumVsSat是否激活
        //会被面板修改
        public TextureCurve master = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        public TextureCurve red = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        public TextureCurve green = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        public TextureCurve blue = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        public TextureCurve hueVsHue = new TextureCurve (new Keyframe[] { }, 0.5f, true, new Vector2 (0f, 1f));
        public TextureCurve hueVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, true, new Vector2 (0f, 1f));
        public TextureCurve satVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, false, new Vector2 (0f, 1f));
        public TextureCurve lumVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, false, new Vector2 (0f, 1f));

        //保持默认值
        TextureCurve _master = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        TextureCurve _red = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        TextureCurve _green = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        TextureCurve _blue = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
        TextureCurve _hueVsHue = new TextureCurve (new Keyframe[] { }, 0.5f, true, new Vector2 (0f, 1f));
        TextureCurve _hueVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, true, new Vector2 (0f, 1f));
        TextureCurve _satVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, false, new Vector2 (0f, 1f));
        TextureCurve _lumVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, false, new Vector2 (0f, 1f));

        //根据激活情况决定是否使用默认值
        public TextureCurve Master {
            get {
                int mask = 1 << 0;
                if ((activeFlag & mask) > 0) return master;
                else return _master;
            }
        }
        public TextureCurve Red {
            get {
                int mask = 1 << 1;
                if ((activeFlag & mask) > 0) return red;
                else return _red;
            }
        }
        public TextureCurve Green {
            get {
                int mask = 1 << 2;
                if ((activeFlag & mask) > 0) return green;
                else return _green;
            }
        }
        public TextureCurve Blue {
            get {
                int mask = 1 << 3;
                if ((activeFlag & mask) > 0) return blue;
                else return _blue;
            }
        }
        public TextureCurve HueVsHue {
            get {
                int mask = 1 << 4;
                if ((activeFlag & mask) > 0) return hueVsHue;
                else return _hueVsHue;
            }
        }
        public TextureCurve HueVsSat {
            get {
                int mask = 1 << 5;
                if ((activeFlag & mask) > 0) return hueVsSat;
                else return _hueVsSat;
            }
        }
        public TextureCurve SatVsSat {
            get {
                int mask = 1 << 6;
                if ((activeFlag & mask) > 0) return satVsSat;
                else return _satVsSat;
            }
        }
        public TextureCurve LumVsSat {
            get {
                int mask = 1 << 7;
                if ((activeFlag & mask) > 0) return lumVsSat;
                else return _lumVsSat;
            }
        }
        public TextureCurve GetTextureCurve (int idx) {
            switch (idx) {
                case 0:
                    return master;
                case 1:
                    return red;
                case 2:
                    return green;
                case 3:
                    return blue;
                case 4:
                    return hueVsHue;
                case 5:
                    return hueVsSat;
                case 6:
                    return satVsSat;
                case 7:
                    return lumVsSat;
                default:
                    Debug.Log (string.Format ("TextureCurve idx must be 0~7,current idx is {0}", idx));
                    return null;
            }
        }
        public void Reset (int idx) {
            switch (idx) {
                case 0:
                    master = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
                    break;
                case 1:
                    red = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
                    break;
                case 2:
                    green = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
                    break;
                case 3:
                    blue = new TextureCurve (new [] { new Keyframe (0f, 0f, 1f, 1f), new Keyframe (1f, 1f, 1f, 1f) }, 0f, false, new Vector2 (0f, 1f));
                    break;
                case 4:
                    hueVsHue = new TextureCurve (new Keyframe[] { }, 0.5f, true, new Vector2 (0f, 1f));
                    break;
                case 5:
                    hueVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, true, new Vector2 (0f, 1f));
                    break;
                case 6:
                    satVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, false, new Vector2 (0f, 1f));
                    break;
                case 7:
                    lumVsSat = new TextureCurve (new Keyframe[] { }, 0.5f, false, new Vector2 (0f, 1f));
                    break;
            }
        }
    }
}