using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
namespace Painter
{
    [ExecuteInEditMode]
    public class PainterTarget : MonoBehaviour
    {
        public static LayerMask layer;

        public static HashSet<Transform> targets = new HashSet<Transform>();
        void OnEnable()
        {
            layer = LayerMask.NameToLayer("PainterLayer");
            targets.Add(this.transform);
            gameObject.layer = layer;

        }
    }
}