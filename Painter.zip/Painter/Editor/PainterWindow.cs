﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
namespace Painter
{
    public class PainterWindow : EditorWindow
    {
        public static bool isActived = true;
        int layerMask = 1073741824;
        public Mesh mesh;

        [MenuItem("Tools/PanterWindow")]
        static void ShowWindow()
        {
            var window = GetWindow<PainterWindow>();
            window.titleContent = new GUIContent("PanterWindow");
            window.Show();
        }
        void OnEnable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.duringSceneGui += OnSceneGUI;
        }
        void OnGUI()
        {
            if (GUILayout.Button("Add"))
            {
                var o = Selection.activeTransform;
                if (!PainterTarget.targets.Contains(o)) o.gameObject.AddComponent<PainterTarget>();
            }
            if (GUILayout.Button("Clear"))
            {
                foreach (var t in PainterTarget.targets)
                {
                    var o = t.GetComponent<PainterTarget>();
                    if (o)
                    {
                        o.gameObject.layer = 0;
                        DestroyImmediate(o);
                    }
                }
                PainterTarget.targets.Clear();
            }
        }


        void OnSceneGUI(SceneView sceneView)
        {
            var e = Event.current;
            UpdateBrush(e.mousePosition);

        }
        void UpdateBrush(Vector2 mousePosition, bool isDrag = false)
        {
            HandleUtility.AddDefaultControl(GUIUtility.GetControlID(0));
            // int materialIndex;
            // var cur = HandleUtility.PickGameObject(mousePosition, false);
            var hit = new RaycastHit();
            Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
            if (Physics.Raycast(ray, Mathf.Infinity, layerMask))
            {
                Debug.Log("poi");
                Handles.DrawWireDisc(hit.point, hit.normal, 2f);
                Handles.DrawLine(hit.point, hit.point + hit.normal * 1f);
            }


            // SceneView.RepaintAll();
            // this.Repaint();
            // Debug.Log(cur);
        }

        void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
        }
    }
}