using System.Runtime.Serialization;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
namespace Painter
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(PainterTarget))]
    public class PainterEditor : Editor
    {
        static Transform o;
        int count = 0;

        int layerMask = 1073741824;
        void OnSceneGUI()
        {
            if (PainterWindow.isActived)
            {
                HandleUtility.AddDefaultControl(GUIUtility.GetControlID(0));
                RaycastHit hit;
                Event e = Event.current;
                Ray r = HandleUtility.GUIPointToWorldRay(e.mousePosition);
                if (Physics.Raycast(r, out hit, Mathf.Infinity, PainterTarget.layer))
                {
                    // Debug.Log(e);
                    Handles.DrawWireDisc(hit.point, hit.normal, 0.5f);
                }
            }
            // Handles.DrawWireDisc(Vector3.zero,Vector3.up,10f);
        }
    }
}



		// HandleUtility.AddDefaultControl(GUIUtility.GetControlID(0));
		// RaycastHit hit;
		// Event e = Event.current;
		// Ray r = HandleUtility.GUIPointToWorldRay(e.mousePosition);
		// if (Physics.Raycast(r, out hit, Mathf.Infinity, layerMask))
		// {
		// 	// Debug.Log(e);
		// 	Handles.DrawWireDisc(hit.point, hit.normal, 0.5f);
		// }
