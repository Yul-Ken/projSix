﻿

using System;
using UnityEditor;
using UnityEditor.ProjectWindowCallback;
using UnityEngine;

namespace CustomPipeline
{
    [CustomEditor(typeof(MDRenderPipelineEditorResources))]
    class MDRenderPipelineEditorResourcesEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            // Add a "Reload All" button in inspector when we are in developer's mode
            if (UnityEditor.EditorPrefs.GetBool("DeveloperMode") && GUILayout.Button("Reload All"))
            {
                var resources = target as MDRenderPipelineEditorResources;
                resources.materials = null;
                resources.shaders = null;
                ResourceReloader.ReloadAllNullIn(target, MDRenderPipelineAsset.packagePath);
            }
        }
        [MenuItem("Assets/Create/Rendering/MD Render Pipeline/MD Pipeline Editor Resources")]
        static void CreateMDPipelineEditorResources()
        {
            ProjectWindowUtil.StartNameEditingIfProjectWindowExists(0, CreateInstance<CreateMDRenderPipelineEditorResources>(), "MDRenderPipelineEditorResources.asset", null, null);
        }
    }
    class CreateMDRenderPipelineEditorResources : EndNameEditAction
    {
        public override void Action(int instanceId, string pathName, string resourceFile)
        {
            var instance = CreateInstance<MDRenderPipelineEditorResources>();
            ResourceReloader.ReloadAllNullIn(instance, MDRenderPipelineAsset.packagePath);
            AssetDatabase.CreateAsset(instance, pathName);
        }
    }
}
