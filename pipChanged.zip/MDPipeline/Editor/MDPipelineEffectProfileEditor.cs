using System.Reflection;
using UnityEditor;
using UnityEditor.ProjectWindowCallback;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    [CustomEditor (typeof (MDPipelineEffectProfile))]
    public class MDPipelineEffectProfileEditor : Editor {

        internal class Styles
        {
            public static GUIContent bloomSettingsText = EditorGUIUtility.TrTextContent("Bloom");
            public static GUIContent sunShaftSettingsText = EditorGUIUtility.TrTextContent("SunShaft");
            public static GUIContent ssaoSettingsText = EditorGUIUtility.TrTextContent("SSAO");
            public static GUIContent sscsSettingsText = EditorGUIUtility.TrTextContent("SSCloudShadow");
        }
        ColorCurvesDrawer m_curveDrawer;
        TrackballUIDrawer m_TrackballUIDrawer;

        SerializedProperty bloomEnableProp;
        SerializedProperty bloomThreshold;
        SerializedProperty bloomIntensity;
        SerializedProperty bloomWeights;
        SerializedProperty bloomScale;
        SerializedProperty bloomScatter;
        SerializedProperty bloomTint;

        SerializedProperty sunShaftEnableProp;
        SerializedProperty sunShaftIntensityProp;
        SerializedProperty sunShaftBlurRadiusProp;
        SerializedProperty sunShaftThresholdProp;
        SerializedProperty sunShaftheightProp;
        SerializedProperty sunShaftRadialBlurIterationsProp;
        SerializedProperty sunShaftMaxRadiusProp;

        SerializedProperty ssaoTypeProp;
        SerializedProperty ssaoNosieProp;
        SerializedProperty ssaoSampleKernelRadiusProp;
        SerializedProperty ssaoSampleKernelCountProp;
        SerializedProperty ssaoDownSampleProp;
        SerializedProperty ssaoBlurRadiusProp;
        SerializedProperty ssaoBilaterFilterStrengthProp;
        SerializedProperty ssaoOnlyShowAOProp;

        SerializedProperty cloudShadowEnableProp;
        SerializedProperty cloudShadowTexProp;
        SerializedProperty cloudShadowUVTilingProp;
        SerializedProperty cloudShadowUVSpeedProp;
        SerializedProperty cloudShadowIntensityProp;
        SerializedProperty cloudShadowDownSampleProp;
        SerializedProperty cloudShadowColorProp;

        SerializedProperty hbaoRadiusProp;
        SerializedProperty hbaoMaxRadiusPixelsProp;
        SerializedProperty hbaoDownSampleProp;
        SerializedProperty hbaoBiasProp;
        SerializedProperty hbaoIntensityProp;

        SerializedProperty exposure;
        SerializedProperty lift;
        SerializedProperty gamma;
        SerializedProperty gain;
        SerializedProperty offset;
        SerializedProperty colorCurves;
        MDPipelineEffectProfile profile;

        bool m_BloomSettingsFoldout = true;
        bool m_SunShaftSettingsFoldout = true;
        bool m_SsaoSettingsFoldout = true;
        bool m_SSCloudShadowFoldout = true;

        void OnEnable () {
            profile = serializedObject.targetObject as MDPipelineEffectProfile;
            m_curveDrawer = new ColorCurvesDrawer (this, profile.colorCurves);
            m_TrackballUIDrawer = new TrackballUIDrawer ();

            bloomEnableProp = serializedObject.FindProperty("bloomEnable");
            bloomThreshold = serializedObject.FindProperty ("bloomThreshold");
            bloomIntensity = serializedObject.FindProperty ("bloomIntensity");
            bloomWeights = serializedObject.FindProperty ("bloomWeights");
            bloomScale = serializedObject.FindProperty ("bloomScale");
            bloomScatter = serializedObject.FindProperty ("bloomScatter");
            bloomTint = serializedObject.FindProperty ("bloomTint");
            exposure = serializedObject.FindProperty ("exposure");

            sunShaftEnableProp = serializedObject.FindProperty("sunShaftEnable");
            sunShaftIntensityProp = serializedObject.FindProperty("sunShaftIntensity");
            sunShaftBlurRadiusProp = serializedObject.FindProperty("sunShaftBlurRadius");
            sunShaftThresholdProp = serializedObject.FindProperty("sunShaftThreshold");
            sunShaftheightProp = serializedObject.FindProperty("sunShaftheight");
            sunShaftRadialBlurIterationsProp = serializedObject.FindProperty("sunShaftRadialBlurIterations");
            sunShaftMaxRadiusProp = serializedObject.FindProperty("sunShaftMaxRadius");

            ssaoTypeProp = serializedObject.FindProperty("ssaoType");
            ssaoNosieProp = serializedObject.FindProperty("ssaoNosie");
            ssaoSampleKernelRadiusProp = serializedObject.FindProperty("ssaoSampleKernelRadius");
            ssaoSampleKernelCountProp = serializedObject.FindProperty("ssaoSampleKernelCount");
            ssaoDownSampleProp = serializedObject.FindProperty("ssaoDownSample");
            ssaoBlurRadiusProp = serializedObject.FindProperty("ssaoBlurRadius");
            ssaoBilaterFilterStrengthProp = serializedObject.FindProperty("ssaoBilaterFilterStrength");
            ssaoOnlyShowAOProp = serializedObject.FindProperty("ssaoOnlyShowAO");

            hbaoRadiusProp = serializedObject.FindProperty("hbaoRadius");
            hbaoMaxRadiusPixelsProp = serializedObject.FindProperty("hbaoMaxRadiusPixels");
            hbaoDownSampleProp = serializedObject.FindProperty("hbaoDownSample");
            hbaoBiasProp = serializedObject.FindProperty("hbaoBias");
            hbaoIntensityProp = serializedObject.FindProperty("hbaoIntensity");

            cloudShadowEnableProp = serializedObject.FindProperty("cloudShadowEnable");
            cloudShadowTexProp = serializedObject.FindProperty("cloudShadowTex");
            cloudShadowUVSpeedProp = serializedObject.FindProperty("cloudShadowUVSpeed");
            cloudShadowUVTilingProp = serializedObject.FindProperty("cloudShadowUVTiling");
            cloudShadowIntensityProp = serializedObject.FindProperty("cloudShadowIntensity");
            cloudShadowDownSampleProp = serializedObject.FindProperty("cloudShadowDownSample");
            cloudShadowColorProp = serializedObject.FindProperty("cloudShadowColor");

            lift = serializedObject.FindProperty ("lift");
            gamma = serializedObject.FindProperty ("gamma");
            gain = serializedObject.FindProperty ("gain");
            offset = serializedObject.FindProperty ("offset");
            colorCurves = serializedObject.FindProperty ("colorCurves");
        }
        TextureCurve InstantiateTexCurve (TextureCurve textureCurve) {
            var type = textureCurve.GetType ();
            var flag = BindingFlags.Instance | BindingFlags.NonPublic;
            var animationCurve = type.GetField ("m_Curve", flag).GetValue (textureCurve) as AnimationCurve;
            var zeroValue = (float) type.GetField ("m_ZeroValue", flag).GetValue (textureCurve);
            var loop = (bool) type.GetField ("m_Loop", flag).GetValue (textureCurve);
            var range = (float) type.GetField ("m_Range", flag).GetValue (textureCurve);
            return new TextureCurve (animationCurve.keys, zeroValue, loop, new Vector2 (0, range)); //what the hell...
        }
        public override void OnInspectorGUI () {
            if (GUILayout.Button ("Use this profile")) {
                MDRenderPipeline.asset.effectSetting = profile;
            }
            DrawBloomGUI ();
            DrawSunShaftGUI();
            DrawSsaoGUI();
            DrawSSCloudShadowGUI();
            DrawColorCurves ();
            DrawLiftGammaGainOffset ();
            // DrawCopySettings ();
            serializedObject.ApplyModifiedProperties ();
            serializedObject.Update ();
        }
        //以下代码添加两个按钮与URP互相拷贝后处理配置数据，需要引入URP程序集使用
        // VolumeProfile volume;
        // void DrawCopySettings () {
        //     GUILayout.Space (30);
        //     volume = EditorGUILayout.ObjectField (volume, typeof (VolumeProfile), false) as VolumeProfile;
        //     if (GUILayout.Button ("Copy Settings From Volume Profile")) {
        //         if (volume != null) {
        //             UnityEngine.Rendering.Universal.ColorCurves curves = null;
        //             UnityEngine.Rendering.Universal.LiftGammaGain liftGammaGain = null;
        //             foreach (var c in volume.components) {
        //                 if (curves == null) curves = c as UnityEngine.Rendering.Universal.ColorCurves;
        //                 if (liftGammaGain == null) liftGammaGain = c as UnityEngine.Rendering.Universal.LiftGammaGain;
        //             }
        //             if (curves != null) {
        //                 profile.colorCurves.master = InstantiateTexCurve (curves.master.value);
        //                 profile.colorCurves.red = InstantiateTexCurve (curves.red.value);
        //                 profile.colorCurves.green = InstantiateTexCurve (curves.green.value);
        //                 profile.colorCurves.blue = InstantiateTexCurve (curves.blue.value);
        //                 profile.colorCurves.hueVsHue = InstantiateTexCurve (curves.hueVsHue.value);
        //                 profile.colorCurves.hueVsSat = InstantiateTexCurve (curves.hueVsSat.value);
        //                 profile.colorCurves.satVsSat = InstantiateTexCurve (curves.satVsSat.value);
        //                 profile.colorCurves.lumVsSat = InstantiateTexCurve (curves.lumVsSat.value);
        //             }
        //             if (liftGammaGain != null) {
        //                 lift.vector4Value = liftGammaGain.lift.value;
        //                 gamma.vector4Value = liftGammaGain.gamma.value;
        //                 gain.vector4Value = liftGammaGain.gain.value;
        //             }
        //             EditorUtility.SetDirty (serializedObject.targetObject);
        //         }
        //     }
        //     if (GUILayout.Button ("Copy Settings To Volume Profile ")) {
        //         if (volume != null) {
        //             UnityEngine.Rendering.Universal.ColorCurves curves = null;
        //             UnityEngine.Rendering.Universal.LiftGammaGain liftGammaGain = null;
        //             foreach (var c in volume.components) {
        //                 if (curves == null) curves = c as UnityEngine.Rendering.Universal.ColorCurves;
        //                 if (liftGammaGain == null) liftGammaGain = c as UnityEngine.Rendering.Universal.LiftGammaGain;
        //             }
        //             if (curves != null) {
        //                 curves.master.value = InstantiateTexCurve (profile.colorCurves.master);
        //                 curves.red.value = InstantiateTexCurve (profile.colorCurves.red);
        //                 curves.green.value = InstantiateTexCurve (profile.colorCurves.green);
        //                 curves.blue.value = InstantiateTexCurve (profile.colorCurves.blue);
        //                 curves.hueVsHue.value = InstantiateTexCurve (profile.colorCurves.hueVsHue);
        //                 curves.hueVsSat.value = InstantiateTexCurve (profile.colorCurves.hueVsSat);
        //                 curves.satVsSat.value = InstantiateTexCurve (profile.colorCurves.satVsSat);
        //                 curves.lumVsSat.value = InstantiateTexCurve (profile.colorCurves.lumVsSat);
        //             }
        //             if (liftGammaGain != null) {
        //                 liftGammaGain.lift.value = lift.vector4Value;
        //                 liftGammaGain.gamma.value = gamma.vector4Value;
        //                 liftGammaGain.gain.value = gain.vector4Value;
        //             }
        //             EditorUtility.SetDirty (volume);
        //         }
        //     }
        // }
        void DrawBloomGUI () {
            m_BloomSettingsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_BloomSettingsFoldout, Styles.bloomSettingsText);
            if (m_BloomSettingsFoldout)
            {
                EditorGUI.indentLevel++;
                

                EditorGUILayout.PropertyField(bloomEnableProp);
                EditorGUILayout.PropertyField(bloomThreshold);
                if (bloomThreshold.floatValue < 0) bloomThreshold.floatValue = 0;
                EditorGUILayout.PropertyField(bloomIntensity);
                if (bloomIntensity.floatValue < 0) bloomIntensity.floatValue = 0;

                var weights = bloomWeights.vector4Value;
                var scale = bloomScale.vector4Value;

                GUILayout.BeginVertical();
                StepGUI(1, ref weights.x, ref scale.x);
                StepGUI(2, ref weights.y, ref scale.y);
                StepGUI(3, ref weights.z, ref scale.z);
                StepGUI(4, ref weights.w, ref scale.w);
                GUILayout.EndHorizontal();
                bloomWeights.vector4Value = weights;
                bloomScale.vector4Value = scale;

                EditorGUILayout.PropertyField(bloomScatter);
                if (bloomScatter.floatValue < 1) bloomScatter.floatValue = 1;
                EditorGUILayout.PropertyField(bloomTint);
                EditorGUILayout.PropertyField(exposure);

                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
            
        }

        void DrawSunShaftGUI()
        {
            m_SunShaftSettingsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_SunShaftSettingsFoldout, Styles.sunShaftSettingsText);
            if (m_SunShaftSettingsFoldout)
            {
                EditorGUI.indentLevel++;
                

                EditorGUILayout.PropertyField(sunShaftEnableProp);
                sunShaftIntensityProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("sunShaftIntensity"), sunShaftIntensityProp.floatValue, 0f, 2.0f);
                sunShaftBlurRadiusProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("sunShaftBlurRadius"), sunShaftBlurRadiusProp.floatValue, 0f, 5.0f);
                sunShaftThresholdProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("sunShaftThreshold"), sunShaftThresholdProp.floatValue, 0f, 0.15f);
                sunShaftheightProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("sunShaftheight"), sunShaftheightProp.floatValue, -5f, 5f);
                sunShaftRadialBlurIterationsProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("sunShaftRadialBlurIterations"), sunShaftRadialBlurIterationsProp.intValue, 0, 4);
                sunShaftMaxRadiusProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("sunShaftMaxRadius"), sunShaftMaxRadiusProp.floatValue, 0f, 1f);

                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        void DrawSsaoGUI()
        {
            m_SsaoSettingsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_SsaoSettingsFoldout, Styles.ssaoSettingsText);
            if (m_SsaoSettingsFoldout)
            {
                EditorGUI.indentLevel++;


                EditorGUILayout.PropertyField(ssaoTypeProp);
                if(ssaoTypeProp.intValue == (int)SSAOType.LearnOpengl)
                {
                    EditorGUILayout.PropertyField(ssaoNosieProp);
                    ssaoSampleKernelRadiusProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("SampleKernelRadius"), ssaoSampleKernelRadiusProp.floatValue, 0.01f, 1.0f);
                    ssaoSampleKernelCountProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("SampleKernelCount"), ssaoSampleKernelCountProp.intValue, 4, 64);
                    ssaoDownSampleProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("DownSample"), ssaoDownSampleProp.intValue, 0, 2);
                    ssaoBlurRadiusProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("BlurRadius"), ssaoBlurRadiusProp.intValue, 1, 4);
                    //ssaoBilaterFilterStrengthProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("BilaterFilterStrength"), ssaoBilaterFilterStrengthProp.floatValue, 0f, 0.2f);
                    EditorGUILayout.PropertyField(ssaoOnlyShowAOProp);
                }
                else if(ssaoTypeProp.intValue == (int)SSAOType.HBAO)
                {
                    hbaoRadiusProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("hbaoRadius"), hbaoRadiusProp.floatValue, 0f, 3f);
                    hbaoMaxRadiusPixelsProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("hbaoMaxRadiusPixels"), hbaoMaxRadiusPixelsProp.intValue, 32, 256);
                    hbaoDownSampleProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("hbaoDownSample"), hbaoDownSampleProp.intValue, 0, 2);
                    hbaoBiasProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("hbaoBias"), hbaoBiasProp.floatValue, 0, 0.99f);
                    hbaoIntensityProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("hbaoIntensity"), hbaoIntensityProp.floatValue, 0f, 2f);
                    ssaoBlurRadiusProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("BlurRadius"), ssaoBlurRadiusProp.intValue, 1, 4);
                    //ssaoBilaterFilterStrengthProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("BilaterFilterStrength"), ssaoBilaterFilterStrengthProp.floatValue, 0f, 0.2f);
                    EditorGUILayout.PropertyField(ssaoOnlyShowAOProp);
                }
                

                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        void DrawSSCloudShadowGUI()
        {
            m_SSCloudShadowFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(m_SSCloudShadowFoldout, Styles.sscsSettingsText);
            if (m_SSCloudShadowFoldout)
            {
                EditorGUI.indentLevel++;
                
                EditorGUILayout.PropertyField(cloudShadowEnableProp);
                EditorGUILayout.PropertyField(cloudShadowTexProp);
                EditorGUILayout.PropertyField(cloudShadowUVTilingProp);
                EditorGUILayout.PropertyField(cloudShadowUVSpeedProp);
                cloudShadowIntensityProp.floatValue = EditorGUILayout.Slider(EditorGUIUtility.TrTextContent("cloudShadowIntensity"), cloudShadowIntensityProp.floatValue, 0f, 2f);
                cloudShadowDownSampleProp.intValue = EditorGUILayout.IntSlider(EditorGUIUtility.TrTextContent("cloudShadowDownSample"), cloudShadowDownSampleProp.intValue, 0, 2);
                EditorGUILayout.PropertyField(cloudShadowColorProp);
                EditorGUI.indentLevel--;
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        void StepGUI (int step, ref float weight, ref float scale) {
            GUILayout.BeginHorizontal ();
            EditorGUILayout.LabelField (string.Format ("DownSample Step {0}:\tWeight & Scale", step));
            weight = EditorGUILayout.FloatField (weight);
            scale = EditorGUILayout.Slider (scale, 0, 1);
            GUILayout.EndHorizontal ();
        }
        void DrawColorCurves () {
            m_curveDrawer.OnGUI ();
        }
        void DrawLiftGammaGainOffset () {
            GUILayout.Space (10f);
            using (new EditorGUILayout.HorizontalScope ()) {
                m_TrackballUIDrawer.OnGUI (lift, EditorGUIUtility.TrTextContent ("Lift"), ref profile.useLift);
                GUILayout.Space (4f);
                m_TrackballUIDrawer.OnGUI (gamma, EditorGUIUtility.TrTextContent ("Gamma"), ref profile.useGamma);
                GUILayout.Space (4f);
                m_TrackballUIDrawer.OnGUI (gain, EditorGUIUtility.TrTextContent ("Gain"), ref profile.useGain);
                GUILayout.Space (4f);
                m_TrackballUIDrawer.OnGUI (offset, EditorGUIUtility.TrTextContent ("Offset"), ref profile.useOffset);
            }
        }

        [MenuItem ("Assets/Create/Rendering/MD Render Pipeline/EffectProfile")]
        static void CreateEffectProfile () {
            ProjectWindowUtil.StartNameEditingIfProjectWindowExists (0, CreateInstance<CreateMDPipelineProfile> (), "MDPipelineEffectProfile.asset", null, null);
        }
        class CreateMDPipelineProfile : EndNameEditAction {
            public override void Action (int instanceId, string pathName, string resourceFile) {
                var instance = CreateInstance<MDPipelineEffectProfile> ();
                AssetDatabase.CreateAsset (instance, pathName);
            }
        }
    }
}