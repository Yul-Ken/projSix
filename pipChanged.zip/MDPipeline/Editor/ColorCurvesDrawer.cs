using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    sealed class ColorCurvesDrawer {
        int m_SelectedCurve;
        static GUIStyle s_PreLabel;
        Editor m_Inspector;
        ColorCurves curves;
        static Material s_MaterialGrid;
        InspectorCurveEditor m_CurveEditor;
        SerializedProperty[] curvesArr = new SerializedProperty[8];
        Dictionary<SerializedProperty, Color> m_CurveDict;
        static GUIContent[] s_Curves = {
            new GUIContent ("Master"),
            new GUIContent ("Red"),
            new GUIContent ("Green"),
            new GUIContent ("Blue"),
            new GUIContent ("Hue Vs Hue"),
            new GUIContent ("Hue Vs Sat"),
            new GUIContent ("Sat Vs Sat"),
            new GUIContent ("Lum Vs Sat")
        };
        public ColorCurvesDrawer (Editor parent, ColorCurves colorCurves) {
            m_Inspector = parent;
            curves = colorCurves;
            m_CurveEditor = new InspectorCurveEditor ();
            m_CurveDict = new Dictionary<SerializedProperty, Color> ();

            var o = m_Inspector.serializedObject;
            curvesArr[0] = o.FindProperty ("colorCurves.master.m_Curve");
            curvesArr[1] = o.FindProperty ("colorCurves.red.m_Curve");
            curvesArr[2] = o.FindProperty ("colorCurves.green.m_Curve");
            curvesArr[3] = o.FindProperty ("colorCurves.blue.m_Curve");
            curvesArr[4] = o.FindProperty ("colorCurves.hueVsHue.m_Curve");
            curvesArr[5] = o.FindProperty ("colorCurves.hueVsSat.m_Curve");
            curvesArr[6] = o.FindProperty ("colorCurves.satVsSat.m_Curve");
            curvesArr[7] = o.FindProperty ("colorCurves.lumVsSat.m_Curve");

            SetupCurve (curvesArr[0], new Color (1f, 1f, 1f), 2, false);
            SetupCurve (curvesArr[1], new Color (1f, 0f, 0f), 2, false);
            SetupCurve (curvesArr[2], new Color (0f, 1f, 0f), 2, false);
            SetupCurve (curvesArr[3], new Color (0f, 0.5f, 1f), 2, false);
            SetupCurve (curvesArr[4], new Color (1f, 1f, 1f), 0, true);
            SetupCurve (curvesArr[5], new Color (1f, 1f, 1f), 0, true);
            SetupCurve (curvesArr[6], new Color (1f, 1f, 1f), 0, false);
            SetupCurve (curvesArr[7], new Color (1f, 1f, 1f), 0, false);
        }
        void SetupCurve (SerializedProperty prop, Color color, uint minPointCount, bool loop) {
            var state = InspectorCurveEditor.CurveState.defaultState;
            state.color = color;
            state.visible = false;
            state.minPointCount = minPointCount;
            state.onlyShowHandlesOnSelection = true;
            state.zeroKeyConstantValue = 0.5f;
            state.loopInBounds = loop;
            m_CurveEditor.Add (prop, state);
            m_CurveDict.Add (prop, color);
        }
        void ResetVisibleCurves () {
            foreach (var curve in m_CurveDict) {
                var state = m_CurveEditor.GetCurveState (curve.Key);
                state.visible = false;
                state.editable = false;
                m_CurveEditor.SetCurveState (curve.Key, state);
            }
        }
        void SetCurveVisible (int idx) {
            var rawProp = curvesArr[idx];
            var state = m_CurveEditor.GetCurveState (rawProp);
            state.visible = true;
            state.editable = true;
            m_CurveEditor.SetCurveState (rawProp, state);
        }
        int DoCurveSelectionPopup (int id) {
            GUILayout.Label (s_Curves[id], EditorStyles.toolbarPopup, GUILayout.MaxWidth (150f));
            var lastRect = GUILayoutUtility.GetLastRect ();
            var e = Event.current;
            if (e.type == EventType.MouseDown && e.button == 0 && lastRect.Contains (e.mousePosition)) {
                var menu = new GenericMenu ();

                for (int i = 0; i < s_Curves.Length; i++) {
                    if (i == 4)
                        menu.AddSeparator ("");
                    int current = i; // Capture local for closure
                    menu.AddItem (s_Curves[i], current == id, () => {
                        m_SelectedCurve = current;
                    });
                }
                menu.DropDown (new Rect (lastRect.xMin, lastRect.yMax, 1f, 1f));
            }
            return id;
        }
        void DrawBackgroundTexture (Rect rect, int pass) {
            if (s_MaterialGrid == null)
                s_MaterialGrid = new Material (Shader.Find ("Hidden/Universal Render Pipeline/Editor/CurveBackground")) { hideFlags = HideFlags.HideAndDontSave };

            float scale = EditorGUIUtility.pixelsPerPoint;

            var oldRt = RenderTexture.active;
            var rt = RenderTexture.GetTemporary (Mathf.CeilToInt (rect.width * scale), Mathf.CeilToInt (rect.height * scale), 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
            s_MaterialGrid.SetFloat ("_DisabledState", GUI.enabled ? 1f : 0.5f);

            Graphics.Blit (null, rt, s_MaterialGrid, pass);
            RenderTexture.active = oldRt;

            GUI.DrawTexture (rect, rt);
            RenderTexture.ReleaseTemporary (rt);
        }
        public void OnGUI () {
            int curveEditingId;
            ResetVisibleCurves ();
            // Top toolbar
            using (new GUILayout.HorizontalScope (EditorStyles.toolbar)) {
                curveEditingId = DoCurveSelectionPopup (m_SelectedCurve);
                SetCurveVisible (curveEditingId);
                int mask = 1 << curveEditingId;
                bool active = (curves.activeFlag & mask) > 0;
                active = GUILayout.Toggle (active, EditorGUIUtility.TrTextContent ("Active"), EditorStyles.toolbarButton);
                if (active) curves.activeFlag |= mask;
                else curves.activeFlag &= (~mask);
                GUILayout.FlexibleSpace ();

                if (GUILayout.Button ("Reset", EditorStyles.toolbarButton)) {
                    curves.Reset (curveEditingId);
                }
            }

            // Curve area
            var rect = GUILayoutUtility.GetAspectRect (2f);
            var innerRect = new RectOffset (10, 10, 10, 10).Remove (rect);

            if (Event.current.type == EventType.Repaint) {
                // Background
                EditorGUI.DrawRect (rect, new Color (0.15f, 0.15f, 0.15f, 1f));

                if (curveEditingId == 4 || curveEditingId == 5)
                    DrawBackgroundTexture (innerRect, 0);
                else if (curveEditingId == 6 || curveEditingId == 7)
                    DrawBackgroundTexture (innerRect, 1);

                // Bounds
                Handles.color = Color.white * (GUI.enabled ? 1f : 0.5f);
                Handles.DrawSolidRectangleWithOutline (innerRect, Color.clear, new Color (0.8f, 0.8f, 0.8f, 0.5f));

                // Grid setup
                Handles.color = new Color (1f, 1f, 1f, 0.05f);
                int hLines = (int) Mathf.Sqrt (innerRect.width);
                int vLines = (int) (hLines / (innerRect.width / innerRect.height));

                // Vertical grid
                int gridOffset = Mathf.FloorToInt (innerRect.width / hLines);
                int gridPadding = ((int) (innerRect.width) % hLines) / 2;

                for (int i = 1; i < hLines; i++) {
                    var offset = i * Vector2.right * gridOffset;
                    offset.x += gridPadding;
                    Handles.DrawLine (innerRect.position + offset, new Vector2 (innerRect.x, innerRect.yMax - 1) + offset);
                }

                // Horizontal grid
                gridOffset = Mathf.FloorToInt (innerRect.height / vLines);
                gridPadding = ((int) (innerRect.height) % vLines) / 2;

                for (int i = 1; i < vLines; i++) {
                    var offset = i * Vector2.up * gridOffset;
                    offset.y += gridPadding;
                    Handles.DrawLine (innerRect.position + offset, new Vector2 (innerRect.xMax - 1, innerRect.y) + offset);
                }
            }

            // // Curve editor
            using (new GUI.ClipScope (innerRect)) {
                if (m_CurveEditor.OnGUI (new Rect (0, 0, innerRect.width - 1, innerRect.height - 1))) {
                    GUI.changed = true;
                    curves.GetTextureCurve (curveEditingId).SetDirty ();
                    m_Inspector.serializedObject.ApplyModifiedProperties ();
                }
            }

            if (Event.current.type == EventType.Repaint) {
                // Borders
                Handles.color = Color.black;
                Handles.DrawLine (new Vector2 (rect.x, rect.y - 20f), new Vector2 (rect.xMax, rect.y - 20f));
                Handles.DrawLine (new Vector2 (rect.x, rect.y - 21f), new Vector2 (rect.x, rect.yMax));
                Handles.DrawLine (new Vector2 (rect.x, rect.yMax), new Vector2 (rect.xMax, rect.yMax));
                Handles.DrawLine (new Vector2 (rect.xMax, rect.yMax), new Vector2 (rect.xMax, rect.y - 20f));

                bool editable = m_CurveEditor.GetCurveState (curvesArr[curveEditingId]).editable;
                string editableString = editable ? string.Empty : "(Not Overriding)\n";

                // Selection info
                var selection = m_CurveEditor.GetSelection ();
                var infoRect = innerRect;
                infoRect.x += 5f;
                infoRect.width = 100f;
                infoRect.height = 30f;

                if (s_PreLabel == null)
                    s_PreLabel = new GUIStyle ("ShurikenLabel");

                if (selection.curve != null && selection.keyframeIndex > -1) {
                    var key = selection.keyframe.Value;
                    GUI.Label (infoRect, $"{key.time:F3}\n{key.value:F3}", s_PreLabel);
                } else {
                    GUI.Label (infoRect, editableString, s_PreLabel);
                }
            }
        }
    }
}