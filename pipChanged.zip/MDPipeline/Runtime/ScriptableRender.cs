using System.Linq.Expressions;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.Rendering;
namespace CustomPipeline
{
    public sealed class ScriptableRender
    {
        CommandBuffer cmd;
        public Camera camera;
        public Camera[] cameras;
        public int mainLightIndex;
        public ScriptableRenderContext context;
        public ColorSpace colorSpace = ColorSpace.Linear;
        public RenderTargetHandle colorTarget => renderTargets[0];
        public RenderTargetHandle color1Target => renderTargets[1];
        public RenderTargetHandle depthTarget; //单独的深度buffer，避免draw call翻倍
        RenderTargetHandle backupTarget; //颜色双缓冲
        RenderTargetHandle[] renderTargets;//TODO: MRT单pass计算反射？
        RenderTargetIdentifier[] renderTargetIdentifiers;
        public List<ScriptablePass> PrePasses = new List<ScriptablePass>();
        public List<ScriptablePass> MainPasses = new List<ScriptablePass>(10);
        public List<ScriptablePass> UIPasses = new List<ScriptablePass>();
        static HashSet<RenderTargetHandle> TemporaryRTPool = new HashSet<RenderTargetHandle>();
        public bool SupportMRT = false;
        public bool SupportFrameBufferFetch = true;
        public bool SupportMSAA = false;

        public bool UseMRT = false;
        public bool UseFrameBufferFetch = false;
        public bool UseARGBHALF = false;

        public ScriptableRender()
        {
            colorSpace = ColorSpace.Linear;
            cmd = CommandBufferPool.Get(string.Empty);
            InitPasses();
        }
        //初始化pass,所有功能在此注册
        private void InitPasses()
        {
            PrePasses.Add(new DrawMainLightPass());
            PrePasses.Add(new DrawCharacterShadowPass());

            //线性空间
            MainPasses.Add (new DrawOpaquePass ());
            MainPasses.Add (new DrawAfterOpaquePass ()); //GPU实例等命令在此嵌入
            MainPasses.Add (new DrawSkyboxPass ());
            MainPasses.Add (new DrawOutlinePass ());
            MainPasses.Add (new CopyColorAndDepthPass());
            MainPasses.Add (new SSAOPass());
            MainPasses.Add(new CloudShadowPass());
            MainPasses.Add (new DrawTransparentPass ());
            MainPasses.Add(new DrawColorAdjustPass());
            MainPasses.Add (new DrawEffectPass ()); //调色不影响特效
            MainPasses.Add (new SunShaftPass());
            MainPasses.Add (new DrawBloomPass ());
            MainPasses.Add (new UberPass());
            MainPasses.Add (new DrawBeforeUIPass ()); //主要用于HUD

            //伽马空间
            UIPasses.Add(new DrawOnlyUIPass());

            foreach (var pass in PrePasses) pass.Init(this);
            foreach (var pass in MainPasses) pass.Init(this);
            foreach (var pass in UIPasses) pass.Init(this);
        }
        void Culling(ref ContextStatus status)
        {
            camera.TryGetCullingParameters(false, out status.cullingParameters); //不支持AR/XR
            status.cullingParameters.isOrthographic = camera.orthographic;
            status.cullingParameters.maximumVisibleLights = LightConstants.MaxVisibleLights;
            status.cullingParameters.shadowDistance = Mathf.Clamp(MDRenderPipeline.asset.shadowDistance, 0f, camera.farClipPlane);
            status.cullingResults = context.Cull(ref status.cullingParameters);
        }
        public void RenderingSingleCamera(Camera camera, ref ScriptableRenderContext context, ref ContextStatus status)
        {
            this.camera = camera;
            Culling(ref status);

            if (status.rendering3DScene)
            { //主要是阴影
                foreach (var pass in PrePasses) pass.SetupAndExcute(ref context, ref status);
            }
            SetupMatrices(ref status);
            SetupRenderTarget(ref status);
            if (status.rendering3DScene)
            { //3D场景,线性空间
                if (colorSpace != ColorSpace.Linear)
                {
                    FullScreenBlit(ref status, CoreUtils.sRGBToLinearBMat);
                    colorSpace = ColorSpace.Linear;
                }
                foreach (var pass in MainPasses) pass.SetupAndExcute(ref context, ref status);
            }
            if (status.renderingUI)
            {
                //UI在伽马空间(可选),且cullingMask仅为UI时不走MainPasses
                if (MDRenderPipeline.asset.gammaSpaceUI)
                {
                    if (colorSpace != ColorSpace.Gamma)
                    {
                        FullScreenBlit(ref status, CoreUtils.linearToSRGBMat);
                        colorSpace = ColorSpace.Gamma;
                    }
                }
                foreach (var pass in UIPasses) pass.SetupAndExcute(ref context, ref status);
            }
        }
        public void EndFrameRendering()
        {
            // context.Submit();
            // GL.sRGBWrite = false;//TODO: 节省最后上屏这次伽马-线性-伽马转换？
            var material = colorSpace == ColorSpace.Gamma ? CoreUtils.sRGBToLinearBMat : CoreUtils.blitMat;
            cmd.SetGlobalTexture(KeywordIds.blitTexId, colorTarget.Identifier());
            cmd.Blit(colorTarget.Identifier(), BuiltinRenderTextureType.CameraTarget, material); //线性下BuiltinRenderTextureType.CameraTarget始终是sRGB的。。。
            colorSpace = ColorSpace.Linear;

            foreach (var pass in PrePasses) pass.EndFrameRendering();
            foreach (var pass in MainPasses) pass.EndFrameRendering();
            foreach (var pass in UIPasses) pass.EndFrameRendering();

            depthTarget.ReleaseTemporaryRT(cmd);
            backupTarget.ReleaseTemporaryRT(cmd);
            for (var i = 0; i < renderTargets.Length; i++) renderTargets[i].ReleaseTemporaryRT(cmd);
            foreach (var rt in TemporaryRTPool) rt.ReleaseTemporaryRT(cmd);
            TemporaryRTPool.Clear();
            CommitCommandBuffer(cmd);
        }
        public void SetupMatrices(ref ContextStatus status)
        {
            context.SetupCameraProperties(camera); //remove this if we find out what's going on there...
            // MDRenderUtils.SetViewProjectionMatrices (cmd, status.viewMatrix, status.projectionMatrix);
            // cmd.SetViewport (status.pixelRect);
            // CommitCommandBuffer (cmd);
        }
        private void ResetRenderTargetHandle()
        {
            renderTargets = new RenderTargetHandle[]{
                new RenderTargetHandle(KeywordIds._ColorTarget0),
                new RenderTargetHandle(KeywordIds._ColorTarget1),
            };
            renderTargetIdentifiers = new RenderTargetIdentifier[]{
                renderTargets[0].Identifier(),
                renderTargets[1].Identifier()
            };
            depthTarget = new RenderTargetHandle(KeywordIds._DepthTarget);
            backupTarget = new RenderTargetHandle(KeywordIds._BackupTarget);
        }
        public void SetupRenderTarget(ref ContextStatus status)
        {
            //申请
            if (status.isBaseCamera)
            {
                ResetRenderTargetHandle();
                //颜色缓冲
                var colorDesc = status.targetDescriptor;
                colorTarget.GetTemporaryRT(cmd, ref colorDesc, FilterMode.Bilinear);
                //深度缓冲
                var depthDesc = status.targetDescriptor;
                depthDesc.depthBufferBits = 24;
                depthDesc.colorFormat = RenderTextureFormat.Depth;
                //depthDesc.bindMS = depthDesc.msaaSamples > 1 && !SystemInfo.supportsMultisampleAutoResolve && (SystemInfo.supportsMultisampledTextures != 0);
                depthTarget.GetTemporaryRT(cmd, ref depthDesc, FilterMode.Point);
                if (UseMRT)
                {
                    var MRTDesc = status.targetDescriptor;
                    MRTDesc.colorFormat = RenderTextureFormat.Depth;//TODO: 格式开放到面板设置
                    MRTDesc.memoryless = RenderTextureMemoryless.MSAA;
                    //depthDesc.msaaSamples = 1;
                    for (var i = 1; i < renderTargets.Length; i++) renderTargets[i].GetTemporaryRT(cmd, ref MRTDesc, FilterMode.Point);
                }
            }
            //设置
            if (UseMRT) cmd.SetRenderTarget(renderTargetIdentifiers, depthTarget.Identifier());
            else
            {
                cmd.SetRenderTarget
                (
                    colorTarget.Identifier(),
                    //注意非主相机在部分手机DontCare会花屏，必须Load
                    status.isBaseCamera ? RenderBufferLoadAction.DontCare : RenderBufferLoadAction.Load,
                    RenderBufferStoreAction.Store,
                    depthTarget.Identifier(),
                    RenderBufferLoadAction.DontCare,
                    RenderBufferStoreAction.Store
                );
            }
            //清理
            var flags = camera.clearFlags;
            cmd.ClearRenderTarget(
                flags <= CameraClearFlags.Depth, // if nothing =>  not clear
                flags == CameraClearFlags.Color, // if it is color =>  clear with color
                flags == CameraClearFlags.Color ? camera.backgroundColor.linear : Color.clear, 1f// transparent or color
            );
            CommitCommandBuffer(cmd);
        }

        public void ReSetRenderTarget(RenderBufferLoadAction loadAction = RenderBufferLoadAction.Load, RenderBufferStoreAction storeAction = RenderBufferStoreAction.Store, bool clearDepth = false, bool clearColor = false)
        {
            if (UseMRT) cmd.SetRenderTarget(renderTargetIdentifiers, depthTarget.Identifier());
            else cmd.SetRenderTarget(colorTarget.Identifier(), loadAction, storeAction, depthTarget.Identifier(), RenderBufferLoadAction.Load, RenderBufferStoreAction.Store);

            if (clearDepth || clearColor) cmd.ClearRenderTarget(clearDepth, clearColor, Color.clear);
            CommitCommandBuffer(cmd);
        }
        public void FullScreenBlit(ref ContextStatus status, Material material = null, int pass = 0)
        {
            if (material == null) material = CoreUtils.blitMat;
            var src = renderTargets[0];//暂时只提供MRT0的交换
            var desc = status.targetDescriptor;
            desc.msaaSamples = 1;
            backupTarget.GetTemporaryRT(cmd, ref desc, FilterMode.Bilinear);
            cmd.SetGlobalTexture(KeywordIds.blitTexId, src.Identifier());
            cmd.Blit(src.Identifier(), backupTarget.Identifier(), material, pass);

            renderTargets[0] = backupTarget;
            renderTargetIdentifiers[0] = backupTarget.Identifier();
            backupTarget = src;
            ReSetRenderTarget(); //及时重设深度缓冲
        }

        //临时RT申请，这种方式申请的RT会加入池中，帧结束时自动释放
        public void GetTemporaryRT(ref RenderTargetHandle handle, RenderTextureDescriptor descriptor, FilterMode filter = FilterMode.Bilinear)
        {
            handle.GetTemporaryRT(cmd, ref descriptor, filter);
            TemporaryRTPool.Add(handle);
            CommitCommandBuffer(cmd);
        }
        public RenderTargetHandle GetTemporaryRT(string name, RenderTextureDescriptor descriptor, FilterMode filter = FilterMode.Bilinear)
        {
            var handle = new RenderTargetHandle(name);
            handle.GetTemporaryRT(cmd, ref descriptor, filter);
            TemporaryRTPool.Add(handle);
            CommitCommandBuffer(cmd);
            return handle;
        }
        public RenderTargetHandle GetTemporaryRT(int nameId, RenderTextureDescriptor descriptor, FilterMode filter = FilterMode.Bilinear)
        {
            var handle = new RenderTargetHandle(nameId);
            handle.GetTemporaryRT(cmd, ref descriptor, filter);
            TemporaryRTPool.Add(handle);
            CommitCommandBuffer(cmd);
            return handle;
        }
        public void CommitCommandBuffer(CommandBuffer command, bool isClear = true)
        {
            context.ExecuteCommandBuffer(command);
            if (isClear) command.Clear();
        }
        public void Dispose()
        {
            foreach (var pass in PrePasses) pass.Dispose();
            foreach (var pass in MainPasses) pass.Dispose();
            foreach (var pass in UIPasses) pass.Dispose();
            PrePasses.Clear();
            MainPasses.Clear();
            UIPasses.Clear();
            CommandBufferPool.Release(cmd);
        }
    }
}