﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CustomPipeline
{
    public class PostProcessManager 
    {
        static readonly Lazy<PostProcessManager> s_Instance = new Lazy<PostProcessManager>(() => new PostProcessManager());
        public static PostProcessManager instance => s_Instance.Value;
        public Dictionary<int, CameraPostProcess> m_CameraMap = new Dictionary<int, CameraPostProcess>();
        public void Register(CameraPostProcess cpp)
        {
            if (!cpp.camera)
                return;
            m_CameraMap.Add(cpp.camera.GetHashCode(), cpp);
        }

        public void Unregister(CameraPostProcess cpp)
        {
            m_CameraMap.Remove(cpp.camera.GetHashCode());
        }

        public void GetCameraPostProcess(Camera camera,out CameraPostProcess cpp)
        {
            m_CameraMap.TryGetValue(camera.GetHashCode(),out cpp);
        }
    }
}

