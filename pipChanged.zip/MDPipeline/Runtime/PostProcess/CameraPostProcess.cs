﻿using UnityEngine;

namespace CustomPipeline
{
    [ExecuteInEditMode]
    public class CameraPostProcess : MonoBehaviour
    {
        [SerializeField]
        public MDPipelineEffectProfile profile;

        Camera m_Camera;
        public Camera camera
        {
            get { return m_Camera; }
        }

        void OnEnable()
        {
            m_Camera = GetComponent<Camera>();
            PostProcessManager.instance.Register(this);
        }

        void OnDisable()
        {
            PostProcessManager.instance.Unregister(this);
        }
    }
}
