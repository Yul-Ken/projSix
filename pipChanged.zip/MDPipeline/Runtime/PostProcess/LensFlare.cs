using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace CustomPipeline
{
    [ExecuteInEditMode]
    [RequireComponent(typeof(MeshRenderer))]
    [RequireComponent(typeof(MeshFilter))]
    public class LensFlare : MonoBehaviour
    {
        [SerializeField, HideInInspector]
        MeshRenderer m_MeshRenderer;
        [SerializeField, HideInInspector]
        MeshFilter m_MeshFilter;
        [SerializeField]
        Light m_Light;
        [SerializeField]
        Material m_Mat;

        [Header("Global Settings")]
        public float OcclusionRadius = 1.0f;
        public float NearFadeStartDistance = 1.0f;
        public float NearFadeEndDistance = 3.0f;
        public float FarFadeStartDistance = 10.0f;
        public float FarFadeEndDistance = 50.0f;
        [Range(1, 5)]
        public int SliceCount = 2;

        int _WorldPosRadiusId = Shader.PropertyToID("_WorldPosRadius");
        int _FadeDataId = Shader.PropertyToID("_FadeData");
        [Header("Flare Element Settings")]
        [SerializeField]
        public List<FlareSettings> Flares;

        void Awake()
        {
            if (m_MeshFilter == null)
                m_MeshFilter = GetComponent<MeshFilter>();
            if (m_MeshRenderer == null)
                m_MeshRenderer = GetComponent<MeshRenderer>();

            m_Light = GetComponent<Light>();

            m_MeshFilter.hideFlags = HideFlags.None;
            m_MeshRenderer.hideFlags = HideFlags.None;

            if (Flares == null)
                Flares = new List<FlareSettings>();

            m_MeshFilter.mesh = InitMesh();
        }

        void OnEnable()
        {
            UpdateGeometry();
        }


        // Use this for initialization
        void Start()
        {
            m_Light = GetComponent<Light>();
        }

        void OnValidate()
        {
            UpdateGeometry();
            UpdateMaterials();
        }

        // Update is called once per frame
        void Update()
        {
            // Lazy!
            if (m_Light)
                transform.position = Camera.main.transform.position - m_Light.transform.forward * 10f;
            UpdateVaryingAttributes();
        }

        Mesh InitMesh()
        {
            Mesh m = new Mesh();
            m.MarkDynamic();
            return m;
        }

        void UpdateMaterials()
        {
            //Material[] mats = new Material[Flares.Count];

            //int i = 0;
            //foreach (FlareSettings f in Flares)
            //{
            //    mats[i] = f.Material;
            //    break;
            //    i++;
            //}
            m_MeshRenderer.sharedMaterial = m_Mat;
        }

        void UpdateGeometry()
        {
            Mesh m = m_MeshFilter.sharedMesh;

            // Positions
            List<Vector3> vertices = new List<Vector3>();
            m.subMeshCount = 1;
            foreach (FlareSettings s in Flares)
            {
                vertices.Add(new Vector3(-1, -1, 0));
                vertices.Add(new Vector3(1, -1, 0));
                vertices.Add(new Vector3(1, 1, 0));
                vertices.Add(new Vector3(-1, 1, 0));
            }
            m.SetVertices(vertices);
            //m.vertices = vertices.ToArray();
            //Debug.LogError(string.Format("updateGeometry 111111111111   :{0} , flarelen : {1}", m.vertices.Length, vertices.Count));
            // UVs
            List<Vector2> uvs = new List<Vector2>();
            float sliceSize = 1.0f / SliceCount;
            foreach (FlareSettings s in Flares)
            {
                float uvY = Mathf.Floor(s.uvIndex / SliceCount) * sliceSize;
                float uvX = (s.uvIndex % SliceCount) * sliceSize;
                uvs.Add(new Vector2(uvX, uvY + sliceSize));
                uvs.Add(new Vector2(uvX + sliceSize, uvY + sliceSize));
                uvs.Add(new Vector2(uvX + sliceSize, uvY));
                uvs.Add(new Vector2(uvX, uvY));
            }
            m.SetUVs(0, uvs);

            // Variable Data
            m.SetColors(GetLensFlareColor());
            m.SetUVs(1, GetLensFlareData());
            m.SetUVs(2, GetLensFlareSize());
            //m.SetUVs(2, GetWorldPositionAndRadius());
            //m.SetUVs(3, GetDistanceFadeData());


            int[] tris = new int[6 * Flares.Count];
            // Tris
            for (int i = 0; i < Flares.Count; i++)
            {
                int start = i * 6;
                //int[] tris = new int[6];
                tris[0 + start] = (i * 4) + 0;
                tris[1 + start] = (i * 4) + 1;
                tris[2 + start] = (i * 4) + 2;
                tris[3 + start] = (i * 4) + 2;
                tris[4 + start] = (i * 4) + 3;
                tris[5 + start] = (i * 4) + 0;
                //m.SetTriangles(tris, i);
            }
            m.SetTriangles(tris, 0);
            Bounds b = m.bounds;
            b.extents = new Vector3(OcclusionRadius, OcclusionRadius, OcclusionRadius);
            m.bounds = b;
            m.UploadMeshData(false);
            //Debug.LogError(string.Format("updateGeometry 22222222222:{0}",m.vertices.Length));
        }

        void UpdateVaryingAttributes()
        {
            Mesh m = m_MeshFilter.sharedMesh;
            //Debug.LogError(string.Format("vlen:{0}", m.vertices.Length));
            m.SetColors(GetLensFlareColor());
            m.SetUVs(1, GetLensFlareData());//   RayPosition    Rotation   width height
            m.SetUVs(2, GetLensFlareSize());
            //m.SetUVs(2, GetWorldPositionAndRadius());//pos      �ڵ��뾶
            //m.SetUVs(3, GetDistanceFadeData());
            if (m_Mat)
            {
                Vector3 pos = transform.position;
                m_Mat.SetVector(_WorldPosRadiusId, new Vector4(pos.x, pos.y, pos.z, OcclusionRadius));
                m_Mat.SetVector(_FadeDataId, new Vector4(NearFadeStartDistance, NearFadeEndDistance, FarFadeStartDistance, FarFadeEndDistance));

            }
            Bounds b = m.bounds;
            b.extents = new Vector3(OcclusionRadius, OcclusionRadius, OcclusionRadius);
            m.bounds = b;
            m.name = "LensFlare (" + gameObject.name + ")";
        }

        List<Color> GetLensFlareColor()
        {
            List<Color> colors = new List<Color>();
            foreach (FlareSettings s in Flares)
            {
                Color c = (s.MultiplyByLightColor && m_Light != null) ? s.Color * m_Light.color * m_Light.intensity : s.Color;

                colors.Add(c);
                colors.Add(c);
                colors.Add(c);
                colors.Add(c);
            }
            //Debug.LogError(string.Format("color len:{0}", colors.Count));
            return colors;
        }

        List<Vector2> GetLensFlareData()
        {
            List<Vector2> lfData = new List<Vector2>();

            foreach (FlareSettings s in Flares)
            {
                Vector2 data = new Vector2(s.RayPosition, s.AutoRotate ? -1 : Mathf.Abs(s.Rotation));
                lfData.Add(data); lfData.Add(data); lfData.Add(data); lfData.Add(data);
            }
            return lfData;
        }
        List<Vector2> GetLensFlareSize()
        {
            List<Vector2> lfData = new List<Vector2>();

            foreach (FlareSettings s in Flares)
            {
                Vector2 data = new Vector2(s.Size.x, s.Size.y);
                lfData.Add(data); lfData.Add(data); lfData.Add(data); lfData.Add(data);
            }
            return lfData;
        }
        List<Vector4> GetDistanceFadeData()
        {
            List<Vector4> fadeData = new List<Vector4>();

            foreach (FlareSettings s in Flares)
            {
                Vector4 data = new Vector4(NearFadeStartDistance, NearFadeEndDistance, FarFadeStartDistance, FarFadeEndDistance);
                fadeData.Add(data); fadeData.Add(data); fadeData.Add(data); fadeData.Add(data);
            }
            return fadeData;
        }


        List<Vector4> GetWorldPositionAndRadius()
        {
            List<Vector4> worldPos = new List<Vector4>();
            Vector3 pos = transform.position;
            Vector4 value = new Vector4(pos.x, pos.y, pos.z, OcclusionRadius);
            foreach (FlareSettings s in Flares)
            {
                worldPos.Add(value); worldPos.Add(value); worldPos.Add(value); worldPos.Add(value);
            }

            return worldPos;
        }

        void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(1, 0, 0, 0.3f);
            Gizmos.DrawSphere(transform.position, OcclusionRadius);
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, OcclusionRadius);
        }

        [System.Serializable]
        public class FlareSettings
        {
            public float RayPosition;
            //public Material Material;
            [ColorUsage(true, true)]
            public Color Color;
            public bool MultiplyByLightColor;
            public Vector2 Size;
            public float Rotation;
            public bool AutoRotate;
            public int uvIndex;

            public FlareSettings()
            {
                RayPosition = 0.0f;
                Color = Color.white;
                MultiplyByLightColor = true;
                Size = new Vector2(0.3f, 0.3f);
                Rotation = 0.0f;
                AutoRotate = false;
                uvIndex = 0;
            }
        }
    }
}