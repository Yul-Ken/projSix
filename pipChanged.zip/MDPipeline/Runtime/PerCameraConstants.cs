using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public class PerCameraConstants
    {
        //相机固有属性，每相机更新一次
        static int _InvCameraViewProj = Shader.PropertyToID("_InvCameraViewProj");
        static int _ScreenParams = Shader.PropertyToID("_ScreenParams");
        static int _ScaledScreenParams = Shader.PropertyToID("_ScaledScreenParams");
        static int _WorldSpaceCameraPos = Shader.PropertyToID("_WorldSpaceCameraPos");
        static int _ZBufferParams = Shader.PropertyToID("_ZBufferParams");
        static int unity_OrthoParams = Shader.PropertyToID("unity_OrthoParams");
        static int _ProjectionParams = Shader.PropertyToID("_ProjectionParams"); //todo: 暂未设置

        static int unity_CameraProjection = Shader.PropertyToID("unity_CameraProjection");
        static int unity_CameraInvProjection = Shader.PropertyToID("unity_CameraInvProjection");
        static int unity_WorldToCamera = Shader.PropertyToID("unity_WorldToCamera");
        static int unity_CameraToWorld = Shader.PropertyToID("unity_CameraToWorld");

        //渲染用属性，可能每pass更新，例如渲阴影或全屏Blit的时候

        public static int viewMatrix = Shader.PropertyToID("unity_MatrixV");
        public static int projectionMatrix = Shader.PropertyToID("glstate_matrix_projection");
        public static int viewAndProjectionMatrix = Shader.PropertyToID("unity_MatrixVP");

        public static int inverseViewMatrix = Shader.PropertyToID("unity_MatrixInvV");
        public static int inverseProjectionMatrix = Shader.PropertyToID("unity_MatrixInvP");
        public static int inverseViewAndProjectionMatrix = Shader.PropertyToID("unity_MatrixInvVP");

        public static void Update(Camera camera, ref ContextStatus status)
        {
            Rect pixelRect = camera.pixelRect;
            float scaledCameraWidth = (float)pixelRect.width * MDRenderPipeline.asset.renderScale;
            float scaledCameraHeight = (float)pixelRect.height * MDRenderPipeline.asset.renderScale;
            Shader.SetGlobalVector(_ScaledScreenParams, new Vector4(scaledCameraWidth, scaledCameraHeight, 1.0f + 1.0f / scaledCameraWidth, 1.0f + 1.0f / scaledCameraHeight));
            Shader.SetGlobalVector(_WorldSpaceCameraPos, camera.transform.position);
            float cameraWidth = (float)pixelRect.width;
            float cameraHeight = (float)pixelRect.height;
            Shader.SetGlobalVector(_ScreenParams, new Vector4(cameraWidth, cameraHeight, 1.0f + 1.0f / cameraWidth, 1.0f + 1.0f / cameraHeight));

            float near = camera.nearClipPlane;
            float far = camera.farClipPlane;
            float invNear = Mathf.Approximately(near, 0.0f) ? 0.0f : 1.0f / near;
            float invFar = Mathf.Approximately(far, 0.0f) ? 0.0f : 1.0f / far;
            float isOrthographic = camera.orthographic ? 1.0f : 0.0f;
            float zc0 = 1.0f - far * invNear;
            float zc1 = far * invNear;
            Vector4 zBufferParams = new Vector4(zc0, zc1, zc0 * invFar, zc1 * invFar);
            if (SystemInfo.usesReversedZBuffer)
            {
                zBufferParams.y += zBufferParams.x;
                zBufferParams.x = -zBufferParams.x;
                zBufferParams.w += zBufferParams.z;
                zBufferParams.z = -zBufferParams.z;
            }
            Shader.SetGlobalVector(_ZBufferParams, zBufferParams);
            Vector4 projectionParams = new Vector4(1, near, far, 1.0f * invFar);
            Shader.SetGlobalVector(_ProjectionParams, projectionParams);
            Matrix4x4 projMatrix = camera.projectionMatrix;
            Matrix4x4 viewMatrix = camera.worldToCameraMatrix;
            Matrix4x4 viewProjMatrix = projMatrix * viewMatrix;
            Matrix4x4 invViewProjMatrix = Matrix4x4.Inverse(viewProjMatrix);
            Shader.SetGlobalMatrix(_InvCameraViewProj, invViewProjMatrix);

            Vector4 orthoParams = new Vector4(camera.orthographicSize * (cameraWidth / cameraHeight), camera.orthographicSize, 0.0f, isOrthographic);
            Shader.SetGlobalVector(unity_OrthoParams, orthoParams);

            // There's an inconsistency in handedness between unity_matrixV and unity_WorldToCamera
            // Unity changes the handedness of unity_WorldToCamera (see Camera::CalculateMatrixShaderProps)
            // we will also change it here to avoid breaking existing shaders. (case 1257518)
            Matrix4x4 worldToCameraMatrix = Matrix4x4.Scale(new Vector3(1.0f, 1.0f, -1.0f)) * status.viewMatrix;
            Matrix4x4 cameraToWorldMatrix = worldToCameraMatrix.inverse;
            Shader.SetGlobalMatrix(unity_WorldToCamera, worldToCameraMatrix); //注意与unity_MatrixV等的区别
            Shader.SetGlobalMatrix(unity_CameraToWorld, cameraToWorldMatrix);
        }
    }
}