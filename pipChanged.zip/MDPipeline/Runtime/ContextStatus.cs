using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public struct ContextStatus
    {
        public bool needReBuildLut;
        public bool isBaseCamera;
        public bool rendering3DScene;
        public bool renderingUI;
        public Rect pixelRect;
        public int mainLightIndex;
        public int additionalLightsCount;
        public Matrix4x4 viewMatrix;
        public Matrix4x4 projectionMatrix;
        public CullingResults cullingResults;
        public MDPipelineEffectProfile effectSetting;
        public ScriptableCullingParameters cullingParameters;
        public RenderTextureDescriptor targetDescriptor;

        public RenderTargetIdentifier bloomRTId;
        public RenderTargetIdentifier sunShaftRtId;
    }
}