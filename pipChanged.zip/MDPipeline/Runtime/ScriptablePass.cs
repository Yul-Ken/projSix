using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

// Background : 1000 - 0 - 1499 = Background
// Geometry : 2000 - 1500 - 2399 = Geometry
// AlphaTest : 2450 - 2400 - 2699 = AlphaTest
// Transparent: 3000 - 2700 - 3599 = Transparent
// Overlay : 4000 - 3600 - 5000 = Overlay

namespace CustomPipeline
{
    public abstract class ScriptablePass
    {
        string profilingSampleName;
        protected CommandBuffer cmd;
        protected ScriptableRender renderer;
        public void Init(ScriptableRender scriptableRender)
        {
            this.renderer = scriptableRender;
            profilingSampleName = GetType().Name;//TODO: 去反射
            cmd = CommandBufferPool.Get(string.Empty);
        }
        ~ScriptablePass()
        {
            CommandBufferPool.Release(cmd);
            renderer = null;
            cmd = null;
        }
        public void SetupAndExcute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            using (new ProfilingScope(renderer, profilingSampleName))
            {
                Excute(ref context, ref status); //主要命令在此填充
                renderer.CommitCommandBuffer(cmd);
            }
        }
        public void EndFrameRendering()
        {
            FrameCleanup();
            renderer.CommitCommandBuffer(cmd);
        }
        protected void SetRenderTarget(RenderTargetIdentifier target, RenderBufferLoadAction loadAction, RenderBufferStoreAction storeAction, bool clearDepth, bool clearColor, Color color)
        {
            cmd.SetRenderTarget(target, loadAction, storeAction);
            if (clearDepth || clearColor) cmd.ClearRenderTarget(clearDepth, clearColor, color);
            renderer.CommitCommandBuffer(cmd);
        }
        protected void SetRenderTarget(RenderTargetIdentifier target, RenderBufferLoadAction loadAction, RenderBufferStoreAction storeAction, bool clearDepth = false, bool clearColor = false)
        {
            cmd.SetRenderTarget(target, loadAction, storeAction);
            if (clearDepth || clearColor) cmd.ClearRenderTarget(clearDepth, clearColor, Color.clear);
            renderer.CommitCommandBuffer(cmd);
        }
        protected void Blit(RenderTargetIdentifier src, RenderTargetIdentifier dst, Material material = null, int pass = 0, bool resetMatrice = true)
        {
            cmd.SetGlobalTexture(KeywordIds.blitTexId, src);
            cmd.Blit(src, dst, material, pass);
            /////////////////////////注意：以下DrawMesh替代blit的方法在部分手机花屏///////////////////////////
            // if (material == null) material = MDRenderUtils.blitMat;
            // cmd.SetRenderTarget (dst, RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
            // cmd.SetViewProjectionMatrices (Matrix4x4.identity, Matrix4x4.identity);
            // cmd.SetGlobalTexture (MDRenderUtils.blitTexId, src);
            // cmd.DrawMesh (MDRenderUtils.fullscreenMesh, Matrix4x4.identity, material, 0, pass);
            // if (resetMatrice) cmd.SetViewProjectionMatrices (data.viewMatrix, data.projectionMatrix); //恢复相机矩阵
            renderer.CommitCommandBuffer(cmd);
        }
        protected DrawingSettings CreateDrawingSetting(ref ShaderTagId shaderTagId, ref SortingCriteria sortingCriteria, PerObjectData perObjectData = PerObjectData.None)
        {
            SortingSettings sortSetting = new SortingSettings(renderer.camera) { criteria = sortingCriteria };
            DrawingSettings drawSetting = new DrawingSettings(shaderTagId, sortSetting)
            {
                perObjectData = perObjectData,
                mainLightIndex = renderer.mainLightIndex,
                enableDynamicBatching = MDRenderPipeline.asset.supportsDynamicBatching,
                enableInstancing = true
            };
            return drawSetting;
        }
        protected DrawingSettings CreateDrawingSetting(List<ShaderTagId> shaderTagIds, ref SortingCriteria sortingCriteria, PerObjectData perObjectData = PerObjectData.None)
        {
            SortingSettings sortSetting = new SortingSettings(renderer.camera) { criteria = sortingCriteria };
            DrawingSettings drawSetting = new DrawingSettings(shaderTagIds[0], sortSetting)
            {
                perObjectData = perObjectData,
                mainLightIndex = renderer.mainLightIndex,
                enableDynamicBatching = MDRenderPipeline.asset.supportsDynamicBatching,
                enableInstancing = true
            };
            for (var i = 1; i < shaderTagIds.Count; i++) drawSetting.SetShaderPassName(i, shaderTagIds[i]);
            return drawSetting;
        }
        //继承此类必须实现此函数，用cmd变量记录相应命令即可，之后会自动提交
        public abstract void Excute(ref ScriptableRenderContext context, ref ContextStatus status);
        //此函数非必须实现，一般用于帧结束时的清理工作
        public virtual void FrameCleanup() { }
        //此函数非必须实现，一般用于管线销毁时的清理工作
        public virtual void Dispose() { }
    }
}