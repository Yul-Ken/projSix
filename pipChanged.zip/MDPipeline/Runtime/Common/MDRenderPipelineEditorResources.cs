﻿using System;
using UnityEngine;
using UnityEngine.Scripting.APIUpdating;

namespace CustomPipeline
{
    public class MDRenderPipelineEditorResources : ScriptableObject
    {
        [Serializable, ReloadGroup]
        public sealed class ShaderResources
        {
            [Reload("Shader/EditorShader/Terrain/TerrainDetailLit.shader")]
            public Shader terrainDetailLitPS;

            [Reload("Shader/EditorShader/Terrain/WavingGrass.shader")]
            public Shader terrainDetailGrassPS;

            [Reload("Shader/EditorShader/Terrain/WavingGrassBillboard.shader")]
            public Shader terrainDetailGrassBillboardPS;
        }

        [Serializable, ReloadGroup]
        public sealed class MaterialResources
        {
            [Reload("Shader/Materials/TerrainLit.mat")]
            public Material terrainLit;
        }

        public ShaderResources shaders;
        public MaterialResources materials;
    }
}
