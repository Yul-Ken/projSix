using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using UnityEngine;

namespace CustomPipeline
{

    public partial class KeywordIds
    {
        public static readonly int _ColorTarget0 = Shader.PropertyToID(KeywordStrings._ColorTarget0);
        public static readonly int _ColorTarget1 = Shader.PropertyToID(KeywordStrings._ColorTarget1);
        public static readonly int _ColorTarget2 = Shader.PropertyToID(KeywordStrings._ColorTarget2);
        public static readonly int _BackupTarget = Shader.PropertyToID(KeywordStrings._BackupTarget);
        public static readonly int _DepthTarget = Shader.PropertyToID(KeywordStrings._DepthTarget);
        public static readonly int blitTexId = Shader.PropertyToID(KeywordStrings._BlitTex);
        public static int _ShadowBiasId = Shader.PropertyToID(KeywordStrings._ShadowBias);
        public static int _LightDirectionId = Shader.PropertyToID(KeywordStrings._LightDirection);
        public static readonly int uiLayer = 1 << LayerMask.NameToLayer(KeywordStrings.UI);
        public static readonly int exceptUILayer = ~KeywordIds.uiLayer;
        public static readonly int hudLayer = 1 << LayerMask.NameToLayer(KeywordStrings.HUD);
        public static readonly int particleLayer = 1 << LayerMask.NameToLayer(KeywordStrings.Particle);
    }
    public static class KeywordStrings
    {
        public static readonly string MDRenderer = "MDRenderer";
        public static readonly string _InternalLut = "_InternalLut";
        public static readonly string _ColorTarget0 = "_ColorTarget0";
        public static readonly string _ColorTarget1 = "_ColorTarget1";
        public static readonly string _ColorTarget2 = "_ColorTarget2";
        public static readonly string _BackupTarget = "_BackupTarget";
        public static readonly string _DepthTarget = "_DepthTarget";
        public static readonly string _CameraOpaqueTexture = "_CameraOpaqueTexture";
        public static readonly string _CameraDepthTexture = "_CameraDepthTexture";
        public static readonly string _CharacterShadowMap = "_CharacterShadowMap";
        public static readonly string _CharacterShadowMapSize = "_CharacterShadowMapSize";
        public static readonly string _WorldToCharacterLight = "_WorldToCharacterLight";
        public static readonly string _MainLightShadowmapTexture = "_MainLightShadowmapTexture";
        public static readonly string _BlitTex = "_BlitTex";
        public static readonly string ShadowCaster = "ShadowCaster";
        public static readonly string CharacterShadowCaster = "CharacterShadowCaster";
        public static readonly string UniversalForward = "UniversalForward";
        public static readonly string SRPDefaultUnlit = "SRPDefaultUnlit"; //默认shader tag
        public static readonly string ToonOutline = "ToonOutline";
        public static readonly string Always = "Always";
        public static readonly string UI = "UI";
        public static readonly string HUD = "HUD";
        public static readonly string Particle = "Particle";
        public static readonly string _TONEMAP_ACES = "_TONEMAP_ACES";
        public static readonly string MainLightShadows = "_MAIN_LIGHT_SHADOWS";
        public static readonly string MainLightShadowCascades = "_MAIN_LIGHT_SHADOWS_CASCADE";
        public static readonly string SoftShadows = "_SHADOWS_SOFT";
        public static readonly string AdditionalLightsVertex = "_ADDITIONAL_LIGHTS_VERTEX";
        public static readonly string AdditionalLightsPixel = "_ADDITIONAL_LIGHTS";
        public static readonly string _ShadowBias = "_ShadowBias";
        public static readonly string _LightDirection = "_LightDirection";

        public static readonly string MixedLightingShadowmask = "_MIXED_LIGHTING_SHADOWMASK";
        public static readonly string ShadowMask = "SHADOWS_SHADOWMASK"; 

        public static readonly string BLOOM_ENABLE = "BLOOM_ENABLE";
        public static readonly string SUNSHAFT_ENABLE = "SUNSHAFT_ENABLE";
        public static readonly string DepthNoMsaa = "_DEPTH_NO_MSAA";
        public static readonly string DepthMsaa2 = "_DEPTH_MSAA_2";
        public static readonly string DepthMsaa4 = "_DEPTH_MSAA_4";
        public static readonly string FXAA = "FXAA";
    }
}