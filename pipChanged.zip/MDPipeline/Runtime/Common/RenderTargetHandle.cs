using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public struct RenderTargetHandle
    {
        public int id { set; get; }
        public RenderTexture rt;
        public bool isActive;
        public static readonly RenderTargetHandle CameraTarget = new RenderTargetHandle() { id = -1, rt = null, isActive = true };
        public RenderTargetHandle(string Name)
        {
            if (string.IsNullOrEmpty(Name)) Debug.LogError("RenderTargetHandle must have a name!");
            id = Shader.PropertyToID(Name);
            rt = null;
            isActive = false;
        }
        public RenderTargetHandle(int nameId)
        {
            id = nameId;
            rt = null;
            isActive = false;
        }
        public RenderTargetHandle(RenderTexture texture)
        {
            if (string.IsNullOrEmpty(texture.name)) Debug.LogError("the texture must have a name while create RenderTargetHandle by it!");
            id = Shader.PropertyToID(texture.name);
            rt = texture;
            isActive = true;
        }
        public void GetTemporaryRT(CommandBuffer command, ref RenderTextureDescriptor descriptor, FilterMode filter = FilterMode.Bilinear)
        {
            if (rt) return;
            if (!isActive)
            {
                //部分参数不正确的descriptor使用此API,打开FrameDebug面板时会内存暴涨,见MDRenderUtils.CreatRenderTextureDescriptor()函数
                command.GetTemporaryRT(id, descriptor, filter);
                // command.GetTemporaryRT (
                //     id, descriptor.width, descriptor.height, descriptor.depthBufferBits, filter, descriptor.colorFormat,
                //     descriptor.sRGB ? RenderTextureReadWrite.sRGB : RenderTextureReadWrite.Linear,
                //     descriptor.msaaSamples, false
                // );
            }
            isActive = true;
        }
        public void ReleaseTemporaryRT(CommandBuffer command)
        {
            if (rt) return;
            if (isActive) command.ReleaseTemporaryRT(id);
            isActive = false;
        }
        public void ReleaseRenderTexture()
        {
            if (!rt) return;
            if (isActive) RenderTexture.ReleaseTemporary(rt);
            rt = null;
            isActive = false;
        }
        public RenderTargetIdentifier Identifier()
        {
            if (id == -1) return BuiltinRenderTextureType.CameraTarget;
            if (rt) return new RenderTargetIdentifier(rt);
            return new RenderTargetIdentifier(id);
        }
        public bool Equals(RenderTargetHandle other)
        {
            if (rt) return rt == other.rt;
            return id == other.id;
        }
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is RenderTargetHandle && Equals((RenderTargetHandle)obj);
        }
        public override int GetHashCode()
        {
            return id;
        }
        public static bool operator ==(RenderTargetHandle c1, RenderTargetHandle c2)
        {
            return c1.Equals(c2);
        }
        public static bool operator !=(RenderTargetHandle c1, RenderTargetHandle c2)
        {
            return !c1.Equals(c2);
        }
    }
}