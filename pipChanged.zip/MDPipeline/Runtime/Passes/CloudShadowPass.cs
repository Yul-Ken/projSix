using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    internal class CloudShadowPass : ScriptablePass {
        const string rtName = "cloudShadowRt";
        RenderTargetHandle ssaoRt;
        int _FrustumCornersRay = Shader.PropertyToID("_FrustumCornersRay");
        int _CloudFactor = Shader.PropertyToID("_CloudFactor");
        int _CloudTex = Shader.PropertyToID("_CloudTex");
        int _CloudShadowTex = Shader.PropertyToID("_CloudShadowTex");
        int _ShadowColor = Shader.PropertyToID("_ShadowColor");
        int _CloudShadowIntensity = Shader.PropertyToID("_CloudShadowIntensity");
        private Camera currentCamera = null;
        
       
        public CloudShadowPass() {
            
        }
       
        void CalculateFrustumCornersRay(Camera camera, Material mat)
        {
            Matrix4x4 frustumCorners = Matrix4x4.identity;

            float fov = camera.fieldOfView;
            float near = camera.nearClipPlane;
            float aspect = camera.aspect;
            Transform cameraTransform = camera.transform;
            float halfHeight = near * Mathf.Tan(fov * 0.5f * Mathf.Deg2Rad);
            Vector3 toRight = cameraTransform.right * halfHeight * aspect;
            Vector3 toTop = cameraTransform.up * halfHeight;

            Vector3 topLeft = cameraTransform.forward * near + toTop - toRight;
            float scale = topLeft.magnitude / near;

            topLeft.Normalize();
            topLeft *= scale;

            Vector3 topRight = cameraTransform.forward * near + toRight + toTop;
            topRight.Normalize();
            topRight *= scale;

            Vector3 bottomLeft = cameraTransform.forward * near - toTop - toRight;
            bottomLeft.Normalize();
            bottomLeft *= scale;

            Vector3 bottomRight = cameraTransform.forward * near + toRight - toTop;
            bottomRight.Normalize();
            bottomRight *= scale;

            frustumCorners.SetRow(0, bottomLeft);
            frustumCorners.SetRow(1, bottomRight);
            frustumCorners.SetRow(2, topRight);
            frustumCorners.SetRow(3, topLeft);

            mat.SetMatrix("_FrustumCornersRay", frustumCorners);
            
        }
        public override void Excute (ref ScriptableRenderContext context, ref ContextStatus status) {
            if (status.effectSetting == null || !status.effectSetting.cloudShadowEnable ) return;
#if UNITY_EDITOR
            if (renderer.camera.cameraType == CameraType.SceneView)
                return;
#endif

            Texture cloudTex = status.effectSetting.cloudShadowTex;
            ssaoRt = new RenderTargetHandle(rtName);
            var descriptor = status.targetDescriptor;
            descriptor.msaaSamples = 1;
            descriptor.colorFormat = RenderTextureFormat.R8;
            descriptor.memoryless = RenderTextureMemoryless.None;
            descriptor.width = descriptor.width >> status.effectSetting.cloudShadowDownSample;
            descriptor.height = descriptor.height >> status.effectSetting.cloudShadowDownSample;
            ssaoRt.GetTemporaryRT(cmd, ref descriptor);
            //MDRenderUtils.ssaoMat
            Material mat = CoreUtils.cloudShaodwMat;
            Camera currentCamera = renderer.camera;
            CalculateFrustumCornersRay(renderer.camera,mat);
            mat.SetTexture(_CloudTex, cloudTex);
            mat.SetFloat(_CloudShadowIntensity, status.effectSetting.cloudShadowIntensity);
            mat.SetColor(_ShadowColor, status.effectSetting.cloudShadowColor);
            float t = Time.time;
            mat.SetVector(_CloudFactor, new Vector4(
                status.effectSetting.cloudShadowUVSpeed.x * t
                , status.effectSetting.cloudShadowUVSpeed.y * t
                , status.effectSetting.cloudShadowUVTiling.x
                , status.effectSetting.cloudShadowUVTiling.y));

            Blit(renderer.colorTarget.Identifier(), ssaoRt.Identifier(), mat, 0);
            cmd.SetGlobalTexture(_CloudShadowTex, ssaoRt.Identifier());
            renderer.FullScreenBlit(ref status, mat, 1);
            
           
        }

        public override void FrameCleanup()
        {
            ssaoRt.ReleaseTemporaryRT(cmd);
        }

    }
}