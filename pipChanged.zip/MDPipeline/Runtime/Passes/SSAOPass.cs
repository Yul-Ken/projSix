using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    internal class SSAOPass : ScriptablePass {
        const string rtName = "ssaoRt";
        const string tempRtName = "ssaoTempRt";
        RenderTargetHandle ssaoRt;
        int _NoiseTexId = Shader.PropertyToID("_NoiseTex");
        int _HeightId = Shader.PropertyToID("Height");
        int _WidthId = Shader.PropertyToID("Width");
        int _InverseProjectionMatrixId = Shader.PropertyToID("_InverseProjectionMatrix");
        int _SampleKernelArrayId = Shader.PropertyToID("_SampleKernelArray");
        int _SampleKernelCountId = Shader.PropertyToID("_SampleKernelCount");
        int _SampleKeneralRadiusId = Shader.PropertyToID("_SampleKeneralRadius");
        int _AOTexId = Shader.PropertyToID("_AOTex");

        #region HBAO
        int _ScreenToViewId = Shader.PropertyToID("_ScreenToView");
        int radiusID = Shader.PropertyToID("_Radius");
        int maxRadiusPixelsID = Shader.PropertyToID("_MaxRadiusPixels");
        int biasID = Shader.PropertyToID("_AngleBias");
        int aoIntensityID = Shader.PropertyToID("_AOIntensity");
        int aoTextureID = Shader.PropertyToID("_AOTexture");
        #endregion

        //int _BilaterFilterFactorId = Shader.PropertyToID("_BilaterFilterFactor");
        int _BlurRadiusId = Shader.PropertyToID("_BlurRadius");
        private Camera currentCamera = null;
        private List<Vector4> sampleKernelList = new List<Vector4>();
        
       
        public enum SSAOPassName
        {
            GenerateAO = 0,
            BilateralFilter = 1,
            Composite = 2,
            Noise = 3,
        }
        public SSAOPass() {
            
        }
        private void GenerateAOSampleKernel(int SampleKernelCount)
        {
            if (SampleKernelCount == sampleKernelList.Count)
                return;
            sampleKernelList.Clear();
            for (int i = 0; i < SampleKernelCount; i++)
            {
                var vec = new Vector4(Random.Range(-1.0f, 1.0f), Random.Range(-1.0f, 1.0f), Random.Range(0, 1.0f), 1.0f);
                vec.Normalize();
                var scale = (float)i / SampleKernelCount;
                //ʹ�ֲ����϶��η��̵�����
                scale = Mathf.Lerp(0.01f, 1.0f, scale * scale);
                vec *= scale;
                sampleKernelList.Add(vec);
            }
        }
        void CalculateScreenToView(Camera mainCamera,Material mat)
        {
            float halfFovTan = Mathf.Tan(mainCamera.fieldOfView * 0.5f * Mathf.Deg2Rad);
            float invFocalLenX = 1.0f / (1.0f / halfFovTan * (mainCamera.pixelHeight / (float)mainCamera.pixelWidth));
            float invFocalLenY = 1.0f / (1.0f / invFocalLenX);
            Vector4 screenToView = new Vector4(2.0f * invFocalLenX, -2.0f * invFocalLenY, -1.0f * invFocalLenX, 1.0f * invFocalLenY);

            mat.SetVector(_ScreenToViewId, screenToView);
        }
        public override void Excute (ref ScriptableRenderContext context, ref ContextStatus status) {
            if (status.effectSetting == null || (status.effectSetting.ssaoType == SSAOType.Disabled )) return;
            if(status.effectSetting.ssaoType == SSAOType.LearnOpengl)
            {
                GenerateAOSampleKernel(status.effectSetting.ssaoSampleKernelCount);
                Texture Nosie = status.effectSetting.ssaoNosie;
                ssaoRt = new RenderTargetHandle(rtName);
                var descriptor = status.targetDescriptor;
                descriptor.msaaSamples = 1;
                descriptor.colorFormat = RenderTextureFormat.R8;
                descriptor.memoryless = RenderTextureMemoryless.None;
                descriptor.width = descriptor.width >> status.effectSetting.ssaoDownSample;
                descriptor.height = descriptor.height >> status.effectSetting.ssaoDownSample;
                ssaoRt.GetTemporaryRT(cmd, ref descriptor);
                //MDRenderUtils.ssaoMat
                Material mat = CoreUtils.ssaoMat;
                Camera currentCamera = renderer.camera;
                mat.SetTexture(_NoiseTexId, Nosie);
                mat.SetFloat(_HeightId, descriptor.height);
                mat.SetFloat(_WidthId, descriptor.width);
                mat.SetMatrix(_InverseProjectionMatrixId, currentCamera.projectionMatrix.inverse);
                //ssaoMaterial.SetFloat("_DepthBiasValue", DepthBiasValue);
                mat.SetVectorArray(_SampleKernelArrayId, sampleKernelList.ToArray());
                mat.SetFloat(_SampleKernelCountId, sampleKernelList.Count);
                //ssaoMaterial.SetFloat("_AOStrength", AOStrength);
                mat.SetFloat(_SampleKeneralRadiusId, status.effectSetting.ssaoSampleKernelRadius);
                Blit(renderer.colorTarget.Identifier(), ssaoRt.Identifier(), mat, (int)SSAOPassName.GenerateAO);
                var tempRt = new RenderTargetHandle(tempRtName);

                tempRt.GetTemporaryRT(cmd, ref descriptor);
                //mat.SetFloat(_BilaterFilterFactorId, 1.0f - status.effectSetting.ssaoBilaterFilterStrength);

                //mat.SetVector("_BlurRadius", new Vector4(BlurRadius, 0, 0, 0));
                cmd.SetGlobalVector(_BlurRadiusId, new Vector4(status.effectSetting.ssaoBlurRadius, 0, 0, 0));
                Blit(ssaoRt.Identifier(), tempRt.Identifier(), mat, (int)SSAOPassName.BilateralFilter);

                cmd.SetGlobalVector(_BlurRadiusId, new Vector4(0, status.effectSetting.ssaoBlurRadius, 0, 0));
                Blit(tempRt.Identifier(), ssaoRt.Identifier(), mat, (int)SSAOPassName.BilateralFilter);

                cmd.SetGlobalTexture(_AOTexId, ssaoRt.Identifier());
                renderer.CommitCommandBuffer(cmd);

                if (status.effectSetting.ssaoOnlyShowAO)
                {
                    Blit(ssaoRt.Identifier(), renderer.colorTarget.Identifier());
                }
                else
                {
                    renderer.FullScreenBlit(ref status, mat, (int)SSAOPassName.Composite);
                }
                tempRt.ReleaseTemporaryRT(cmd);
            }
            else
            {
                ssaoRt = new RenderTargetHandle(rtName);
                var descriptor = status.targetDescriptor;
                descriptor.msaaSamples = 1;
                descriptor.memoryless = RenderTextureMemoryless.None;
                descriptor.width = descriptor.width >> status.effectSetting.hbaoDownSample;
                descriptor.height = descriptor.height >> status.effectSetting.hbaoDownSample;
                descriptor.colorFormat = RenderTextureFormat.R8;
                ssaoRt.GetTemporaryRT(cmd, ref descriptor);
                //MDRenderUtils.ssaoMat
                Material mat = CoreUtils.hbaoMat;
                Camera currentCamera = renderer.camera;

                
                //----------��������Բ�����Բ���ÿ֡����
                Vector2 r = Vector2.zero;
                float tanHalfFovY = Mathf.Tan(0.5f * currentCamera.fieldOfView * Mathf.Deg2Rad);
                float radius = status.effectSetting.hbaoRadius;
                r.Set(radius * 0.5f * (currentCamera.pixelHeight / (tanHalfFovY * 2.0f)) * 0.5f, -1.0f / (radius * radius));
                mat.SetVector(radiusID, r);
                mat.SetFloat(biasID, status.effectSetting.hbaoBias);
                mat.SetFloat(aoIntensityID, status.effectSetting.hbaoIntensity);
                mat.SetFloat(maxRadiusPixelsID, status.effectSetting.hbaoMaxRadiusPixels);
                //mat.SetFloat(_BilaterFilterFactorId, 1.0f - status.effectSetting.ssaoBilaterFilterStrength);
                CalculateScreenToView(currentCamera, mat);
                //--------------------------------------------------------

                Blit(renderer.colorTarget.Identifier(), ssaoRt.Identifier(), mat, (int)SSAOPassName.GenerateAO);
                var tempRt = new RenderTargetHandle(tempRtName);

                tempRt.GetTemporaryRT(cmd, ref descriptor);
                //mat.SetVector("_BlurRadius", new Vector4(BlurRadius, 0, 0, 0));
                cmd.SetGlobalVector(_BlurRadiusId, new Vector4(status.effectSetting.ssaoBlurRadius, status.effectSetting.ssaoBlurRadius, 0, 0));
                Blit(ssaoRt.Identifier(), tempRt.Identifier(), mat, (int)SSAOPassName.BilateralFilter);

                //cmd.SetGlobalVector(_BlurRadiusId, new Vector4(0, status.effectSetting.ssaoBlurRadius, 0, 0));
                //Blit(tempRt.Identifier(), ssaoRt.Identifier(), mat, (int)SSAOPassName.BilateralFilter);

                cmd.SetGlobalTexture(_AOTexId, tempRt.Identifier());
                renderer.CommitCommandBuffer(cmd);

                if (status.effectSetting.ssaoOnlyShowAO)
                {
                    Blit(tempRt.Identifier(), renderer.colorTarget.Identifier());
                }
                else
                {
                    renderer.FullScreenBlit(ref status, mat, (int)SSAOPassName.Composite);
                }
                ssaoRt.ReleaseTemporaryRT(cmd);
                ssaoRt = tempRt;
            }
        }

        public override void FrameCleanup()
        {
            ssaoRt.ReleaseTemporaryRT(cmd);
        }

    }
}