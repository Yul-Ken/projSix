using System;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawMainLightPass : ScriptablePass
    {
        const int cascadesCount = 1; //固定支持两级阴影级联
        int maxPerObjectLights = 4;
        public bool shadeAdditionalLightsPerVertex = false;
        LightConstants mainLightBuffer;
        int shadowResolution;
        RenderTargetHandle mainLightShadowMap;
        ShadowSplitData[] splitData = new ShadowSplitData[4]; //shader常量设置为4级
        RenderTextureDescriptor shadowMapDesc;
        public DrawMainLightPass()
        {
            mainLightBuffer = new LightConstants();
            MDRenderPipelineAsset asset = MDRenderPipeline.asset;
            shadowResolution = (int)MDRenderPipeline.asset.MainLightShadowReslution;
            var shadowMap = RenderTexture.GetTemporary(
                shadowResolution, shadowResolution / cascadesCount,
                16, CoreUtils.shadowFormat);
            shadowMap.filterMode = FilterMode.Point;
            shadowMap.wrapMode = TextureWrapMode.Clamp;
            shadowMap.name = KeywordStrings._MainLightShadowmapTexture;
            mainLightShadowMap = new RenderTargetHandle(shadowMap);

            //主阴影相关的宏
            if (asset.mainLightShadowEnable)
            {
                Shader.EnableKeyword(KeywordStrings.MainLightShadows);
                Shader.EnableKeyword(KeywordStrings.MainLightShadowCascades);
                if (asset.softShadow) Shader.EnableKeyword(KeywordStrings.SoftShadows);
                else Shader.DisableKeyword(KeywordStrings.SoftShadows);
            }
            else
            {
                Shader.DisableKeyword(KeywordStrings.MainLightShadows);
                Shader.DisableKeyword(KeywordStrings.MainLightShadowCascades);
                Shader.DisableKeyword(KeywordStrings.SoftShadows);
            }
            //多点光相关的宏
            //if (MDRenderPipeline.asset.additionalLightsEnable) {
            //    Shader.EnableKeyword (MDTags.AdditionalLightsVertex);
            //    Shader.EnableKeyword (MDTags.AdditionalLightsPixel);
            //} else {
            //    Shader.DisableKeyword (MDTags.AdditionalLightsVertex);
            //    Shader.DisableKeyword (MDTags.AdditionalLightsPixel);
            //}
            shadeAdditionalLightsPerVertex = asset.additionalLightsRenderingMode == LightRenderingMode.PerVertex;
            if (asset.additionalLightsRenderingMode != LightRenderingMode.Disabled)
            {
                maxPerObjectLights = Math.Min(asset.additionalLightsPerObjectLimit, 4);
            }
            else
            {
                maxPerObjectLights = 0;
            }
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            status.mainLightIndex = GetShadowLightIndex(status.cullingResults.visibleLights);
            renderer.mainLightIndex = status.mainLightIndex;
            mainLightBuffer.SetupMainLight(cmd, ref status);
            mainLightBuffer.SetupAdditionalLight(cmd, ref status, shadeAdditionalLightsPerVertex, maxPerObjectLights);

            if (!MDRenderPipeline.asset.mainLightShadowEnable) return;
            cmd.SetShadowSamplingMode(mainLightShadowMap.Identifier(), ShadowSamplingMode.CompareDepths);
            SetRenderTarget(mainLightShadowMap.Identifier(), RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store, true, true);

            RenderMainShadowMapTwoCascade(ref context, ref status);

            cmd.SetGlobalTexture(mainLightShadowMap.id, mainLightShadowMap.Identifier());
        }
        void RenderMainShadowMapTwoCascade(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            var proj = Matrix4x4.identity;
            var view = Matrix4x4.identity;
            var sliceResolution = shadowResolution / cascadesCount;
            var visibleLights = status.cullingResults.visibleLights;
            if (visibleLights.Length <= 0) return;
            var shadowLightIndex = status.mainLightIndex;

            var mainLight = visibleLights[shadowLightIndex];
            var splitRatio = new Vector3(MDRenderPipeline.asset.MainLightShadowDistance, 1f, 0f); //x:cascade0/shadowDistance,y:cascade1/shadowDistance
            mainLightBuffer.shadowmapSize = new Vector4(1.0f / shadowResolution, 1.0f / sliceResolution, shadowResolution, sliceResolution); //1/w,1/h,w,h

            for (var splitIndex = 0; splitIndex < cascadesCount; ++splitIndex)
            {
                bool success = status.cullingResults.ComputeDirectionalShadowMatricesAndCullingPrimitives(
                    shadowLightIndex, splitIndex, cascadesCount, splitRatio,
                    shadowResolution, mainLight.light.shadowNearPlane,
                    out view, out proj, out splitData[splitIndex]
                );
                Bounds bounds;
                success &= status.cullingResults.GetShadowCasterBounds(shadowLightIndex, out bounds);
                if (success)
                {
                    var shadowBias = GetShadowBias(ref mainLight, ref proj, sliceResolution);
                    var lightDir = -mainLight.localToWorldMatrix.GetColumn(2);
                    lightDir.w = 0f;
                    cmd.SetGlobalVector(KeywordIds._ShadowBiasId, shadowBias);
                    cmd.SetGlobalVector(KeywordIds._LightDirectionId, lightDir);

                    int offsetX = splitIndex * sliceResolution;
                    int offsetY = 0;
                    cmd.SetViewport(new Rect(offsetX, offsetY, sliceResolution, sliceResolution));
                    cmd.EnableScissorRect(new Rect(offsetX + 4, offsetY + 4, sliceResolution - 8, sliceResolution - 8));
                    CoreUtils.SetViewProjectionMatrices(cmd, view, proj);
                    renderer.CommitCommandBuffer(cmd);

                    var settings = new ShadowDrawingSettings(status.cullingResults, shadowLightIndex);
                    settings.splitData = splitData[splitIndex];
                    context.DrawShadows(ref settings);
                    CameraCommandBufferEvent.ExecuteCommandBuffers(renderer, CommandBufferEventType.MainShadow);
                    cmd.DisableScissorRect();

                    var sliceTransform = Matrix4x4.identity;
                    sliceTransform.m00 = sliceResolution * mainLightBuffer.shadowmapSize.x;
                    sliceTransform.m11 = sliceResolution * mainLightBuffer.shadowmapSize.y;
                    sliceTransform.m03 = offsetX * mainLightBuffer.shadowmapSize.x;
                    sliceTransform.m13 = offsetY * mainLightBuffer.shadowmapSize.y;
                    var shadowTransform = CoreUtils.GetAdjustedMatrice(proj, view, false);

                    mainLightBuffer.worldToShadow[splitIndex] = sliceTransform * shadowTransform;
                }
                else
                {
#if UNITY_EDITOR
                    if (renderer.camera.cameraType == CameraType.Preview) continue; //preview camera always fail...
#endif
                    // Debug.LogError (string.Format ("ComputeDirectionalShadowMatricesAndCullingPrimitives Error! Current Camera is: {0}", data.currentCamera.name));
                }
            }

            Matrix4x4 noOpShadowMatrix = Matrix4x4.zero; //余下部分填充无操作的矩阵
            noOpShadowMatrix.m22 = (SystemInfo.usesReversedZBuffer) ? 1.0f : 0.0f;
            for (var i = cascadesCount; i <= LightConstants.MaxCascade; ++i) mainLightBuffer.worldToShadow[i] = noOpShadowMatrix;

            status.mainLightIndex = shadowLightIndex;
            mainLightBuffer.SetupShadow(cmd, splitData, ref shadowMapDesc, ref status, renderer.camera);
        }
        // 投射阴影的主光源由rendersetting指定,否则选取最亮的平行光
        int GetShadowLightIndex(NativeArray<VisibleLight> visibleLights)
        {
            int brightestIdx = 0;
            float brightestLightIntensity = 0f;
            for (var i = 0; i < visibleLights.Length; i++)
            {
                var visibleLight = visibleLights[i];
                var light = visibleLight.light;
                if (light == RenderSettings.sun) return i;
                if (visibleLight.lightType == LightType.Directional && light.intensity > brightestLightIntensity)
                {
                    brightestIdx = i;
                    brightestLightIntensity = light.intensity;
                }
            }
            return brightestIdx;
        }
        Vector4 GetShadowBias(ref VisibleLight light, ref Matrix4x4 proj, int sliceResolution)
        {
            var frustumSize = 2.0f / proj.m00; //只考虑平行光

            // depth and normal bias scale is in shadowmap texel size in world space
            float texelSize = frustumSize / sliceResolution;
            float depthBias = -MDRenderPipeline.asset.shadowDepthBias * texelSize;
            float normalBias = -MDRenderPipeline.asset.shadowNormalBias * texelSize;

            // TODO: depth and normal bias assume sample is no more than 1 texel away from shadowmap
            // This is not true with PCF. Ideally we need to do either
            // cone base bias (based on distance to center sample)
            // or receiver place bias based on derivatives.
            // For now we scale it by the PCF kernel size (5x5)
            const float kernelRadius = 2.5f;
            depthBias *= kernelRadius;
            normalBias *= kernelRadius;
            return new Vector4(depthBias, normalBias, 0.0f, 0.0f);
        }
        public override void Dispose()
        {
            mainLightShadowMap.ReleaseRenderTexture();
        }
    }
}