using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline {
    internal class DrawSkyboxPass : ScriptablePass {
        public override void Excute (ref ScriptableRenderContext context, ref ContextStatus status) {
            renderer.ReSetRenderTarget();
            var flags = renderer.camera.clearFlags;
            if (flags == CameraClearFlags.Skybox) {
                context.DrawSkybox (renderer.camera);
            }
        }
    }
}