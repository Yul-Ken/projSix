using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawOnlyUIPass : ScriptablePass
    {
        List<ShaderTagId> tagIds = new List<ShaderTagId>();
        SortingCriteria criteria = SortingCriteria.CanvasOrder | SortingCriteria.CommonTransparent;
        public DrawOnlyUIPass()
        {
            tagIds.Add(new ShaderTagId(KeywordStrings.UniversalForward));
            tagIds.Add(new ShaderTagId(KeywordStrings.SRPDefaultUnlit));
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            // //有时Game相机只有一个，渲UI前需要清理下深度，但scene相机不能清。。。
            // if (status.rendering3DScene && renderer.camera.cameraType != CameraType.SceneView) {
            //     cmd.ClearRenderTarget (true, false, Color.clear);
            //     renderer.CommitCommandBuffer (cmd);
            // }
            var drawSetting = CreateDrawingSetting(tagIds, ref criteria);
            var filterSetting = new FilteringSettings(RenderQueueRange.transparent, KeywordIds.uiLayer);

            context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);
        }
    }
}