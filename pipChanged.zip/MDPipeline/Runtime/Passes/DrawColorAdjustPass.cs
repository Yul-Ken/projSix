using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawColorAdjustPass : ScriptablePass
    {
        int lutTexId = Shader.PropertyToID(KeywordStrings._InternalLut);
        // static RenderTexture lut; //static 避免频繁重复申请
        RenderTargetHandle lut;
        int lutWidth = LookupTableConstants.lutsize * LookupTableConstants.lutsize; //1024
        int lutHeight = LookupTableConstants.lutsize; //32
        public DrawColorAdjustPass()
        {
            var rt = RenderTexture.GetTemporary(lutWidth, lutHeight, 0, RenderTextureFormat.RGB111110Float);
            rt.filterMode = FilterMode.Bilinear;
            rt.wrapMode = TextureWrapMode.Clamp;
            rt.name = KeywordStrings._InternalLut;
            lut = new RenderTargetHandle(rt);
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            if (status.effectSetting == null) return;
            if (status.needReBuildLut)
            {
                LookupTableConstants.SetupConstants(status.effectSetting);
                cmd.SetGlobalTexture(lut.id, lut.Identifier());
                Blit(lut.Identifier(), lut.Identifier(), CoreUtils.lutBuilderMat);
                // data.needReBuildLut = false;//to do: 按需更新
            }
            float exposure = Mathf.Pow(2f, status.effectSetting.exposure);
            CoreUtils.colorGradeMat.SetVector("_LutScaleOffset", new Vector4(1f / lutWidth, 1f / lutHeight, lutHeight - 1f, exposure));

            renderer.FullScreenBlit(ref status, CoreUtils.colorGradeMat);
        }
        public override void Dispose()
        {
            lut.ReleaseRenderTexture();
        }
    }
}