using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawEffectPass : ScriptablePass
    {
        List<ShaderTagId> tagIds = new List<ShaderTagId>();
        SortingCriteria criteria = SortingCriteria.CommonTransparent;
        public DrawEffectPass()
        {
            tagIds.Add(new ShaderTagId(KeywordStrings.UniversalForward));
            tagIds.Add(new ShaderTagId(KeywordStrings.SRPDefaultUnlit));
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            if (MDRenderPipeline.asset.colorGradingDontAffectParticleLayer)
            {
                var effectLayer = renderer.camera.cullingMask & KeywordIds.particleLayer;
                if (effectLayer != 0)
                {
                    var drawSetting = CreateDrawingSetting(tagIds, ref criteria, CoreUtils.GetPerObjectLightFlags(status.additionalLightsCount)); //半透明受光?
                    var filterSetting = new FilteringSettings(RenderQueueRange.transparent, effectLayer);

                    context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);
                }
            }
        }
    }
}