using System.Collections.Generic;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    internal class DrawTransparentPass : ScriptablePass
    {
        int mask;
        List<ShaderTagId> tagIds = new List<ShaderTagId>();
        SortingCriteria criteria = SortingCriteria.CommonTransparent;
        public DrawTransparentPass()
        {
            mask = KeywordIds.uiLayer | KeywordIds.hudLayer; //UI、HUD单独渲染
            if (MDRenderPipeline.asset.colorGradingDontAffectParticleLayer) mask |= KeywordIds.particleLayer; //调色不影响特效时特效单独渲染
            mask = ~mask;
            tagIds.Add(new ShaderTagId(KeywordStrings.UniversalForward));
            tagIds.Add(new ShaderTagId(KeywordStrings.SRPDefaultUnlit));
        }
        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            renderer.ReSetRenderTarget();
            var transparentLayer = renderer.camera.cullingMask & mask;
            if (transparentLayer != 0)
            {
                var drawSetting = CreateDrawingSetting(tagIds, ref criteria, CoreUtils.GetPerObjectLightFlags(status.additionalLightsCount)); //半透明受光?
                var filterSetting = new FilteringSettings(RenderQueueRange.transparent, transparentLayer);

                context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);
            }
        }
    }
}