﻿using System.Collections.Generic;
using UnityEngine.Rendering;
using UnityEngine;

namespace CustomPipeline
{
    internal class DrawBeforeUIPass : ScriptablePass
    {
        int mask;
        List<ShaderTagId> tagIds = new List<ShaderTagId>();
        SortingCriteria criteria = SortingCriteria.CommonTransparent;
        public DrawBeforeUIPass()
        {
            tagIds.Add(new ShaderTagId(KeywordStrings.UniversalForward));
            tagIds.Add(new ShaderTagId(KeywordStrings.SRPDefaultUnlit));
        }

        public override void Excute(ref ScriptableRenderContext context, ref ContextStatus status)
        {
            var effectLayer = renderer.camera.cullingMask & KeywordIds.hudLayer;
            if (effectLayer != 0)
            {
                var drawSetting = CreateDrawingSetting(tagIds, ref criteria, CoreUtils.GetPerObjectLightFlags(status.additionalLightsCount));
                var filterSetting = new FilteringSettings(RenderQueueRange.transparent, effectLayer);

                context.DrawRenderers(status.cullingResults, ref drawSetting, ref filterSetting);

                CameraCommandBufferEvent.ExecuteCommandBuffers(renderer, CommandBufferEventType.BeforeUI);
            }

        }
    }
}