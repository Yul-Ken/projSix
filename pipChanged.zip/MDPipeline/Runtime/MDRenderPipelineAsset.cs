﻿#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using UnityEngine.Rendering;

namespace CustomPipeline
{
    public enum ShadowResolution
    {
        _256 = 256,
        _512 = 512,
        _1024 = 1024,
        _2048 = 2048,
        _4096 = 4096
    }
    public enum TonemapMode
    {
        ACES,
        None
    }
    public enum LightRenderingMode
    {
        Disabled = 0,
        PerVertex = 2,
        PerPixel = 1,
    }

    public enum MsaaQuality
    {
        Disabled = 1,
        _2x = 2,
        _4x = 4,
        _8x = 8
    }
     public enum AASetting
    {
        Disabled = 0,
        FXAA = 1,
        //MSAA = 2
    }
    public class MDRenderPipelineAsset : RenderPipelineAsset
    {
        public MDRenderPipeline currentActivePipeline;
        [SerializeField] [HideInInspector] public bool supportsDynamicBatching = true;
        [SerializeField] [HideInInspector] public bool lightsUseLinearIntensity = true;
        [SerializeField] public TonemapMode tonemapMode = TonemapMode.None;
        [SerializeField] public AASetting aaSetting = AASetting.Disabled;
        [SerializeField] public RenderTextureFormat renderTargetFormat = RenderTextureFormat.RGB111110Float;//HDR、bloom等后效必须
        [SerializeField] public MsaaQuality msaaQuality = MsaaQuality.Disabled;
        [SerializeField] public bool gammaSpaceUI = true; //需要单独的UI相机且贴图不勾选sRGB，否则仍在线性下渲染
        [SerializeField] public bool forceReversedZBuffer = false; //强制全平台reversed Z,部分逻辑深埋在C++层表现神奇，暂放弃此功能
        [SerializeField] public bool colorGradingDontAffectParticleLayer = true; //调色不影响特效
        [SerializeField] public float renderScale = 1f;

        [SerializeField] public ShadowResolution CharacterShadowReslution = ShadowResolution._1024;
        [SerializeField] public ShadowResolution MainLightShadowReslution = ShadowResolution._4096;
        //[SerializeField] public bool additionalLightsEnable = true; //启用多点光

        [SerializeField] public LightRenderingMode additionalLightsRenderingMode = LightRenderingMode.PerPixel;
        [SerializeField] public int additionalLightsPerObjectLimit = 4;

        [SerializeField] public bool mainLightShadowEnable = true; //主阴影
        [SerializeField] public bool softShadow = true; //软阴影
        [SerializeField] public float shadowDepthBias = 0f;
        [SerializeField] public float shadowNormalBias = 0f;
        [SerializeField] public float shadowDistance = 60f;
        [SerializeField] [Range(0f, 1f)] public float MainLightShadowDistance = 0.15f; //相对相机视距
        [SerializeField] [Range(0.1f, 1f)] public float OpaqueTextureDawnSample = 0.5f;
        [SerializeField] public MDPipelineEffectProfile effectSetting;
        public bool UseSrpBatcher = true;
        public override Material defaultMaterial => new Material(Shader.Find("MD/Standard/SimplePBR")) { hideFlags = HideFlags.HideAndDontSave };
        // public override Material defaultParticleMaterial => new Material (Shader.Find ("MD/Effect/FX_Main")) { hideFlags = HideFlags.HideAndDontSave };
        public override Shader defaultShader => Shader.Find("MD/Standard/SimplePBR");

        public override bool Equals(object other)
        {
            return base.Equals(other);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
        protected override RenderPipeline CreatePipeline()
        {
            currentActivePipeline = new MDRenderPipeline();
            return currentActivePipeline;
        }

        protected override void OnDisable()
        {
            base.OnDisable();
        }

        protected override void OnValidate()
        {
            base.OnValidate();
        }
#if UNITY_EDITOR
        public enum DefaultMaterialType
        {
            Standard,
            Particle,
            Terrain,
            Sprite,
            UnityBuiltinDefault
        }
        public override Material defaultTerrainMaterial
        {
            get { return GetMaterial(DefaultMaterialType.Terrain); }
        }
        public override Shader terrainDetailLitShader
        {
            get { return editorResources.shaders.terrainDetailLitPS; }
        }

        public override Shader terrainDetailGrassShader
        {
            get { return editorResources.shaders.terrainDetailGrassPS; }
        }

        public override Shader terrainDetailGrassBillboardShader
        {
            get { return editorResources.shaders.terrainDetailGrassBillboardPS; }
        }
        Material GetMaterial(DefaultMaterialType materialType)
        {
            if (editorResources == null)
                return null;
            switch (materialType)
            {
                case DefaultMaterialType.Terrain:
                    return editorResources.materials.terrainLit;
                default:
                 return null;
            }
        }
        internal MDRenderPipelineEditorResources m_EditorResourcesAsset;
        MDRenderPipelineEditorResources editorResources
        {
            get
            {
                if (m_EditorResourcesAsset == null)
                    m_EditorResourcesAsset = LoadResourceFile<MDRenderPipelineEditorResources>();

                return m_EditorResourcesAsset;
            }
        }

        public static readonly string packagePath = "Packages/com.sh.md_pipeline";
        static T LoadResourceFile<T>() where T : ScriptableObject
        {
            T resourceAsset = null;
            var guids = AssetDatabase.FindAssets(typeof(T).Name + " t:scriptableobject", new[] { "Assets" });
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                resourceAsset = AssetDatabase.LoadAssetAtPath<T>(path);
                if (resourceAsset != null)
                    break;
            }
            // There's currently an issue that prevents FindAssets from find resources withing the package folder.
            if (resourceAsset == null)
            {
                //string path = packagePath + "/Runtime/Data/" + typeof(T).Name + ".asset";
                string path = packagePath + "/" + typeof(T).Name + ".asset";
                resourceAsset = AssetDatabase.LoadAssetAtPath<T>(path);
            }
            // Validate the resource file
            ResourceReloader.TryReloadAllNullIn(resourceAsset, packagePath);
            return resourceAsset;
        }
#endif
    }
}