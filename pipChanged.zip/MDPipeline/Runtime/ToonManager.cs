﻿using UnityEngine;

[ExecuteInEditMode]
public class ToonManager : MonoBehaviour {
    [Header ("环境光")]
    public Color _AmbientColor = Color.white; //全局环境光
    public float _AmbientIntensity = 0.3f;

    [Header ("场景明暗环境光")]
    public Color _SceneLightSideAmbientColor = Color.white;
    public Color _SceneDarkSideAmbientColor = Color.white;

    [Header ("角色明暗环境光")]
    public Color _CharacterLightSideAmbientColor = Color.white;
    public Color _CharacterDarkSideAmbientColor = Color.white;

    [Header ("角色主光方向")]
    public Vector3 _CharacterLightDir;

    [Header ("角色高度雾")]
    public Color _CharacterHeightFogColor = Color.white;
    public float _CharacterHeightFogThreshold = 0f;
    public float _CharacterHeightFogFearther = 0.1f;
    [Range (0f, 1f)]
    public float _CharacterHeightFogIntensity = 0f;

    [Header ("场景高度雾")]
    // public Color _SceneHightFogStartColor = Color.white;
    // public Color _SceneHightFogEndColor = Color.white;
    public Color _SceneHightFogColor = Color.white; //低于一定世界坐标出现高度雾
    public float _SceneHeightFogThreshold = 0f;
    public float _SceneHeightFogFearther = 0.1f;
    [Range (0f, 1f)]
    public float _SceneHeightFogIntensity = 0f;
    public Transform playerPos;
    public float updateInterval = 0.05f;
    Vector3 lastFramePos;
    Vector4[] _PlayerTrail = new Vector4[5]; //记录轨迹
    Vector4 _PlayerEffect;
    Matrix4x4 _MATRIX_I_VP;

    // ID
    int _AmbientColorID;
    int _AmbientIntensityID;
    int _CharacterLightSideAmbientColorID;
    int _CharacterDarkSideAmbientColorID;
    int _SceneLightSideAmbientColorID;
    int _SceneDarkSideAmbientColorID;
    // [HideInInspector][SerializeField] int MATRIX_I_VPID;
    // int _SceneHightFogStartColorID;
    // int _SceneHightFogEndColorID;
    int _CharacterHeightFogColorID;
    int _CharacterHeightFogThreasholdID;
    int _CharacterHeightFogFeartherID;
    int _CharacterHeightFogIntensityID;

    int _SceneHeightFogColorID;
    int _SceneHeightFogThreasholdID;
    int _SceneHeightFogFeartherID;
    int _SceneHeightFogIntensityID;
    int _PlayerEffectID;
    int _PlayerTrailID;
    int _CharacterLightDirID;

    private static ToonManager mInstance = null;
    public static ToonManager Instance => mInstance;
    Camera cam;

    void OnEnable () {
        mInstance = this;
        _AmbientColorID = Shader.PropertyToID ("_AmbientColor");
        _AmbientIntensityID = Shader.PropertyToID ("_AmbientIntensity");
        _CharacterLightSideAmbientColorID = Shader.PropertyToID ("_CharacterLightSideAmbientColor");
        _CharacterDarkSideAmbientColorID = Shader.PropertyToID ("_CharacterDarkSideAmbientColor");

        _SceneLightSideAmbientColorID = Shader.PropertyToID ("_SceneLightSideAmbientColor");
        _SceneDarkSideAmbientColorID = Shader.PropertyToID ("_SceneDarkSideAmbientColor");

        _CharacterHeightFogColorID = Shader.PropertyToID ("_CharacterHeightFogColor");
        _CharacterHeightFogThreasholdID = Shader.PropertyToID ("_CharacterHeightFogThreshold");
        _CharacterHeightFogFeartherID = Shader.PropertyToID ("_CharacterHeightFogFearther");
        _CharacterHeightFogIntensityID = Shader.PropertyToID ("_CharacterHeightFogIntensity");

        // _SceneHightFogStartColorID = Shader.PropertyToID ("_SceneHightFogStartColor");
        // _SceneHightFogEndColorID = Shader.PropertyToID ("_SceneHightFogEndColor");
        _SceneHeightFogColorID = Shader.PropertyToID ("_SceneHightFogColor");
        _SceneHeightFogThreasholdID = Shader.PropertyToID ("_SceneHeightFogThreshold");
        _SceneHeightFogFeartherID = Shader.PropertyToID ("_SceneHeightFogFearther");
        _SceneHeightFogIntensityID = Shader.PropertyToID ("_SceneHeightFogIntensity");
        _PlayerEffectID = Shader.PropertyToID ("_PlayerEffect");
        _PlayerTrailID = Shader.PropertyToID ("_PlayerTrail");
        _CharacterLightDirID = Shader.PropertyToID ("_CharacterLightDir");
        // _MATRIX_I_VPID = Shader.PropertyToID ("_MATRIX_I_VP");
        InitGloabalVariables ();

        cam = Camera.main;
        if (cam != null)
            cam.depthTextureMode = DepthTextureMode.Depth; //临时
    }
    void OnValidate () {
        InitGloabalVariables ();
    }
    public void InitGloabalVariables () {
        Shader.SetGlobalColor (_AmbientColorID, _AmbientColor);
        Shader.SetGlobalFloat (_AmbientIntensityID, _AmbientIntensity);
        Shader.SetGlobalColor (_CharacterLightSideAmbientColorID, _CharacterLightSideAmbientColor);
        Shader.SetGlobalColor (_CharacterDarkSideAmbientColorID, _CharacterDarkSideAmbientColor);
        Shader.SetGlobalColor (_SceneLightSideAmbientColorID, _SceneLightSideAmbientColor);
        Shader.SetGlobalColor (_SceneDarkSideAmbientColorID, _SceneDarkSideAmbientColor);
        // Shader.SetGlobalMatrix (_MATRIX_I_VPID, _MATRIX_I_VP);

        Shader.SetGlobalColor (_CharacterHeightFogColorID, _CharacterHeightFogColor);
        Shader.SetGlobalFloat (_CharacterHeightFogThreasholdID, _CharacterHeightFogThreshold);
        Shader.SetGlobalFloat (_CharacterHeightFogFeartherID, _CharacterHeightFogFearther);
        Shader.SetGlobalFloat (_CharacterHeightFogIntensityID, _CharacterHeightFogIntensity);

        // Shader.SetGlobalColor (_SceneHightFogStartColorID, _SceneHightFogStartColor);
        // Shader.SetGlobalColor (_SceneHightFogEndColorID, _SceneHightFogEndColor);
        Shader.SetGlobalColor (_SceneHeightFogColorID, _SceneHightFogColor);
        Shader.SetGlobalFloat (_SceneHeightFogThreasholdID, _SceneHeightFogThreshold);
        Shader.SetGlobalFloat (_SceneHeightFogFeartherID, _SceneHeightFogFearther);
        Shader.SetGlobalFloat (_SceneHeightFogIntensityID, _SceneHeightFogIntensity);
        Shader.SetGlobalVector (_PlayerEffectID, _PlayerEffect);
        Shader.SetGlobalVectorArray (_PlayerTrailID, _PlayerTrail);
        Shader.SetGlobalVector (_CharacterLightDirID, Vector3.Normalize (Quaternion.Euler (_CharacterLightDir) * -Vector3.forward));
    }
    void UpdateGloabalVariables () {
        Shader.SetGlobalVector (_PlayerEffectID, _PlayerEffect);
        Shader.SetGlobalVectorArray (_PlayerTrailID, _PlayerTrail);
    }
    float t = 1f;
    void Update () {
        if (playerPos == null) return;
        if ((playerPos.position - lastFramePos).magnitude > 0.01f) {
            lastFramePos = playerPos.position;
            _PlayerEffect = playerPos.position;
            _PlayerEffect.w = Time.timeSinceLevelLoad; //记录到达当前位置时间
            _PlayerTrail[0] = _PlayerEffect;
            UpdateGloabalVariables ();
        }
        t -= Time.deltaTime;
        if (t <= 0) {
            t = updateInterval;
            for (int i = _PlayerTrail.Length - 1; i > 0; i--) {
                _PlayerTrail[i] = _PlayerTrail[i - 1];
            }
            UpdateGloabalVariables ();
        }
    }

    //#region characterShadow

    //Camera m_Camera;
    //[Header("角色投影")]
    //public RenderTexture rt;
    //Shader m_DepthShader;
    //public Vector4 ShadowBias = new Vector4(0.005f, 0.005f, 0, 0);
    //private int m_ShadowBias;
    //private int m_DepthMapID;
    //private int m_ProjectionMatrixID;
    //private void initShadowCamera()
    //{
    //    m_Camera = GetComponent<Camera>();
    //    if (m_Camera == null)
    //    {
    //        m_Camera = gameObject.AddComponent<Camera>();
    //        return;
    //    }
    //    m_Camera.orthographic = true;
    //    m_Camera.clearFlags = CameraClearFlags.Color;
    //    m_Camera.backgroundColor = Color.white;
    //    m_Camera.allowMSAA = false;
    //    m_Camera.allowHDR = false;
    //    m_Camera.useOcclusionCulling = false;
    //    if (m_DepthShader == null)
    //    {
    //        m_DepthShader = Shader.Find("MD/Character/CharacterShadowDepth");
    //    }
    //    if (!rt)
    //    {
    //        rt = RenderTexture.GetTemporary(1024, 1024, 24, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear);
    //        rt.filterMode = FilterMode.Bilinear;
    //    }
    //    m_ShadowBias = Shader.PropertyToID("_CharShadowBias");
    //    m_DepthMapID = Shader.PropertyToID("_CharacterShadowMap");
    //    m_ProjectionMatrixID = Shader.PropertyToID("_CharacterShadowMapProjectionMatrix");
    //    m_Camera.targetTexture = rt;
    //    m_Camera.SetReplacementShader(m_DepthShader, "RenderType");
    //}

    //private void shadowUpdate()
    //{
    //    if(m_Camera != null)
    //    {
    //        Shader.SetGlobalVector(m_ShadowBias, ShadowBias);
    //        Shader.SetGlobalTexture(m_DepthMapID, m_Camera.targetTexture);
    //        Matrix4x4 viewToShadowProj = GL.GetGPUProjectionMatrix(m_Camera.projectionMatrix, false) * m_Camera.worldToCameraMatrix;
    //        Shader.SetGlobalMatrix(m_ProjectionMatrixID, viewToShadowProj);
    //    }
    //}

    //private void shadowOnDestroy()
    //{
    //    if (m_Camera)
    //    {
    //        m_Camera.targetTexture = null;
    //    }
    //    if (rt)
    //    {
    //        RenderTexture.ReleaseTemporary(rt);
    //        rt = null;
    //    }
    //}

    //private void OnDrawGizmos()
    //{
    //    //Gizmos.DrawCube(transform.position, new Vector3(1, 1, 2));
    //    Gizmos.color = new Color(1, 1/2, 0);

    //    Gizmos.DrawLine(transform.position + Vector3.zero, transform.position + (Quaternion.Euler(_CharacterLightDir) * Vector3.forward * 2));
    //}
    //#endregion
    // private void OnPreRender () {
    //     // MATRIX_I_VP = (GL.GetGPUProjectionMatrix (cam.projectionMatrix, false) * cam.worldToCameraMatrix).inverse;
    // }

}