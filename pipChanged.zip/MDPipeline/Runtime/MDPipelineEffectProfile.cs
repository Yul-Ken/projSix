using System;
using UnityEngine;

namespace CustomPipeline
{
    public enum SSAOType
    {
        Disabled = 0,
        LearnOpengl = 1,
        HBAO = 2,
    }
    [Serializable]
    public class MDPipelineEffectProfile : ScriptableObject
    {
        [SerializeField] public bool bloomEnable = true;
        [SerializeField] [HideInInspector] public float bloomThreshold = 0.9f;
        [SerializeField] [HideInInspector] public float bloomIntensity = 1;
        [SerializeField] [HideInInspector] public Vector4 bloomWeights = new Vector4(1, 1, 1, 1);
        [SerializeField] [HideInInspector] public Vector4 bloomScale = new Vector4(0, 0, 0, 0);
        [SerializeField] public float bloomScatter = 1;
        [SerializeField] public Color bloomTint = Color.white;

        [SerializeField] public bool sunShaftEnable = true;
        [SerializeField] public float sunShaftIntensity = 0.5f;
        [SerializeField] public float sunShaftBlurRadius = 2.5f;
        [SerializeField] public float sunShaftThreshold = 0.15f;
        [SerializeField] public float sunShaftheight = 1f;
        [SerializeField] public int sunShaftRadialBlurIterations = 2;
        [SerializeField] public float sunShaftMaxRadius = 0.75f;

        [SerializeField] public SSAOType ssaoType = SSAOType.Disabled;
        [SerializeField] public bool ssaoOnlyShowAO = false;
        [SerializeField] public int ssaoBlurRadius = 2;
        //[SerializeField] public float ssaoBilaterFilterStrength = 0.2f;
        //ssao1
        [SerializeField] public Texture ssaoNosie;
        [SerializeField] public float ssaoSampleKernelRadius = 0.16f;
        [SerializeField] public int ssaoSampleKernelCount = 64;
        [SerializeField] public int ssaoDownSample = 0;
        //hbao
        [SerializeField] public float hbaoRadius = 0.5f;
        [SerializeField] public int hbaoMaxRadiusPixels = 128;
        [SerializeField] public int hbaoDownSample = 0;
        [SerializeField] public float hbaoBias = 0f;
        [SerializeField] public float hbaoIntensity = 1;

        [SerializeField] public bool cloudShadowEnable = false;
        [SerializeField] public Texture cloudShadowTex;
        [SerializeField] public Vector2 cloudShadowUVSpeed;
        [SerializeField] public Vector2 cloudShadowUVTiling;
        [SerializeField] public float cloudShadowIntensity = 1f;
        [SerializeField] public int cloudShadowDownSample = 0;
        [SerializeField] public Color cloudShadowColor = Color.black;

        [SerializeField] public float exposure = 0;
        [SerializeField] [HideInInspector] public Vector4 lift;
        [SerializeField] [HideInInspector] public bool useLift = false;
        [SerializeField] [HideInInspector] public Vector4 gamma;
        [SerializeField] [HideInInspector] public bool useGamma = false;
        [SerializeField] [HideInInspector] public Vector4 gain;
        [SerializeField] [HideInInspector] public bool useGain = false;
        [SerializeField] [HideInInspector] public Vector4 offset;
        [SerializeField] [HideInInspector] public bool useOffset = false;

        [SerializeField] [HideInInspector] public ColorCurves colorCurves = new ColorCurves();
    }
}